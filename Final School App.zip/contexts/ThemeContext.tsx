
import React, { createContext, useContext, useState, useEffect } from 'react';

type Theme = 'light' | 'dark' | 'pink' | 'blue';

interface ThemeClasses {
    mainBg: string;
    cardBg: string;
    textMain: string;
    textSub: string;
    border: string;
    accentBg: string;
    sidebarBg: string;
}

interface ThemeContextType {
  theme: Theme;
  setTheme: (theme: Theme) => void;
  soundEnabled: boolean;
  toggleSound: () => void;
  notificationsEnabled: boolean;
  toggleNotifications: () => void;
  playSound: (type: 'click' | 'success' | 'error') => void;
  primaryColor: string; // Helper for CSS classes
  hideHeader: boolean;
  setHideHeader: (hide: boolean) => void;
  themeClasses: ThemeClasses;
}

const ThemeContext = createContext<ThemeContextType | undefined>(undefined);

export const useTheme = () => {
  const context = useContext(ThemeContext);
  if (!context) throw new Error('useTheme must be used within a ThemeProvider');
  return context;
};

export const ThemeProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [theme, setThemeState] = useState<Theme>('light');
  const [soundEnabled, setSoundEnabled] = useState(true);
  const [notificationsEnabled, setNotificationsEnabled] = useState(true);
  const [hideHeader, setHideHeader] = useState(false);

  // Load from local storage on mount
  useEffect(() => {
    const savedTheme = localStorage.getItem('app_theme') as Theme;
    const savedSound = localStorage.getItem('app_sound');
    const savedNotif = localStorage.getItem('app_notifications');
    const savedHeader = localStorage.getItem('app_hide_header');
    
    if (savedTheme) setThemeState(savedTheme);
    if (savedSound) setSoundEnabled(savedSound === 'true');
    if (savedNotif) setNotificationsEnabled(savedNotif === 'true');
    if (savedHeader) setHideHeader(savedHeader === 'true');
  }, []);

  const setTheme = (newTheme: Theme) => {
    setThemeState(newTheme);
    localStorage.setItem('app_theme', newTheme);
  };

  const toggleSound = () => {
    const newState = !soundEnabled;
    setSoundEnabled(newState);
    localStorage.setItem('app_sound', String(newState));
  };
  
  const toggleNotifications = () => {
      const newState = !notificationsEnabled;
      setNotificationsEnabled(newState);
      localStorage.setItem('app_notifications', String(newState));
  };

  const updateHideHeader = (hide: boolean) => {
      setHideHeader(hide);
      localStorage.setItem('app_hide_header', String(hide));
  };

  const playSound = (type: 'click' | 'success' | 'error') => {
    if (!soundEnabled) return;
    const audio = new Audio('https://codeskulptor-demos.commondatastorage.googleapis.com/pang/pop.mp3');
    audio.volume = 0.5;
    audio.play().catch(() => {});
  };

  const primaryColor = 
      theme === 'dark' ? 'bg-indigo-600' : 
      theme === 'pink' ? 'bg-pink-500' :
      theme === 'blue' ? 'bg-blue-500' :
      'bg-indigo-600';

  const themeClasses: ThemeClasses = {
      mainBg: theme === 'dark' ? 'bg-slate-900' : theme === 'pink' ? 'bg-pink-50' : theme === 'blue' ? 'bg-sky-50' : 'bg-[#f0f2f5]',
      cardBg: theme === 'dark' ? 'bg-slate-800' : 'bg-white',
      textMain: theme === 'dark' ? 'text-white' : theme === 'pink' ? 'text-pink-900' : theme === 'blue' ? 'text-blue-900' : 'text-gray-900',
      textSub: theme === 'dark' ? 'text-slate-400' : 'text-gray-500',
      border: theme === 'dark' ? 'border-slate-700' : theme === 'pink' ? 'border-pink-200' : theme === 'blue' ? 'border-blue-200' : 'border-gray-200',
      accentBg: theme === 'dark' ? 'bg-slate-700' : theme === 'pink' ? 'bg-pink-100' : theme === 'blue' ? 'bg-blue-100' : 'bg-indigo-50',
      sidebarBg: theme === 'dark' ? 'bg-slate-950 border-slate-800' : theme === 'pink' ? 'bg-white border-pink-100' : theme === 'blue' ? 'bg-white border-blue-100' : 'bg-white border-gray-200',
  };

  return (
    <ThemeContext.Provider value={{ theme, setTheme, soundEnabled, toggleSound, notificationsEnabled, toggleNotifications, playSound, primaryColor, hideHeader, setHideHeader: updateHideHeader, themeClasses }}>
      <div className={`theme-${theme} min-h-screen transition-colors duration-500`}>
        {children}
      </div>
    </ThemeContext.Provider>
  );
};
