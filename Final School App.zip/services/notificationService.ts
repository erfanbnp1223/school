

import { messaging } from '../firebase';
import { getToken } from 'firebase/messaging';

export const requestForToken = async () => {
    if (!messaging) {
        console.log("Messaging not initialized (not supported in this browser).");
        return;
    }
    try {
        const permission = await Notification.requestPermission();
        if (permission === 'granted') {
            // Note: Replace with your actual VAPID key from Firebase Console -> Project Settings -> Cloud Messaging -> Web Configuration
            const currentToken = await getToken(messaging, { 
                vapidKey: 'BM_replace_this_with_your_actual_vapid_key_from_firebase_console' 
            });
            
            if (currentToken) {
                console.log('FCM Token Generated:', currentToken);
                alert("Notifications Enabled Successfully!");
                // In a real app, you would save this token to the user's Firestore document
                // e.g., updateDoc(doc(db, 'users', uid), { fcmToken: currentToken });
            } else {
                console.log('No registration token available. Request permission to generate one.');
            }
        } else {
            console.log("Notification permission denied.");
            alert("Notification permission was denied. Please enable it in browser settings.");
        }
    } catch (err) {
        console.log('An error occurred while retrieving token: ', err);
    }
};