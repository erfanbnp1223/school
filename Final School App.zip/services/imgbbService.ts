
// Updated API Key provided by user
const IMGBB_API_KEY = "8ef308dab3f8e60d66b7d5a64a22c4d0"; 

export const uploadImageToImgBB = async (file: File): Promise<string> => {
  const formData = new FormData();
  formData.append('image', file);

  try {
    const response = await fetch(`https://api.imgbb.com/1/upload?key=${IMGBB_API_KEY}`, {
      method: 'POST',
      body: formData,
    });

    const data = await response.json();

    if (data.success) {
      return data.data.url;
    } else {
      console.error("ImgBB Error Data:", data);
      throw new Error(data.error?.message || 'Image upload failed. Please try a smaller image.');
    }
  } catch (error: any) {
    console.error("ImgBB Upload Error:", error);
    throw new Error(error.message || "Network error during upload");
  }
};
