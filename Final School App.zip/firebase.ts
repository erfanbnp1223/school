
import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';
import { getDatabase } from 'firebase/database';
import { getMessaging } from 'firebase/messaging';

const firebaseConfig = {
  apiKey: "AIzaSyBbzWxj3b0wSqyJ0B1qMy2rW1GYBDHGaVY",
  authDomain: "school-9da11.firebaseapp.com",
  databaseURL: "https://school-9da11-default-rtdb.firebaseio.com",
  projectId: "school-9da11",
  storageBucket: "school-9da11.firebasestorage.app",
  messagingSenderId: "414201450324",
  appId: "1:414201450324:web:05b6c93a0866ff023e42c1",
  measurementId: "G-K1G4WZDMWT"
};

const app = initializeApp(firebaseConfig);

export const auth = getAuth(app);
export const db = getFirestore(app);
export const rtdb = getDatabase(app);

// Initialize Messaging (Error handling for environments where it's not supported)
let messaging: any = null;
try {
  if (typeof window !== "undefined" && typeof navigator !== "undefined") {
    messaging = getMessaging(app);
  }
} catch (err) {
  console.log("Firebase Messaging not supported in this environment");
}
export { messaging };

export default app;
