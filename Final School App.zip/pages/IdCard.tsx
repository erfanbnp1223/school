
import React from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { ShieldCheck, ScanBarcode, CreditCard, Sparkles } from 'lucide-react';

const IdCard: React.FC = () => {
    const { userProfile } = useAuth();
    const { themeClasses, primaryColor } = useTheme();

    if (!userProfile) return null;

    if (userProfile.role === 'parent') {
        return (
            <div className="flex flex-col items-center justify-center h-[60vh] text-center space-y-4">
                 <div className="bg-gray-100 dark:bg-slate-800 p-8 rounded-full">
                    <CreditCard size={64} className="text-gray-400" />
                 </div>
                 <h2 className={`text-xl font-bold ${themeClasses.textMain}`}>No ID Card Issued</h2>
                 <p className={themeClasses.textSub}>Parent accounts are not issued digital student IDs.</p>
            </div>
        );
    }

    // "VIP Golden" Style for everyone (As requested)
    const cardBg = "bg-gradient-to-br from-yellow-500 via-amber-400 to-yellow-600";
    const accentColor = "bg-black/80";
    const badgeColor = "bg-black text-yellow-400";
    const textColor = "text-black";
    const badgeText = userProfile.role === 'admin' ? "ADMINISTRATOR" : userProfile.role === 'teacher' ? "FACULTY MEMBER" : "STUDENT";

    return (
        <div className="space-y-6 pb-20">
            <h1 className={`text-2xl font-bold flex items-center gap-2 ${themeClasses.textMain}`}>
                <CreditCard className="text-amber-500" /> Golden Digital ID
            </h1>
            
            <div className="flex justify-center py-6">
                <div className={`w-full max-w-[400px] aspect-[1.586/1] rounded-[24px] shadow-2xl relative overflow-hidden flex flex-col ${cardBg} transition-transform duration-500 hover:scale-[1.02] border-2 border-yellow-300 ring-4 ring-yellow-500/20`}>
                    
                    {/* Holographic / Texture Effects */}
                    <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/cubes.png')] opacity-20 mix-blend-overlay pointer-events-none"></div>
                    <div className="absolute inset-0 bg-gradient-to-tr from-transparent via-white/30 to-transparent z-20 pointer-events-none opacity-50"></div>
                    <div className="absolute -inset-full top-0 block h-full w-1/2 -skew-x-12 bg-gradient-to-r from-transparent to-white opacity-30 animate-shine" style={{ left: '150%' }}></div>

                    {/* Header */}
                    <div className="flex justify-between items-start p-5 relative z-10">
                        <div className="flex items-center gap-3">
                            <div className="w-12 h-12 bg-black rounded-full flex items-center justify-center border-2 border-yellow-300 shadow-lg">
                                <ShieldCheck size={24} className="text-yellow-400" />
                            </div>
                            <div>
                                <h2 className={`font-black text-lg leading-none ${textColor} tracking-tight uppercase`}>Pachgao Adorsho</h2>
                                <p className={`text-[9px] font-bold opacity-80 ${textColor} tracking-[0.2em] uppercase mt-1`}>High School</p>
                            </div>
                        </div>
                        {/* Chip Mockup */}
                        <div className="w-12 h-9 rounded-lg bg-gradient-to-br from-yellow-200 to-amber-300 border border-yellow-600 shadow-inner flex items-center justify-center opacity-90">
                           <div className="w-8 h-5 border border-yellow-800/20 rounded flex justify-between px-1">
                               <div className="w-[1px] h-full bg-yellow-800/20"></div>
                               <div className="w-[1px] h-full bg-yellow-800/20"></div>
                               <div className="w-[1px] h-full bg-yellow-800/20"></div>
                           </div>
                        </div>
                    </div>

                    {/* Content */}
                    <div className="flex-1 px-5 pb-5 flex items-end relative z-10 gap-4">
                        <div className="w-24 h-24 rounded-xl border-4 border-black/10 shadow-xl overflow-hidden shrink-0 bg-black/10">
                             <img src={userProfile.photoURL} className="w-full h-full object-cover" />
                        </div>
                        
                        <div className="flex-1 min-w-0 flex flex-col justify-end">
                            <div className="mb-2">
                                <h1 className={`text-xl font-black truncate ${textColor} tracking-tight drop-shadow-sm`}>{userProfile.displayName}</h1>
                                <span className={`inline-block px-3 py-1 rounded-full text-[10px] font-bold tracking-widest uppercase mt-1 shadow-sm ${badgeColor}`}>
                                    {badgeText}
                                </span>
                            </div>
                            
                            <div className="grid grid-cols-2 gap-y-1 text-[10px] uppercase tracking-wider font-bold">
                                <div>
                                    <p className="opacity-60 text-black">ID No.</p>
                                    <p className="text-black">{userProfile.uid.substring(0,6).toUpperCase()}</p>
                                </div>
                                {userProfile.className && (
                                    <div>
                                        <p className="opacity-60 text-black">Class</p>
                                        <p className="text-black">{userProfile.className}</p>
                                    </div>
                                )}
                                <div>
                                    <p className="opacity-60 text-black">Issued</p>
                                    <p className="text-black">2024</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    
                    {/* Decorative Background Elements */}
                    <div className="absolute bottom-0 right-0 p-4 opacity-10">
                         <Sparkles size={100} className="text-black" />
                    </div>
                </div>
            </div>

            {/* Back of Card / Barcode Section */}
            <div className={`max-w-[400px] mx-auto ${themeClasses.cardBg} rounded-3xl p-6 shadow-sm border ${themeClasses.border} text-center space-y-4`}>
                 <p className={`text-xs uppercase font-bold tracking-widest ${themeClasses.textSub}`}>Official Identification</p>
                 <div className="h-20 bg-white rounded-lg border border-gray-200 flex items-center justify-center relative overflow-hidden">
                     <div className="absolute inset-0 flex items-center justify-center opacity-80">
                         {/* CSS Barcode Mockup */}
                         <div className="flex items-end gap-[2px] h-12">
                             {[...Array(45)].map((_,i) => (
                                 <div key={i} className="bg-black" style={{ width: Math.random() > 0.5 ? '2px' : '4px', height: '100%' }}></div>
                             ))}
                         </div>
                     </div>
                 </div>
                 <p className="font-mono text-xs text-gray-400 tracking-[0.5em]">{userProfile.uid.toUpperCase()}</p>
                 <div className="pt-4 border-t border-dashed border-gray-200 dark:border-slate-700">
                     <p className="text-[10px] text-gray-400">
                         This card is the property of Pachgao Adorsho High School. 
                         If found, please return to the school administration office.
                     </p>
                 </div>
            </div>
        </div>
    );
};

export default IdCard;
