
import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { collection, addDoc, query, orderBy, onSnapshot, where, deleteDoc, doc } from 'firebase/firestore';
import { db } from '../firebase';
import { Quiz as IQuiz, QuizResult } from '../types';
import { BrainCircuit, Plus, CheckCircle, Trophy, ChevronRight, X, ArrowLeft, ArrowRight, Trash2, AlertTriangle, Clock, ListChecks } from 'lucide-react';
import { createPortal } from 'react-dom';

const Quiz: React.FC = () => {
    const { userProfile } = useAuth();
    const { themeClasses, primaryColor, playSound } = useTheme();
    const [quizzes, setQuizzes] = useState<IQuiz[]>([]);
    const [results, setResults] = useState<QuizResult[]>([]);
    const [activeTab, setActiveTab] = useState<'available' | 'results'>('available');
    
    // Create Quiz State
    const [showCreate, setShowCreate] = useState(false);
    const [newQuiz, setNewQuiz] = useState({ title: '', subject: '', classGrade: '6' });
    const [questions, setQuestions] = useState([{ question: '', options: ['', '', '', ''], correctOption: 0 }]);

    // Take Quiz State
    const [takingQuiz, setTakingQuiz] = useState<IQuiz | null>(null);
    const [currentQIndex, setCurrentQIndex] = useState(0);
    const [answers, setAnswers] = useState<number[]>([]);
    const [score, setScore] = useState<number | null>(null);

    const isTeacher = userProfile?.role === 'teacher' || userProfile?.role === 'admin';

    useEffect(() => {
        let q = query(collection(db, 'quizzes'), orderBy('createdAt', 'desc'));
        const unsub = onSnapshot(q, snap => {
            let data = snap.docs.map(d => ({ id: d.id, ...d.data() } as IQuiz));
            if (userProfile?.role === 'student' && userProfile.className) {
                data = data.filter(q => q.classGrade === userProfile.className || q.classGrade === 'All');
            }
            setQuizzes(data);
        });

        if (userProfile) {
            // REMOVED orderBy('timestamp', 'desc') to fix composite index error
            const resQ = query(collection(db, 'quiz_results'), where('studentId', '==', userProfile.uid));
            const unsubRes = onSnapshot(resQ, 
                snap => {
                    const data = snap.docs.map(d => ({ id: d.id, ...d.data() } as QuizResult));
                    // Client Sort
                    data.sort((a,b) => b.timestamp - a.timestamp);
                    setResults(data);
                },
                error => {
                    console.error("Quiz Result Error:", error);
                }
            );
            return () => { unsub(); unsubRes(); }
        }

        return unsub;
    }, [userProfile]);

    const handleAddQuestion = () => {
        setQuestions([...questions, { question: '', options: ['', '', '', ''], correctOption: 0 }]);
    };

    const handleCreate = async () => {
        if (!newQuiz.title) return alert("Enter Quiz Title");
        const validQuestions = questions.filter(q => q.question.trim() !== '');
        if (validQuestions.length === 0) return alert("Add at least one valid question.");

        try {
            await addDoc(collection(db, 'quizzes'), {
                ...newQuiz,
                questions: validQuestions,
                createdBy: userProfile?.displayName || 'Admin',
                createdAt: Date.now()
            });
            setShowCreate(false);
            setNewQuiz({ title: '', subject: '', classGrade: '6' });
            setQuestions([{ question: '', options: ['', '', '', ''], correctOption: 0 }]);
            playSound('success');
        } catch (error: any) {
            console.error(error);
            alert("Error creating quiz.");
        }
    };

    const handleDeleteQuiz = async (id: string) => {
        if(confirm("Are you sure you want to delete this quiz?")) {
            await deleteDoc(doc(db, 'quizzes', id));
        }
    };

    const startQuiz = (quiz: IQuiz) => {
        setTakingQuiz(quiz);
        setAnswers(new Array(quiz.questions.length).fill(-1));
        setScore(null);
        setCurrentQIndex(0);
    };

    const handleSelectOption = (optionIndex: number) => {
        const newAns = [...answers];
        newAns[currentQIndex] = optionIndex;
        setAnswers(newAns);
        playSound('click');
    };

    const nextQuestion = () => {
        if (currentQIndex < (takingQuiz?.questions.length || 0) - 1) {
            setCurrentQIndex(currentQIndex + 1);
        }
    };

    const prevQuestion = () => {
        if (currentQIndex > 0) setCurrentQIndex(currentQIndex - 1);
    };

    const handleSubmitQuiz = async () => {
        if (!takingQuiz || !userProfile) return;
        playSound('success');
        
        let correctCount = 0;
        takingQuiz.questions.forEach((q, i) => {
            if (answers[i] === q.correctOption) correctCount++;
        });

        const finalScore = Math.round((correctCount / takingQuiz.questions.length) * 100);
        setScore(finalScore);

        await addDoc(collection(db, 'quiz_results'), {
            quizId: takingQuiz.id,
            quizTitle: takingQuiz.title,
            studentId: userProfile.uid,
            studentName: userProfile.displayName,
            score: finalScore,
            totalQuestions: takingQuiz.questions.length,
            timestamp: Date.now()
        });
    };

    return (
        <div className="space-y-6 pb-20">
            <div className="flex justify-between items-center">
                <h1 className={`text-2xl font-bold flex items-center gap-2 ${themeClasses.textMain}`}>
                    <BrainCircuit className="text-purple-500" /> Online Quiz
                </h1>
                {isTeacher && (
                    <button onClick={() => setShowCreate(true)} className={`px-4 py-2 rounded-xl text-white font-bold flex items-center gap-2 shadow-lg ${primaryColor}`}>
                        <Plus size={18} /> Create Quiz
                    </button>
                )}
            </div>

            {/* Premium Tabs */}
            <div className={`p-1 rounded-2xl border ${themeClasses.border} inline-flex ${themeClasses.cardBg}`}>
                <button onClick={() => setActiveTab('available')} className={`px-6 py-2.5 rounded-xl font-bold text-sm transition-all ${activeTab === 'available' ? `${primaryColor} text-white shadow-md` : 'text-gray-500 hover:bg-gray-100'}`}>Available Quizzes</button>
                <button onClick={() => setActiveTab('results')} className={`px-6 py-2.5 rounded-xl font-bold text-sm transition-all ${activeTab === 'results' ? `${primaryColor} text-white shadow-md` : 'text-gray-500 hover:bg-gray-100'}`}>My Results</button>
            </div>

            {activeTab === 'available' ? (
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {quizzes.map(quiz => (
                        <div key={quiz.id} className={`${themeClasses.cardBg} rounded-[2rem] p-6 shadow-sm border ${themeClasses.border} hover:shadow-lg transition-all group relative overflow-hidden`}>
                            {/* Decorative */}
                            <div className="absolute top-0 right-0 p-8 opacity-5">
                                <BrainCircuit size={100} />
                            </div>

                            <div className="relative z-10">
                                <div className="flex justify-between items-start mb-4">
                                    <div className="p-3 rounded-2xl bg-indigo-50 text-indigo-600">
                                        <ListChecks size={24} />
                                    </div>
                                    <div className="flex gap-2">
                                        {isTeacher && (
                                            <button onClick={() => handleDeleteQuiz(quiz.id)} className="p-2 bg-red-50 text-red-500 rounded-full hover:bg-red-100 transition-colors">
                                                <Trash2 size={16} />
                                            </button>
                                        )}
                                        <span className="bg-gray-100 text-gray-600 px-3 py-1 rounded-full text-xs font-bold uppercase tracking-wider">{quiz.questions.length} Qs</span>
                                    </div>
                                </div>
                                
                                <h3 className={`font-bold text-xl mb-2 ${themeClasses.textMain}`}>{quiz.title}</h3>
                                <p className={`text-sm ${themeClasses.textSub} font-medium mb-6`}>{quiz.subject} • Class {quiz.classGrade}</p>
                                
                                <button onClick={() => startQuiz(quiz)} className={`w-full py-3 rounded-xl font-bold text-white shadow-lg flex justify-center items-center gap-2 group-hover:scale-[1.02] transition-transform ${primaryColor}`}>
                                    Start Quiz <ChevronRight size={18}/>
                                </button>
                            </div>
                        </div>
                    ))}
                    {quizzes.length === 0 && <div className="col-span-full text-center p-10 text-gray-400">No quizzes available.</div>}
                </div>
            ) : (
                <div className="space-y-4">
                    {results.map(res => (
                        <div key={res.id} className={`${themeClasses.cardBg} p-5 rounded-3xl border ${themeClasses.border} shadow-sm flex justify-between items-center animate-fade-in`}>
                            <div className="flex items-center gap-4">
                                <div className={`w-12 h-12 rounded-full flex items-center justify-center font-bold text-lg ${res.score >= 80 ? 'bg-green-100 text-green-600' : res.score >= 50 ? 'bg-orange-100 text-orange-600' : 'bg-red-100 text-red-600'}`}>
                                    {res.score >= 80 ? 'A+' : res.score >= 50 ? 'B' : 'F'}
                                </div>
                                <div>
                                    <h3 className={`font-bold text-lg ${themeClasses.textMain}`}>{res.quizTitle}</h3>
                                    <p className={`text-xs ${themeClasses.textSub} font-medium`}>{new Date(res.timestamp).toLocaleString()} • {res.totalQuestions} Questions</p>
                                </div>
                            </div>
                            <div className="text-right">
                                <p className={`text-2xl font-black ${res.score >= 80 ? 'text-green-500' : res.score >= 50 ? 'text-orange-500' : 'text-red-500'}`}>{res.score}%</p>
                                <p className="text-[10px] text-gray-400 uppercase font-bold">Score</p>
                            </div>
                        </div>
                    ))}
                    {results.length === 0 && <div className="text-center p-10 text-gray-400">No results found.</div>}
                </div>
            )}

            {/* Take Quiz Modal (One by One) */}
            {takingQuiz && createPortal(
                <div className="fixed inset-0 z-[200] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
                    <div className={`${themeClasses.cardBg} w-full max-w-2xl max-h-[90vh] rounded-[2.5rem] flex flex-col overflow-hidden animate-slide-in-up border-4 border-white/10 shadow-2xl`}>
                        {/* Header */}
                        <div className={`p-6 border-b ${themeClasses.border} flex justify-between items-center bg-gray-50/50 dark:bg-slate-800/50`}>
                            <div>
                                <h2 className={`text-xl font-bold ${themeClasses.textMain}`}>{takingQuiz.title}</h2>
                                <p className="text-xs text-gray-400 font-bold uppercase mt-1 flex items-center gap-1"><Clock size={12}/> Time Running</p>
                            </div>
                            <div className="flex items-center gap-4">
                                <div className="text-right">
                                     <span className="text-2xl font-black text-indigo-500">{currentQIndex + 1}</span>
                                     <span className="text-sm font-bold text-gray-300">/{takingQuiz.questions.length}</span>
                                </div>
                                <button onClick={() => setTakingQuiz(null)} className="p-2 bg-gray-200 rounded-full hover:bg-gray-300"><X size={20}/></button>
                            </div>
                        </div>

                        {/* Progress Bar */}
                        <div className="w-full h-1.5 bg-gray-100">
                            <div 
                                className={`h-full ${primaryColor} transition-all duration-300 shadow-[0_0_10px_rgba(99,102,241,0.5)]`} 
                                style={{ width: `${((currentQIndex + 1) / takingQuiz.questions.length) * 100}%` }}
                            ></div>
                        </div>

                        <div className="flex-1 overflow-y-auto p-8 flex flex-col justify-center">
                            {score === null ? (
                                <div className="space-y-8 animate-fade-in">
                                    <h3 className={`text-2xl font-bold leading-relaxed ${themeClasses.textMain} text-center`}>
                                        {takingQuiz.questions[currentQIndex].question}
                                    </h3>
                                    <div className="grid gap-3">
                                        {takingQuiz.questions[currentQIndex].options.map((opt, idx) => (
                                            <button
                                                key={idx}
                                                onClick={() => handleSelectOption(idx)}
                                                className={`w-full p-5 rounded-2xl text-left border-2 transition-all font-medium text-lg flex items-center justify-between group shadow-sm hover:shadow-md ${
                                                    answers[currentQIndex] === idx 
                                                        ? 'border-indigo-500 bg-indigo-50 text-indigo-700 ring-2 ring-indigo-200' 
                                                        : `border-transparent ${themeClasses.accentBg} ${themeClasses.textMain} hover:bg-gray-100 dark:hover:bg-slate-700`
                                                }`}
                                            >
                                                <span>{opt}</span>
                                                {answers[currentQIndex] === idx && <CheckCircle size={24} className="text-indigo-600"/>}
                                            </button>
                                        ))}
                                    </div>
                                </div>
                            ) : (
                                <div className="text-center py-10 animate-fade-in-up">
                                    <div className="relative inline-block">
                                        <div className="absolute inset-0 bg-yellow-400 blur-2xl opacity-20 rounded-full animate-pulse"></div>
                                        <Trophy size={100} className="mx-auto text-yellow-400 mb-6 drop-shadow-xl" />
                                    </div>
                                    <h2 className={`text-4xl font-black ${themeClasses.textMain} mb-2`}>Quiz Completed!</h2>
                                    <p className={`text-lg ${themeClasses.textSub}`}>Here is your performance report</p>
                                    
                                    <div className={`text-8xl font-black my-8 tracking-tighter ${score >= 80 ? 'text-green-500' : score >= 50 ? 'text-orange-500' : 'text-red-500'}`}>
                                        {score}%
                                    </div>
                                    
                                    <div className="flex justify-center gap-4">
                                         <div className="text-center px-6 py-3 bg-gray-50 rounded-2xl border border-gray-100">
                                             <p className="text-xs font-bold text-gray-400 uppercase">Status</p>
                                             <p className={`text-lg font-bold ${score >= 50 ? 'text-green-600' : 'text-red-600'}`}>{score >= 50 ? 'PASSED' : 'FAILED'}</p>
                                         </div>
                                    </div>

                                    <button onClick={() => setTakingQuiz(null)} className={`mt-10 px-12 py-4 rounded-2xl text-white font-bold shadow-xl hover:scale-105 transition-transform ${primaryColor}`}>Return to Menu</button>
                                </div>
                            )}
                        </div>

                        {score === null && (
                            <div className={`p-6 border-t ${themeClasses.border} flex justify-between items-center bg-gray-50/30`}>
                                <button 
                                    onClick={prevQuestion} 
                                    disabled={currentQIndex === 0}
                                    className={`px-6 py-3 rounded-xl font-bold flex items-center gap-2 transition-colors ${currentQIndex === 0 ? 'text-gray-300 cursor-not-allowed' : 'text-gray-600 hover:bg-gray-100'}`}
                                >
                                    <ArrowLeft size={20}/> Previous
                                </button>

                                {currentQIndex === takingQuiz.questions.length - 1 ? (
                                    <button 
                                        onClick={handleSubmitQuiz}
                                        disabled={answers.includes(-1)}
                                        className={`px-10 py-3 rounded-xl text-white font-bold shadow-lg transition-all ${answers.includes(-1) ? 'bg-gray-300 cursor-not-allowed' : 'bg-green-500 hover:bg-green-600 hover:scale-105'}`}
                                    >
                                        Submit Quiz
                                    </button>
                                ) : (
                                    <button 
                                        onClick={nextQuestion}
                                        className={`px-8 py-3 rounded-xl text-white font-bold shadow-lg flex items-center gap-2 hover:scale-105 transition-transform ${primaryColor}`}
                                    >
                                        Next <ArrowRight size={20}/>
                                    </button>
                                )}
                            </div>
                        )}
                    </div>
                </div>, document.body
            )}

            {/* Create Quiz Modal */}
            {showCreate && createPortal(
                <div className="fixed inset-0 z-[200] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
                    <div className={`${themeClasses.cardBg} w-full max-w-3xl max-h-[90vh] rounded-[2rem] flex flex-col overflow-hidden animate-slide-in-up shadow-2xl`}>
                        <div className={`p-6 border-b ${themeClasses.border} flex justify-between items-center`}>
                            <h2 className={`text-xl font-bold ${themeClasses.textMain}`}>Create New Quiz</h2>
                            <button onClick={() => setShowCreate(false)} className="p-2 bg-gray-100 rounded-full hover:bg-gray-200"><X size={20}/></button>
                        </div>
                        
                        <div className="flex-1 overflow-y-auto p-6 space-y-6">
                            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                                <input className={`p-4 rounded-2xl outline-none font-bold ${themeClasses.accentBg} ${themeClasses.textMain}`} placeholder="Quiz Title" value={newQuiz.title} onChange={e => setNewQuiz({...newQuiz, title: e.target.value})} />
                                <input className={`p-4 rounded-2xl outline-none font-bold ${themeClasses.accentBg} ${themeClasses.textMain}`} placeholder="Subject" value={newQuiz.subject} onChange={e => setNewQuiz({...newQuiz, subject: e.target.value})} />
                                <select className={`p-4 rounded-2xl outline-none font-bold ${themeClasses.accentBg} ${themeClasses.textMain}`} value={newQuiz.classGrade} onChange={e => setNewQuiz({...newQuiz, classGrade: e.target.value})}>
                                    {[6,7,8,9,10].map(c => <option key={c} value={c}>Class {c}</option>)}
                                    <option value="All">All Classes</option>
                                </select>
                            </div>

                            <div className="space-y-6">
                                {questions.map((q, qIdx) => (
                                    <div key={qIdx} className={`p-6 rounded-3xl border ${themeClasses.border} space-y-4 bg-gray-50 dark:bg-slate-800/50`}>
                                        <div className="flex justify-between items-center">
                                            <span className="font-bold text-indigo-500 uppercase text-xs tracking-wider">Question {qIdx + 1}</span>
                                            {questions.length > 1 && (
                                                <button onClick={() => setQuestions(questions.filter((_, i) => i !== qIdx))} className="text-red-400 hover:text-red-600"><Trash2 size={18}/></button>
                                            )}
                                        </div>
                                        <input 
                                            className={`w-full p-4 rounded-2xl outline-none font-bold text-lg ${themeClasses.cardBg} ${themeClasses.textMain}`} 
                                            placeholder="Enter question text..."
                                            value={q.question}
                                            onChange={e => {
                                                const newQs = [...questions];
                                                newQs[qIdx].question = e.target.value;
                                                setQuestions(newQs);
                                            }}
                                        />
                                        <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                                            {q.options.map((opt, oIdx) => (
                                                <div key={oIdx} className={`flex items-center gap-3 p-2 rounded-xl border ${q.correctOption === oIdx ? 'border-green-500 bg-green-50' : 'border-transparent bg-white'}`}>
                                                    <input 
                                                        type="radio" 
                                                        name={`correct-${qIdx}`} 
                                                        className="w-5 h-5 accent-green-500"
                                                        checked={q.correctOption === oIdx}
                                                        onChange={() => {
                                                            const newQs = [...questions];
                                                            newQs[qIdx].correctOption = oIdx;
                                                            setQuestions(newQs);
                                                        }}
                                                    />
                                                    <input 
                                                        className={`flex-1 p-2 bg-transparent outline-none text-sm font-medium ${themeClasses.textMain}`}
                                                        placeholder={`Option ${oIdx + 1}`}
                                                        value={opt}
                                                        onChange={e => {
                                                            const newQs = [...questions];
                                                            newQs[qIdx].options[oIdx] = e.target.value;
                                                            setQuestions(newQs);
                                                        }}
                                                    />
                                                </div>
                                            ))}
                                        </div>
                                    </div>
                                ))}
                            </div>
                            
                            <button onClick={handleAddQuestion} className="w-full py-4 border-2 border-dashed border-gray-300 rounded-2xl font-bold text-gray-500 hover:bg-gray-50 hover:border-gray-400 transition-colors">
                                + Add Another Question
                            </button>
                        </div>

                        <div className={`p-6 border-t ${themeClasses.border}`}>
                            <button onClick={handleCreate} className={`w-full py-4 rounded-2xl text-white font-bold text-lg shadow-xl hover:scale-[1.02] transition-transform ${primaryColor}`}>Publish Quiz Now</button>
                        </div>
                    </div>
                </div>, document.body
            )}
        </div>
    );
};

export default Quiz;
