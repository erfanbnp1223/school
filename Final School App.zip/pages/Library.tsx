
import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { collection, addDoc, query, onSnapshot, deleteDoc, doc } from 'firebase/firestore';
import { db } from '../firebase';
import { uploadImageToImgBB } from '../services/imgbbService';
import { Book } from '../types';
import { Library as LibraryIcon, Plus, Search, Trash2, BookOpen } from 'lucide-react';

const Library: React.FC = () => {
    const { userProfile } = useAuth();
    const { themeClasses, primaryColor } = useTheme();
    const [books, setBooks] = useState<Book[]>([]);
    const [showForm, setShowForm] = useState(false);
    const [title, setTitle] = useState('');
    const [author, setAuthor] = useState('');
    const [file, setFile] = useState<File | null>(null);
    const [searchTerm, setSearchTerm] = useState('');

    useEffect(() => {
        const unsubscribe = onSnapshot(collection(db, 'library'), snap => {
            setBooks(snap.docs.map(d => ({ id: d.id, ...d.data() } as Book)));
        });
        return unsubscribe;
    }, []);

    const handleAdd = async (e: React.FormEvent) => {
        e.preventDefault();
        if (file) {
            const url = await uploadImageToImgBB(file);
            await addDoc(collection(db, 'library'), {
                title, author, coverUrl: url, available: true, addedBy: userProfile?.uid
            });
            setShowForm(false);
            setTitle(''); setAuthor(''); setFile(null);
        }
    };

    const handleDelete = async (id: string, e: React.MouseEvent) => {
        e.stopPropagation();
        if (confirm("Delete this book?")) await deleteDoc(doc(db, 'library', id));
    };

    const filteredBooks = books.filter(b => b.title.toLowerCase().includes(searchTerm.toLowerCase()));

    return (
        <div className="space-y-6 pb-20">
            <div className="flex justify-between items-center">
                <h1 className={`text-2xl font-bold flex items-center gap-2 ${themeClasses.textMain}`}>
                    <LibraryIcon className="text-primary" /> Digital Library
                </h1>
                {(userProfile?.role === 'admin' || userProfile?.role === 'teacher') && (
                    <button onClick={() => setShowForm(!showForm)} className={`px-4 py-2 rounded-xl text-white font-bold flex items-center gap-2 ${primaryColor}`}>
                        <Plus size={18} /> Add Book
                    </button>
                )}
            </div>

            {/* Search */}
            <div className={`${themeClasses.cardBg} p-4 rounded-2xl shadow-sm border ${themeClasses.border} flex items-center gap-3`}>
                <Search className="text-gray-400" />
                <input 
                    placeholder="Search books..." 
                    className={`flex-1 bg-transparent outline-none ${themeClasses.textMain}`} 
                    value={searchTerm} 
                    onChange={e => setSearchTerm(e.target.value)} 
                />
            </div>

            {showForm && (
                <form onSubmit={handleAdd} className={`${themeClasses.cardBg} p-6 rounded-3xl shadow-lg border ${themeClasses.border} space-y-4 animate-fade-in`}>
                    <h3 className={`font-bold ${themeClasses.textMain}`}>Add New Book</h3>
                    <input value={title} onChange={e => setTitle(e.target.value)} placeholder="Book Title" required className={`w-full p-3 rounded-xl outline-none ${themeClasses.accentBg} ${themeClasses.textMain}`} />
                    <input value={author} onChange={e => setAuthor(e.target.value)} placeholder="Author" required className={`w-full p-3 rounded-xl outline-none ${themeClasses.accentBg} ${themeClasses.textMain}`} />
                    <input type="file" onChange={e => setFile(e.target.files?.[0] || null)} required className={`w-full text-sm ${themeClasses.textSub}`} />
                    <button type="submit" className={`w-full py-3 rounded-xl text-white font-bold ${primaryColor}`}>Upload Book</button>
                </form>
            )}

            <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
                {filteredBooks.map(book => (
                    <div key={book.id} className={`${themeClasses.cardBg} rounded-2xl p-3 shadow-sm hover:shadow-lg transition-all border ${themeClasses.border} group relative`}>
                        <div className="aspect-[2/3] rounded-xl overflow-hidden mb-3 relative">
                            <img src={book.coverUrl} className="w-full h-full object-cover transition-transform group-hover:scale-105" />
                            <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                                <button className="bg-white/20 backdrop-blur p-2 rounded-full text-white"><BookOpen /></button>
                            </div>
                        </div>
                        <h3 className={`font-bold text-sm truncate ${themeClasses.textMain}`}>{book.title}</h3>
                        <p className={`text-xs ${themeClasses.textSub} truncate`}>{book.author}</p>
                        
                        {(userProfile?.role === 'admin') && (
                            <button 
                                onClick={(e) => handleDelete(book.id, e)}
                                className="absolute top-2 right-2 bg-red-500 text-white p-1.5 rounded-full shadow-md opacity-0 group-hover:opacity-100 transition-opacity"
                            >
                                <Trash2 size={12} />
                            </button>
                        )}
                    </div>
                ))}
            </div>
        </div>
    );
};

export default Library;
