
import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { collection, query, where, onSnapshot } from 'firebase/firestore';
import { db } from '../firebase';
import { Fee } from '../types';
import { CreditCard, CheckCircle, AlertCircle, Clock, Calendar, TrendingUp, DollarSign } from 'lucide-react';

const Fees: React.FC = () => {
    const { userProfile } = useAuth();
    const { themeClasses, primaryColor } = useTheme();
    const [fees, setFees] = useState<Fee[]>([]);
    const [liveFee, setLiveFee] = useState(0);
    const [rates, setRates] = useState({ daily: 0, hourly: 0, minute: 0 });
    const [totalPaid, setTotalPaid] = useState(0);
    
    // Get monthly fee from profile, default to 0 to avoid assuming a cost
    const monthlyFee = userProfile?.monthlyFee || 0; 
    const isFreeStudent = monthlyFee === 0;

    useEffect(() => {
        if (!userProfile) return;

        // Fetch paid records
        const q = query(collection(db, 'fees'), where('studentId', '==', userProfile.uid));
        const unsubscribe = onSnapshot(q, snap => {
            const data = snap.docs.map(d => ({ id: d.id, ...d.data() } as Fee));
            data.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
            setFees(data);
            
            const paid = data.filter(f => f.status === 'paid').reduce((acc, curr) => acc + Number(curr.amount), 0);
            setTotalPaid(paid);
        });
        return unsubscribe;
    }, [userProfile]);

    // Real-time Fee Counter Logic
    useEffect(() => {
        if (monthlyFee === 0) {
            setLiveFee(0);
            setRates({ daily: 0, hourly: 0, minute: 0 });
            return;
        }

        const calculateLiveFee = () => {
            const now = new Date();
            const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
            const daysInMonth = new Date(now.getFullYear(), now.getMonth() + 1, 0).getDate();
            
            // Rates
            const perDay = monthlyFee / daysInMonth;
            const perHour = perDay / 24;
            const perMinute = perHour / 60;
            const perSecond = perMinute / 60;

            setRates({ 
                daily: parseFloat(perDay.toFixed(2)), 
                hourly: parseFloat(perHour.toFixed(2)), 
                minute: parseFloat(perMinute.toFixed(4)) 
            });

            // Calculate accumulated fee for this month down to the millisecond
            const msPassed = now.getTime() - startOfMonth.getTime();
            const totalSecondsPassed = msPassed / 1000;
            
            // Accrued this month
            const currentMonthAccrued = totalSecondsPassed * perSecond;
            
            setLiveFee(currentMonthAccrued);
        };

        const timer = setInterval(calculateLiveFee, 100); // Update every 100ms for smooth effect
        calculateLiveFee(); // Initial call

        return () => clearInterval(timer);
    }, [monthlyFee]);

    return (
        <div className="space-y-8 pb-24">
            <div className="flex justify-between items-center">
                 <h1 className={`text-2xl font-bold flex items-center gap-2 ${themeClasses.textMain}`}>
                    <CreditCard className="text-emerald-500" /> Live Tuition Fees
                </h1>
                <div className="text-xs font-bold text-gray-400 bg-gray-100 px-3 py-1 rounded-full">
                    Monthly Base: ৳{monthlyFee}
                </div>
            </div>

            {/* Real-time Ticker Card */}
            <div className={`relative overflow-hidden rounded-[2.5rem] ${isFreeStudent ? 'bg-gradient-to-br from-green-500 to-emerald-700' : 'bg-gradient-to-br from-slate-900 via-slate-800 to-black'} text-white shadow-2xl p-8 border border-slate-700`}>
                <div className="absolute top-0 right-0 p-10 opacity-10">
                    <Clock size={120} />
                </div>
                
                <div className="relative z-10 flex flex-col items-center text-center">
                    <p className="text-sm font-bold opacity-80 uppercase tracking-[0.2em] mb-2 animate-pulse">
                        {isFreeStudent ? "Scholarship Status" : "Real-time Cost Counter"}
                    </p>
                    <div className="text-6xl md:text-7xl font-mono font-black tracking-tighter text-transparent bg-clip-text bg-gradient-to-r from-white to-slate-200 mb-4 tabular-nums">
                        {isFreeStudent ? "FREE" : `৳${liveFee.toFixed(4)}`}
                    </div>
                    <p className="text-xs opacity-60 max-w-xs">
                        {isFreeStudent 
                            ? "You are currently studying with a full scholarship. No tuition fees apply."
                            : "This reflects the tuition fee accumulated for the current month up to this exact second."
                        }
                    </p>
                </div>

                {/* Rates Grid */}
                {!isFreeStudent && (
                    <div className="grid grid-cols-3 gap-4 mt-8 pt-6 border-t border-white/10 relative z-10">
                        <div className="text-center">
                            <p className="text-[10px] text-gray-500 uppercase font-bold">Per Day</p>
                            <p className="text-lg font-bold text-white">৳{rates.daily}</p>
                        </div>
                        <div className="text-center border-l border-r border-white/10">
                            <p className="text-[10px] text-gray-500 uppercase font-bold">Per Hour</p>
                            <p className="text-lg font-bold text-white">৳{rates.hourly}</p>
                        </div>
                        <div className="text-center">
                            <p className="text-[10px] text-gray-500 uppercase font-bold">Per Min</p>
                            <p className="text-lg font-bold text-white">৳{rates.minute}</p>
                        </div>
                    </div>
                )}
            </div>

            {/* Stats Overview */}
            <div className="grid grid-cols-2 gap-4">
                <div className={`${themeClasses.cardBg} p-5 rounded-3xl shadow-sm border ${themeClasses.border} flex flex-col justify-between`}>
                     <div className="flex justify-between items-start mb-2">
                         <div className="p-2 bg-green-100 text-green-600 rounded-full"><CheckCircle size={18} /></div>
                         <span className="text-[10px] font-bold text-gray-400 uppercase">Paid</span>
                     </div>
                     <h3 className={`text-2xl font-black ${themeClasses.textMain}`}>৳{totalPaid}</h3>
                     <div className="h-1.5 w-full bg-gray-100 rounded-full mt-2 overflow-hidden">
                         <div className="h-full bg-green-500 w-3/4"></div>
                     </div>
                </div>

                <div className={`${themeClasses.cardBg} p-5 rounded-3xl shadow-sm border ${themeClasses.border} flex flex-col justify-between`}>
                     <div className="flex justify-between items-start mb-2">
                         <div className="p-2 bg-red-100 text-red-600 rounded-full"><AlertCircle size={18} /></div>
                         <span className="text-[10px] font-bold text-gray-400 uppercase">Est. Due</span>
                     </div>
                     <h3 className={`text-2xl font-black ${themeClasses.textMain}`}>৳{(Math.max(0, monthlyFee - (totalPaid % (monthlyFee || 1)))).toFixed(0)}</h3>
                     <div className="h-1.5 w-full bg-gray-100 rounded-full mt-2 overflow-hidden">
                         <div className="h-full bg-red-500 w-1/2"></div>
                     </div>
                </div>
            </div>

            {/* Transaction History */}
            <div className={`${themeClasses.cardBg} rounded-[2rem] shadow-sm border ${themeClasses.border} overflow-hidden`}>
                <div className={`p-6 border-b ${themeClasses.border} flex justify-between items-center`}>
                    <h3 className={`font-bold text-lg ${themeClasses.textMain}`}>Payment History</h3>
                    <Calendar size={18} className="text-gray-400" />
                </div>
                
                <div className="divide-y divide-gray-100 dark:divide-gray-800">
                    {fees.length > 0 ? fees.map(fee => (
                        <div key={fee.id} className="p-5 flex items-center justify-between hover:bg-gray-50 dark:hover:bg-slate-800/50 transition-colors">
                            <div className="flex items-center gap-4">
                                <div className={`w-10 h-10 rounded-full flex items-center justify-center font-bold text-lg ${fee.status === 'paid' ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'}`}>
                                    $
                                </div>
                                <div>
                                    <p className={`font-bold ${themeClasses.textMain}`}>{fee.type} Fee</p>
                                    <p className="text-xs text-gray-400">{fee.month} • {new Date(fee.date).toLocaleDateString()}</p>
                                </div>
                            </div>
                            <div className="text-right">
                                <p className={`font-bold ${themeClasses.textMain}`}>৳{fee.amount}</p>
                                <span className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded ${
                                    fee.status === 'paid' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'
                                }`}>
                                    {fee.status}
                                </span>
                            </div>
                        </div>
                    )) : (
                        <div className="p-10 text-center text-gray-400 flex flex-col items-center">
                            <CreditCard size={48} className="mb-2 opacity-20" />
                            <p>No payment records found.</p>
                        </div>
                    )}
                </div>
            </div>
        </div>
    );
};

export default Fees;
