
import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { collection, query, where, onSnapshot, getDocs } from 'firebase/firestore';
import { db } from '../firebase';
import { UserProfile, Fee } from '../types';
import { Users, Search, Phone, Mail, X, MapPin, Droplet, User, Calendar, Hash, Filter } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { createPortal } from 'react-dom';

const AllStudents: React.FC = () => {
    const { userProfile } = useAuth();
    const { themeClasses } = useTheme();
    const navigate = useNavigate();
    const [students, setStudents] = useState<UserProfile[]>([]);
    const [searchTerm, setSearchTerm] = useState('');
    const [selectedClass, setSelectedClass] = useState('All');
    
    // Modal State
    const [selectedStudent, setSelectedStudent] = useState<UserProfile | null>(null);
    const [studentStats, setStudentStats] = useState({ presentCount: 0, totalDue: 0, totalPaid: 0 });

    useEffect(() => {
        if (userProfile && userProfile.role === 'student') {
            navigate('/');
        }
        const q = query(collection(db, 'users'), where('role', '==', 'student'));
        const unsubscribe = onSnapshot(q, (snapshot) => {
            const data = snapshot.docs.map(doc => ({ uid: doc.id, ...doc.data() } as UserProfile));
            setStudents(data);
        });
        return unsubscribe;
    }, [userProfile, navigate]);

    // Fetch Stats when a student is selected
    useEffect(() => {
        const fetchStats = async () => {
            if (!selectedStudent) return;
            
            // Attendance
            const attQ = query(collection(db, 'attendance'), where('studentId', '==', selectedStudent.uid), where('status', '==', 'present'));
            const attSnap = await getDocs(attQ);
            
            // Fees
            const monthlyFee = selectedStudent['monthlyFee'] || 0;
            const currentMonth = new Date().getMonth() + 1;
            const totalAccrued = currentMonth * monthlyFee;

            const feeQ = query(collection(db, 'fees'), where('studentId', '==', selectedStudent.uid), where('status', '==', 'paid'));
            const feeSnap = await getDocs(feeQ);
            const totalPaid = feeSnap.docs.reduce((a, b) => a + Number(b.data().amount), 0);
            
            setStudentStats({ presentCount: attSnap.size, totalDue: Math.max(0, totalAccrued - totalPaid), totalPaid: totalPaid });
        };
        fetchStats();
    }, [selectedStudent]);

    const filteredStudents = students.filter(s => {
        const matchesSearch = (s.displayName || '').toLowerCase().includes(searchTerm.toLowerCase()) || 
                              s.rollNumber?.includes(searchTerm);
        const matchesClass = selectedClass === 'All' || s.className === selectedClass;
        return matchesSearch && matchesClass;
    });

    return (
        <div className="space-y-6">
            <h1 className={`text-2xl font-bold flex items-center gap-2 ${themeClasses.textMain}`}>
                <Users className="text-primary" /> All Students
            </h1>
            
            <div className="flex flex-col md:flex-row gap-4">
                <div className={`${themeClasses.cardBg} p-4 rounded-3xl shadow-sm flex items-center space-x-2 border ${themeClasses.border} flex-1`}>
                    <Search className="text-gray-400" />
                    <input 
                        type="text" 
                        placeholder="Search by Name or Roll..." 
                        className={`flex-1 bg-transparent border-none focus:ring-0 outline-none ${themeClasses.textMain}`}
                        value={searchTerm}
                        onChange={e => setSearchTerm(e.target.value)}
                    />
                </div>
                
                <div className={`${themeClasses.cardBg} p-4 rounded-3xl shadow-sm flex items-center space-x-2 border ${themeClasses.border} md:w-48`}>
                    <Filter className="text-gray-400" size={18} />
                    <select 
                        className={`bg-transparent outline-none w-full ${themeClasses.textMain} font-bold`}
                        value={selectedClass}
                        onChange={(e) => setSelectedClass(e.target.value)}
                    >
                        <option value="All">All Classes</option>
                        {[6,7,8,9,10].map(c => <option key={c} value={c}>Class {c}</option>)}
                    </select>
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 pb-24">
                {filteredStudents.map(student => (
                    <div 
                        key={student.uid} 
                        onClick={() => setSelectedStudent(student)}
                        className={`${themeClasses.cardBg} p-6 rounded-3xl shadow-sm hover:shadow-lg hover:scale-[1.02] transition-all flex flex-col items-center text-center relative border ${themeClasses.border} cursor-pointer overflow-hidden group`}
                    >
                        {/* Background Image Overlay - UPDATED */}
                        <div className="absolute inset-0 z-0">
                            <img 
                                src="https://i.postimg.cc/y3WGqbYX/image.jpg" 
                                className="w-full h-full object-cover opacity-10 group-hover:opacity-20 transition-opacity blur-sm" 
                                onError={(e) => e.currentTarget.style.display = 'none'} 
                            />
                            <div className="absolute inset-0 bg-gradient-to-t from-white/90 via-white/50 to-white/20 dark:from-slate-900 dark:via-slate-900/50 dark:to-slate-900/20"></div>
                        </div>

                        <div className="relative z-10 w-full flex flex-col items-center">
                            <div className="absolute top-0 right-0 bg-indigo-50 text-indigo-700 font-bold px-2 py-1 rounded-lg text-xs border border-indigo-100 shadow-sm">
                                Class {student.className || 'N/A'}
                            </div>
                            <div className="absolute top-0 left-0 bg-orange-50 text-orange-700 font-bold px-2 py-1 rounded-lg text-xs border border-orange-100 shadow-sm">
                                Roll: {student.rollNumber || '-'}
                            </div>
                            
                            <div className="w-24 h-24 rounded-full p-1 border-2 border-indigo-100 mb-4 bg-white/50 backdrop-blur-sm">
                                <img 
                                    src={student.photoURL} 
                                    alt={student.displayName} 
                                    className="w-full h-full rounded-full object-cover shadow-md"
                                />
                            </div>
                            
                            <h3 className={`font-bold text-lg ${themeClasses.textMain} line-clamp-1`}>{student.displayName}</h3>
                            
                            <div className="mt-4 space-y-2 w-full text-sm">
                                <div className="flex items-center justify-center gap-2 text-gray-500 bg-white/60 dark:bg-black/20 py-1.5 rounded-full backdrop-blur-md border border-white/20">
                                    <Mail size={14} /> <span className="truncate max-w-[150px]">{student.email}</span>
                                </div>
                            </div>
                        </div>
                    </div>
                ))}
                {filteredStudents.length === 0 && <div className="col-span-full text-center text-gray-400 py-10">No students found.</div>}
            </div>

            {/* Modal - Higher Z-Index [300] to cover Nav */}
            {selectedStudent && createPortal(
                <div className="fixed inset-0 z-[300] flex items-center justify-center bg-black/60 backdrop-blur-md p-4" onClick={() => setSelectedStudent(null)}>
                    <div className={`${themeClasses.cardBg} w-full max-w-lg rounded-[2.5rem] p-6 relative animate-slide-in-up shadow-2xl flex flex-col max-h-[90vh]`} onClick={e => e.stopPropagation()}>
                        
                        <div className="flex justify-between items-center mb-4 border-b border-gray-100 dark:border-slate-800 pb-4">
                             <h2 className={`text-xl font-bold ${themeClasses.textMain}`}>Student Profile</h2>
                             <button onClick={() => setSelectedStudent(null)} className="p-2 bg-gray-100 dark:bg-slate-700 rounded-full text-gray-500 hover:text-gray-800">
                                <X size={20} />
                            </button>
                        </div>
                        
                        <div className="overflow-y-auto no-scrollbar pb-6">
                            <div className="text-center mb-6">
                                <div className="relative inline-block">
                                    <div className="absolute inset-0 bg-indigo-500 blur-xl opacity-20 rounded-full"></div>
                                    <img src={selectedStudent.photoURL} className="relative w-32 h-32 rounded-full mx-auto mb-3 border-4 border-indigo-50 dark:border-slate-700 shadow-xl object-cover" />
                                </div>
                                <h2 className={`text-2xl font-bold ${themeClasses.textMain}`}>{selectedStudent.displayName}</h2>
                                <div className="flex justify-center gap-2 mt-2">
                                    <span className="bg-indigo-100 text-indigo-600 px-3 py-1 rounded-full text-xs font-bold uppercase shadow-sm">Class {selectedStudent.className}</span>
                                    <span className="bg-orange-100 text-orange-600 px-3 py-1 rounded-full text-xs font-bold uppercase shadow-sm">Roll {selectedStudent.rollNumber}</span>
                                </div>
                            </div>

                            <div className="grid grid-cols-2 gap-4 mb-6">
                                <div className="bg-gradient-to-br from-green-50 to-green-100 dark:from-green-900/20 dark:to-green-900/10 p-4 rounded-2xl text-center border border-green-200 dark:border-green-800/30">
                                    <p className="text-xs text-green-700 font-bold uppercase mb-1">Present Days</p>
                                    <p className="text-2xl font-black text-green-600 dark:text-green-400">{studentStats.presentCount}</p>
                                </div>
                                <div className="bg-gradient-to-br from-red-50 to-red-100 dark:from-red-900/20 dark:to-red-900/10 p-4 rounded-2xl text-center border border-red-200 dark:border-red-800/30">
                                    <p className="text-xs text-red-700 font-bold uppercase mb-1">Total Due</p>
                                    <p className="text-2xl font-black text-red-600 dark:text-red-400">৳{studentStats.totalDue}</p>
                                </div>
                            </div>

                            <div className="space-y-4">
                                <h3 className={`font-bold border-b pb-2 ${themeClasses.border} ${themeClasses.textMain}`}>Personal Information</h3>
                                
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                                    <div className={`flex items-start gap-3 ${themeClasses.accentBg} p-3 rounded-2xl`}>
                                        <div className="p-2 bg-white dark:bg-slate-800 rounded-full text-blue-500 shadow-sm"><User size={16}/></div>
                                        <div>
                                            <p className={`text-[10px] font-bold uppercase opacity-60 ${themeClasses.textSub}`}>Father's Name</p>
                                            <p className={`text-sm font-bold ${themeClasses.textMain}`}>{selectedStudent['fatherName'] || 'N/A'}</p>
                                        </div>
                                    </div>

                                    <div className={`flex items-start gap-3 ${themeClasses.accentBg} p-3 rounded-2xl`}>
                                        <div className="p-2 bg-white dark:bg-slate-800 rounded-full text-red-500 shadow-sm"><Droplet size={16}/></div>
                                        <div>
                                            <p className={`text-[10px] font-bold uppercase opacity-60 ${themeClasses.textSub}`}>Blood Group</p>
                                            <p className={`text-sm font-bold ${themeClasses.textMain}`}>{selectedStudent['bloodGroup'] || 'N/A'}</p>
                                        </div>
                                    </div>
                                    
                                     <div className={`flex items-start gap-3 ${themeClasses.accentBg} p-3 rounded-2xl`}>
                                        <div className="p-2 bg-white dark:bg-slate-800 rounded-full text-orange-500 shadow-sm"><Calendar size={16}/></div>
                                        <div>
                                            <p className={`text-[10px] font-bold uppercase opacity-60 ${themeClasses.textSub}`}>Age</p>
                                            <p className={`text-sm font-bold ${themeClasses.textMain}`}>{selectedStudent['age'] ? `${selectedStudent['age']} Years` : 'N/A'}</p>
                                        </div>
                                    </div>

                                    <div className={`flex items-start gap-3 ${themeClasses.accentBg} p-3 rounded-2xl`}>
                                        <div className="p-2 bg-white dark:bg-slate-800 rounded-full text-pink-500 shadow-sm"><Phone size={16}/></div>
                                        <div>
                                            <p className={`text-[10px] font-bold uppercase opacity-60 ${themeClasses.textSub}`}>Phone</p>
                                            <p className={`text-sm font-bold ${themeClasses.textMain}`}>{selectedStudent.phone || 'N/A'}</p>
                                        </div>
                                    </div>
                                    
                                    <div className={`flex items-start gap-3 ${themeClasses.accentBg} p-3 rounded-2xl col-span-1 md:col-span-2`}>
                                        <div className="p-2 bg-white dark:bg-slate-800 rounded-full text-green-500 shadow-sm"><MapPin size={16}/></div>
                                        <div>
                                            <p className={`text-[10px] font-bold uppercase opacity-60 ${themeClasses.textSub}`}>Address</p>
                                            <p className={`text-sm font-bold ${themeClasses.textMain}`}>{selectedStudent['address'] || 'N/A'}</p>
                                        </div>
                                    </div>

                                     <div className={`flex items-start gap-3 ${themeClasses.accentBg} p-3 rounded-2xl col-span-1 md:col-span-2`}>
                                        <div className="p-2 bg-white dark:bg-slate-800 rounded-full text-indigo-500 shadow-sm"><Mail size={16}/></div>
                                        <div>
                                            <p className={`text-[10px] font-bold uppercase opacity-60 ${themeClasses.textSub}`}>Email</p>
                                            <p className={`text-sm font-bold ${themeClasses.textMain} break-all`}>{selectedStudent.email}</p>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div className="pt-2">
                            <button onClick={() => setSelectedStudent(null)} className="w-full bg-indigo-600 text-white py-3 rounded-xl font-bold shadow-lg shadow-indigo-500/30">
                                Close Profile
                            </button>
                        </div>
                    </div>
                </div>, document.body
            )}
        </div>
    );
};

export default AllStudents;
