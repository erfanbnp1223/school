

import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { collection, addDoc, query, orderBy, onSnapshot, where, deleteDoc, doc } from 'firebase/firestore';
import { db } from '../firebase';
import { RoutineEntry } from '../types';
import { Calendar, Plus, Clock, BookOpen, User, Trash2, ChevronRight, X } from 'lucide-react';
import { createPortal } from 'react-dom';

const DAYS = ['Saturday', 'Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday'];

const Routine: React.FC = () => {
    const { userProfile } = useAuth();
    const { themeClasses, primaryColor } = useTheme();
    const [routines, setRoutines] = useState<RoutineEntry[]>([]);
    const [selectedDay, setSelectedDay] = useState(DAYS[0]);
    const [selectedClass, setSelectedClass] = useState(userProfile?.className || '6'); // Default to 6 if not student

    // Form State
    const [showAdd, setShowAdd] = useState(false);
    const [newEntry, setNewEntry] = useState<Partial<RoutineEntry>>({
        classGrade: '6', day: 'Saturday', period: '', time: '', subject: '', teacherName: ''
    });

    const isStudent = userProfile?.role === 'student';
    const canEdit = userProfile?.role === 'admin' || userProfile?.role === 'teacher';

    useEffect(() => {
        let q = query(collection(db, 'routine_entries'), orderBy('time'));
        
        if (isStudent) {
            // Students only see their class
            q = query(collection(db, 'routine_entries'), where('classGrade', '==', userProfile.className));
        }
        
        const unsubscribe = onSnapshot(q, snap => {
            const data = snap.docs.map(d => ({ id: d.id, ...d.data() } as RoutineEntry));
            // Client side filter if needed for dynamic class selection by teacher
            setRoutines(data);
        });
        return unsubscribe;
    }, [userProfile, isStudent]);

    const handleAdd = async () => {
        if(!newEntry.period || !newEntry.subject || !newEntry.time) return;
        await addDoc(collection(db, 'routine_entries'), {
            ...newEntry,
            createdAt: Date.now()
        });
        setShowAdd(false);
        setNewEntry({ classGrade: selectedClass, day: selectedDay, period: '', time: '', subject: '', teacherName: '' });
    };

    const handleDelete = async (id: string) => {
        if(confirm("Delete this routine entry?")) await deleteDoc(doc(db, 'routine_entries', id));
    };

    // Filter displayed routines
    const displayedRoutines = routines.filter(r => 
        r.day === selectedDay && 
        (isStudent ? true : r.classGrade === selectedClass)
    ).sort((a,b) => a.time.localeCompare(b.time));

    return (
        <div className="space-y-6 pb-24">
            <div className="flex justify-between items-center">
                <h1 className={`text-2xl font-bold flex items-center gap-2 ${themeClasses.textMain}`}>
                    <Calendar className="text-pink-500" /> Class Routine
                </h1>
                {canEdit && (
                    <button onClick={() => setShowAdd(true)} className={`px-4 py-2 rounded-xl text-white font-bold flex items-center gap-2 shadow-lg ${primaryColor}`}>
                        <Plus size={18} /> Add Period
                    </button>
                )}
            </div>

            {/* Class Selector for Teachers */}
            {!isStudent && (
                <div className={`${themeClasses.cardBg} p-4 rounded-2xl border ${themeClasses.border} flex items-center gap-4`}>
                    <span className={`font-bold ${themeClasses.textSub}`}>Select Class:</span>
                    <select 
                        value={selectedClass} 
                        onChange={(e) => setSelectedClass(e.target.value)}
                        className={`bg-transparent font-bold text-lg outline-none ${themeClasses.textMain}`}
                    >
                        {[6,7,8,9,10].map(c => <option key={c} value={c}>Class {c}</option>)}
                    </select>
                </div>
            )}

            {/* Days Tabs */}
            <div className="flex overflow-x-auto gap-2 pb-2 no-scrollbar">
                {DAYS.map(day => (
                    <button
                        key={day}
                        onClick={() => setSelectedDay(day)}
                        className={`px-5 py-2.5 rounded-full font-bold whitespace-nowrap transition-all ${
                            selectedDay === day 
                            ? `${primaryColor} text-white shadow-lg scale-105` 
                            : `${themeClasses.cardBg} ${themeClasses.textSub} border ${themeClasses.border}`
                        }`}
                    >
                        {day}
                    </button>
                ))}
            </div>

            {/* Timeline */}
            <div className="space-y-4">
                {displayedRoutines.length > 0 ? displayedRoutines.map((r, i) => (
                    <div key={r.id} className={`${themeClasses.cardBg} p-5 rounded-3xl border ${themeClasses.border} shadow-sm flex gap-4 relative group animate-fade-in-up`} style={{animationDelay: `${i*100}ms`}}>
                        <div className="flex flex-col items-center justify-center w-20 shrink-0 border-r border-dashed border-gray-200 dark:border-slate-700 pr-4">
                            <span className={`text-sm font-bold ${themeClasses.textMain}`}>{r.time.split('-')[0]}</span>
                            <div className="h-8 w-0.5 bg-gray-200 dark:bg-slate-700 my-1"></div>
                            <span className={`text-xs text-gray-400`}>{r.time.split('-')[1]}</span>
                        </div>
                        <div className="flex-1">
                            <div className="flex justify-between items-start">
                                <h3 className={`font-bold text-lg ${themeClasses.textMain}`}>{r.subject}</h3>
                                <span className="bg-indigo-50 text-indigo-600 px-2 py-1 rounded-lg text-xs font-bold uppercase">{r.period}</span>
                            </div>
                            <div className="flex items-center gap-4 mt-2">
                                <div className="flex items-center gap-1 text-sm text-gray-500">
                                    <User size={14} /> {r.teacherName || 'TBA'}
                                </div>
                                {r.roomNo && (
                                     <div className="flex items-center gap-1 text-sm text-gray-500">
                                        <div className="w-1.5 h-1.5 bg-gray-400 rounded-full"></div> Room {r.roomNo}
                                    </div>
                                )}
                            </div>
                        </div>
                        {canEdit && (
                            <button onClick={() => handleDelete(r.id)} className="absolute top-4 right-4 text-red-400 opacity-0 group-hover:opacity-100 transition-opacity">
                                <Trash2 size={16}/>
                            </button>
                        )}
                    </div>
                )) : (
                    <div className="text-center py-20 opacity-50">
                        <Calendar size={64} className="mx-auto mb-4 text-gray-300"/>
                        <p>No classes scheduled for {selectedDay}.</p>
                    </div>
                )}
            </div>

            {/* Add Modal */}
            {showAdd && createPortal(
                <div className="fixed inset-0 z-[200] bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
                     <div className={`${themeClasses.cardBg} w-full max-w-md rounded-[2.5rem] p-6 animate-slide-in-up`}>
                        <div className="flex justify-between items-center mb-6 border-b pb-4 border-gray-100 dark:border-slate-800">
                             <h2 className={`text-xl font-bold ${themeClasses.textMain}`}>Add Schedule Entry</h2>
                             <button onClick={() => setShowAdd(false)}><X className="text-gray-400"/></button>
                        </div>
                        
                        <div className="space-y-4">
                            <div className="flex gap-4">
                                <div className="flex-1">
                                    <label className={`text-xs font-bold uppercase ${themeClasses.textSub}`}>Class</label>
                                    <select className={`w-full p-3 rounded-xl outline-none ${themeClasses.accentBg} ${themeClasses.textMain}`} value={newEntry.classGrade} onChange={e => setNewEntry({...newEntry, classGrade: e.target.value})}>
                                        {[6,7,8,9,10].map(c => <option key={c} value={c}>Class {c}</option>)}
                                    </select>
                                </div>
                                <div className="flex-1">
                                    <label className={`text-xs font-bold uppercase ${themeClasses.textSub}`}>Day</label>
                                    <select className={`w-full p-3 rounded-xl outline-none ${themeClasses.accentBg} ${themeClasses.textMain}`} value={newEntry.day} onChange={e => setNewEntry({...newEntry, day: e.target.value})}>
                                        {DAYS.map(d => <option key={d} value={d}>{d}</option>)}
                                    </select>
                                </div>
                            </div>

                            <input className={`w-full p-3 rounded-xl outline-none ${themeClasses.accentBg} ${themeClasses.textMain}`} placeholder="Period Name (e.g. 1st Period)" value={newEntry.period} onChange={e => setNewEntry({...newEntry, period: e.target.value})} />
                            <input className={`w-full p-3 rounded-xl outline-none ${themeClasses.accentBg} ${themeClasses.textMain}`} placeholder="Time (e.g. 10:00 - 10:45 AM)" value={newEntry.time} onChange={e => setNewEntry({...newEntry, time: e.target.value})} />
                            <input className={`w-full p-3 rounded-xl outline-none ${themeClasses.accentBg} ${themeClasses.textMain}`} placeholder="Subject Name" value={newEntry.subject} onChange={e => setNewEntry({...newEntry, subject: e.target.value})} />
                            <input className={`w-full p-3 rounded-xl outline-none ${themeClasses.accentBg} ${themeClasses.textMain}`} placeholder="Teacher Name" value={newEntry.teacherName} onChange={e => setNewEntry({...newEntry, teacherName: e.target.value})} />
                            <input className={`w-full p-3 rounded-xl outline-none ${themeClasses.accentBg} ${themeClasses.textMain}`} placeholder="Room No (Optional)" value={newEntry.roomNo} onChange={e => setNewEntry({...newEntry, roomNo: e.target.value})} />

                            <button onClick={handleAdd} className={`w-full py-3 rounded-xl text-white font-bold shadow-lg ${primaryColor}`}>Add to Routine</button>
                        </div>
                     </div>
                </div>, document.body
            )}
        </div>
    );
};

export default Routine;