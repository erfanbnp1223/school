

import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { collection, addDoc, query, orderBy, onSnapshot, deleteDoc, doc } from 'firebase/firestore';
import { db } from '../firebase';
import { uploadImageToImgBB } from '../services/imgbbService';
import { GalleryItem } from '../types';
import { Image, Plus, Trash2, ZoomIn, X, Loader2 } from 'lucide-react';
import { createPortal } from 'react-dom';

const Gallery: React.FC = () => {
    const { userProfile } = useAuth();
    const { themeClasses, primaryColor } = useTheme();
    const [images, setImages] = useState<GalleryItem[]>([]);
    const [filter, setFilter] = useState('All');
    
    // Upload State
    const [uploading, setUploading] = useState(false);
    const [file, setFile] = useState<File | null>(null);
    const [caption, setCaption] = useState('');
    const [category, setCategory] = useState<GalleryItem['category']>('Other');
    const [showUpload, setShowUpload] = useState(false);

    // Lightbox
    const [lightbox, setLightbox] = useState<string | null>(null);

    const canUpload = userProfile?.role === 'admin' || userProfile?.role === 'teacher';

    useEffect(() => {
        const q = query(collection(db, 'gallery'), orderBy('createdAt', 'desc'));
        const unsubscribe = onSnapshot(q, snap => {
            setImages(snap.docs.map(d => ({ id: d.id, ...d.data() } as GalleryItem)));
        });
        return unsubscribe;
    }, []);

    const handleUpload = async (e: React.FormEvent) => {
        e.preventDefault();
        if (file) {
            setUploading(true);
            try {
                const url = await uploadImageToImgBB(file);
                await addDoc(collection(db, 'gallery'), {
                    imageUrl: url,
                    caption,
                    category,
                    createdAt: Date.now()
                });
                setShowUpload(false);
                setFile(null); setCaption('');
            } catch (error) {
                console.error(error);
                alert("Upload failed");
            } finally {
                setUploading(false);
            }
        }
    };

    const handleDelete = async (id: string) => {
        if (confirm("Delete this photo?")) await deleteDoc(doc(db, 'gallery', id));
    };

    const filteredImages = filter === 'All' ? images : images.filter(i => i.category === filter);
    const categories = ['All', 'Sports', 'Cultural', 'Academic', 'Other'];

    return (
        <div className="space-y-6 pb-20">
            <div className="flex justify-between items-center">
                <h1 className={`text-2xl font-bold flex items-center gap-2 ${themeClasses.textMain}`}>
                    <Image className="text-pink-500" /> Photo Gallery
                </h1>
                {canUpload && (
                    <button onClick={() => setShowUpload(true)} className={`px-4 py-2 rounded-xl text-white font-bold flex items-center gap-2 shadow-lg ${primaryColor}`}>
                        <Plus size={18} /> Upload
                    </button>
                )}
            </div>

            {/* Filter Pills */}
            <div className="flex gap-2 overflow-x-auto pb-2">
                {categories.map(cat => (
                    <button
                        key={cat}
                        onClick={() => setFilter(cat)}
                        className={`px-4 py-1.5 rounded-full text-sm font-bold whitespace-nowrap transition-all ${
                            filter === cat 
                            ? `${primaryColor} text-white shadow-md` 
                            : `${themeClasses.cardBg} ${themeClasses.textSub} border ${themeClasses.border}`
                        }`}
                    >
                        {cat}
                    </button>
                ))}
            </div>

            {/* Masonry Grid */}
            <div className="columns-2 md:columns-3 gap-4 space-y-4">
                {filteredImages.map(img => (
                    <div key={img.id} className={`${themeClasses.cardBg} rounded-2xl overflow-hidden shadow-sm border ${themeClasses.border} break-inside-avoid relative group`}>
                        <img 
                            src={img.imageUrl} 
                            className="w-full object-cover cursor-pointer hover:scale-105 transition-transform duration-500"
                            onClick={() => setLightbox(img.imageUrl)}
                        />
                        <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity pointer-events-none flex flex-col justify-end p-4">
                            <p className="text-white font-bold text-sm">{img.caption}</p>
                            <span className="text-[10px] text-white/80 uppercase tracking-wider">{img.category}</span>
                        </div>
                        {canUpload && (
                            <button 
                                onClick={() => handleDelete(img.id)}
                                className="absolute top-2 right-2 bg-red-600 text-white p-1.5 rounded-full opacity-0 group-hover:opacity-100 transition-opacity"
                            >
                                <Trash2 size={12} />
                            </button>
                        )}
                    </div>
                ))}
            </div>
            {filteredImages.length === 0 && <div className="text-center p-10 text-gray-400">No photos found.</div>}

            {/* Upload Modal */}
            {showUpload && createPortal(
                <div className="fixed inset-0 z-[200] bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
                    <div className={`${themeClasses.cardBg} w-full max-w-md rounded-[2rem] p-6 animate-slide-in-up`}>
                        <div className="flex justify-between items-center mb-6">
                            <h2 className={`text-xl font-bold ${themeClasses.textMain}`}>Upload Photo</h2>
                            <button onClick={() => setShowUpload(false)}><X size={20} className="text-gray-500"/></button>
                        </div>
                        <form onSubmit={handleUpload} className="space-y-4">
                            <div className={`w-full h-40 rounded-2xl border-2 border-dashed flex items-center justify-center relative overflow-hidden ${file ? 'border-indigo-500' : 'border-gray-300'}`}>
                                {file ? (
                                    <img src={URL.createObjectURL(file)} className="w-full h-full object-cover" />
                                ) : (
                                    <div className="text-center text-gray-400">
                                        <Image className="mx-auto mb-2" />
                                        <span className="text-sm">Tap to select photo</span>
                                    </div>
                                )}
                                <input type="file" className="absolute inset-0 opacity-0 cursor-pointer" onChange={e => setFile(e.target.files?.[0] || null)} required accept="image/*" />
                            </div>
                            <input className={`w-full p-3 rounded-xl outline-none ${themeClasses.accentBg} ${themeClasses.textMain}`} placeholder="Caption" value={caption} onChange={e => setCaption(e.target.value)} required />
                            <select className={`w-full p-3 rounded-xl outline-none ${themeClasses.accentBg} ${themeClasses.textMain}`} value={category} onChange={e => setCategory(e.target.value as any)}>
                                <option value="Sports">Sports</option>
                                <option value="Cultural">Cultural</option>
                                <option value="Academic">Academic</option>
                                <option value="Other">Other</option>
                            </select>
                            <button type="submit" disabled={uploading} className={`w-full py-3 rounded-xl text-white font-bold shadow-lg flex justify-center items-center gap-2 ${primaryColor}`}>
                                {uploading ? <Loader2 className="animate-spin" size={20}/> : 'Upload'}
                            </button>
                        </form>
                    </div>
                </div>, document.body
            )}

            {/* Lightbox */}
            {lightbox && createPortal(
                <div className="fixed inset-0 z-[300] bg-black/95 flex items-center justify-center p-2" onClick={() => setLightbox(null)}>
                    <img src={lightbox} className="max-w-full max-h-[90vh] rounded-lg shadow-2xl" />
                    <button className="absolute top-4 right-4 text-white bg-white/10 p-2 rounded-full backdrop-blur-md"><X size={24}/></button>
                </div>, document.body
            )}
        </div>
    );
};

export default Gallery;