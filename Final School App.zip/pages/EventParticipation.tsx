import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { collection, addDoc, query, orderBy, onSnapshot, deleteDoc, doc, where, getDocs } from 'firebase/firestore';
import { db } from '../firebase';
import { EventName, EventParticipant, UserProfile } from '../types';
import { Trophy, Plus, Trash2, Users, Search, Calendar, ChevronRight, X, UserPlus, CheckCircle } from 'lucide-react';
import { createPortal } from 'react-dom';

const EventParticipation: React.FC = () => {
    const { userProfile } = useAuth();
    const { themeClasses, primaryColor, playSound } = useTheme();
    
    // Main Data
    const [events, setEvents] = useState<EventName[]>([]);
    const [participants, setParticipants] = useState<EventParticipant[]>([]);
    const [selectedEventId, setSelectedEventId] = useState<string | null>(null);

    // Modal States
    const [showCreateEvent, setShowCreateEvent] = useState(false);
    const [showAddParticipant, setShowAddParticipant] = useState(false);

    // Forms
    const [newEventTitle, setNewEventTitle] = useState('');
    const [newEventDate, setNewEventDate] = useState('');

    // Add Participant Logic
    const [selectedClass, setSelectedClass] = useState('6');
    const [studentsInClass, setStudentsInClass] = useState<UserProfile[]>([]);
    const [searchStudent, setSearchStudent] = useState('');

    const isTeacher = userProfile?.role === 'teacher' || userProfile?.role === 'admin';

    // 1. Load All Event Names
    useEffect(() => {
        const q = query(collection(db, 'event_names'), orderBy('date', 'desc'));
        const unsub = onSnapshot(q, snap => {
            const data = snap.docs.map(d => ({ id: d.id, ...d.data() } as EventName));
            setEvents(data);
            // Default select first event if none selected and data exists
            if (!selectedEventId && data.length > 0) {
                setSelectedEventId(data[0].id);
            }
        });
        return unsub;
    }, []);

    // 2. Load Participants for Selected Event
    useEffect(() => {
        if (!selectedEventId) {
            setParticipants([]);
            return;
        }
        const q = query(collection(db, 'event_participants'), where('eventId', '==', selectedEventId));
        const unsub = onSnapshot(q, snap => {
            setParticipants(snap.docs.map(d => ({ id: d.id, ...d.data() } as EventParticipant)));
        });
        return unsub;
    }, [selectedEventId]);

    // 3. Load Students when "Add Participant" modal is open & class changes
    useEffect(() => {
        if (!showAddParticipant) return;
        const fetchStudents = async () => {
            const q = query(
                collection(db, 'users'), 
                where('role', '==', 'student'), 
                where('className', '==', selectedClass)
            );
            const snap = await getDocs(q);
            setStudentsInClass(snap.docs.map(d => d.data() as UserProfile));
        };
        fetchStudents();
    }, [showAddParticipant, selectedClass]);

    // HANDLERS

    const handleCreateEvent = async (e: React.FormEvent) => {
        e.preventDefault();
        if(!newEventTitle) return;
        try {
            await addDoc(collection(db, 'event_names'), {
                title: newEventTitle,
                date: newEventDate || new Date().toISOString(),
                createdAt: Date.now()
            });
            setShowCreateEvent(false);
            setNewEventTitle(''); setNewEventDate('');
            playSound('success');
        } catch (e) { alert("Error creating event"); }
    };

    const handleDeleteEvent = async (id: string, e: React.MouseEvent) => {
        e.stopPropagation();
        if(confirm("Delete this event and all its participants?")) {
            await deleteDoc(doc(db, 'event_names', id));
            // Cleanup participants manually or via Cloud Function (Doing manual minimal here)
            // Real app should use batch delete
            if (selectedEventId === id) setSelectedEventId(null);
        }
    };

    const handleAddStudent = async (student: UserProfile) => {
        if (!selectedEventId) return;
        // Check if already added
        const exists = participants.find(p => p.studentId === student.uid);
        if (exists) return alert("Student already added to this event.");

        playSound('click');
        await addDoc(collection(db, 'event_participants'), {
            eventId: selectedEventId,
            studentId: student.uid,
            studentName: student.displayName,
            studentPhoto: student.photoURL,
            classGrade: student.className,
            rollNumber: student.rollNumber,
            addedAt: Date.now()
        });
    };

    const handleRemoveParticipant = async (id: string) => {
        if(confirm("Remove student from this event?")) {
            await deleteDoc(doc(db, 'event_participants', id));
        }
    };

    const filteredStudents = studentsInClass.filter(s => s.displayName.toLowerCase().includes(searchStudent.toLowerCase()));

    return (
        <div className="space-y-6 pb-20">
             <div className="flex justify-between items-center">
                <h1 className={`text-2xl font-bold flex items-center gap-2 ${themeClasses.textMain}`}>
                    <Trophy className="text-yellow-500" /> Event Participation
                </h1>
                {isTeacher && (
                    <button onClick={() => setShowCreateEvent(true)} className={`px-4 py-2 rounded-xl text-white font-bold flex items-center gap-2 shadow-lg ${primaryColor}`}>
                        <Plus size={18} /> New Event
                    </button>
                )}
            </div>

            {/* Event Selector (Horizontal Scroll) */}
            <div className="flex gap-3 overflow-x-auto pb-2 no-scrollbar">
                {events.map(ev => (
                    <button
                        key={ev.id}
                        onClick={() => setSelectedEventId(ev.id)}
                        className={`min-w-[160px] p-4 rounded-2xl border text-left transition-all relative group ${
                            selectedEventId === ev.id 
                            ? `${primaryColor} text-white shadow-lg border-transparent` 
                            : `${themeClasses.cardBg} ${themeClasses.textMain} border ${themeClasses.border} hover:border-gray-300`
                        }`}
                    >
                        <p className="font-bold truncate pr-4">{ev.title}</p>
                        <p className={`text-xs ${selectedEventId === ev.id ? 'text-white/80' : 'text-gray-400'}`}>
                            {new Date(ev.date).toLocaleDateString()}
                        </p>
                        {isTeacher && (
                            <div 
                                onClick={(e) => handleDeleteEvent(ev.id, e)} 
                                className="absolute top-2 right-2 p-1 bg-white/20 rounded-full opacity-0 group-hover:opacity-100 transition-opacity hover:bg-red-500 text-white"
                            >
                                <Trash2 size={12}/>
                            </div>
                        )}
                    </button>
                ))}
                {events.length === 0 && <div className="p-4 text-gray-400 text-sm">No events created yet.</div>}
            </div>

            {/* Active Event Details */}
            {selectedEventId && (
                <div className="animate-fade-in">
                    <div className="flex justify-between items-end mb-4">
                        <div>
                            <h2 className={`text-xl font-bold ${themeClasses.textMain}`}>Participants List</h2>
                            <p className="text-sm text-gray-400 font-medium">{participants.length} Students Participating</p>
                        </div>
                        {isTeacher && (
                            <button onClick={() => setShowAddParticipant(true)} className={`px-5 py-2.5 rounded-xl font-bold bg-white text-indigo-600 shadow-md border border-gray-100 hover:bg-gray-50 flex items-center gap-2`}>
                                <UserPlus size={18} /> Add Students
                            </button>
                        )}
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                        {participants.map(p => (
                            <div key={p.id} className={`${themeClasses.cardBg} p-4 rounded-3xl border ${themeClasses.border} shadow-sm flex items-center gap-4 relative group hover:shadow-md transition-all`}>
                                <img src={p.studentPhoto} className="w-14 h-14 rounded-full border-2 border-gray-100 object-cover" />
                                <div>
                                    <h3 className={`font-bold ${themeClasses.textMain}`}>{p.studentName}</h3>
                                    <div className="flex gap-2 text-xs font-bold text-gray-400 uppercase tracking-wide">
                                        <span className="bg-gray-100 px-2 py-0.5 rounded">Class {p.classGrade}</span>
                                        {p.rollNumber && <span className="bg-gray-100 px-2 py-0.5 rounded">Roll {p.rollNumber}</span>}
                                    </div>
                                </div>
                                {isTeacher && (
                                    <button 
                                        onClick={() => handleRemoveParticipant(p.id)}
                                        className="absolute top-4 right-4 text-gray-300 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"
                                    >
                                        <Trash2 size={18} />
                                    </button>
                                )}
                            </div>
                        ))}
                        {participants.length === 0 && (
                            <div className="col-span-full text-center py-20 opacity-50">
                                <Users size={64} className="mx-auto mb-4 text-gray-300" />
                                <p>No participants added yet.</p>
                            </div>
                        )}
                    </div>
                </div>
            )}

            {/* Create Event Modal */}
            {showCreateEvent && createPortal(
                <div className="fixed inset-0 z-[200] flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
                    <form onSubmit={handleCreateEvent} className={`${themeClasses.cardBg} w-full max-w-sm rounded-[2rem] p-6 shadow-2xl space-y-4 animate-slide-in-up border ${themeClasses.border}`}>
                         <h3 className={`font-bold text-lg ${themeClasses.textMain}`}>Create New Event</h3>
                         <input autoFocus placeholder="Event Name (e.g. Sports Day)" className={`w-full p-3 rounded-xl outline-none ${themeClasses.accentBg} ${themeClasses.textMain}`} value={newEventTitle} onChange={e => setNewEventTitle(e.target.value)} required />
                         <input type="date" className={`w-full p-3 rounded-xl outline-none ${themeClasses.accentBg} ${themeClasses.textMain}`} value={newEventDate} onChange={e => setNewEventDate(e.target.value)} required />
                         <div className="flex gap-3 pt-2">
                             <button type="button" onClick={() => setShowCreateEvent(false)} className="flex-1 py-3 rounded-xl font-bold bg-gray-100 text-gray-500">Cancel</button>
                             <button type="submit" className={`flex-1 py-3 rounded-xl text-white font-bold ${primaryColor}`}>Create</button>
                         </div>
                    </form>
                </div>, document.body
            )}

            {/* Add Student Modal */}
            {showAddParticipant && createPortal(
                <div className="fixed inset-0 z-[200] flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
                    <div className={`${themeClasses.cardBg} w-full max-w-lg max-h-[80vh] flex flex-col rounded-[2.5rem] shadow-2xl animate-slide-in-up border ${themeClasses.border}`}>
                         <div className="p-6 border-b border-gray-100 dark:border-slate-800 flex justify-between items-center">
                             <div>
                                 <h3 className={`font-bold text-lg ${themeClasses.textMain}`}>Add Participants</h3>
                                 <p className="text-xs text-gray-400 font-bold">Select Class & Student</p>
                             </div>
                             <button onClick={() => setShowAddParticipant(false)}><X className="text-gray-400"/></button>
                         </div>

                         <div className="p-4 flex gap-3 border-b border-gray-100 dark:border-slate-800 bg-gray-50/50 dark:bg-slate-800/50">
                             <select 
                                className={`p-3 rounded-xl outline-none font-bold ${themeClasses.cardBg} ${themeClasses.textMain} shadow-sm`} 
                                value={selectedClass} 
                                onChange={e => setSelectedClass(e.target.value)}
                             >
                                {[6,7,8,9,10].map(c => <option key={c} value={c}>Class {c}</option>)}
                             </select>
                             <div className={`flex-1 flex items-center px-3 rounded-xl ${themeClasses.cardBg} shadow-sm`}>
                                 <Search size={18} className="text-gray-400 mr-2"/>
                                 <input 
                                    className={`w-full bg-transparent outline-none py-3 ${themeClasses.textMain}`} 
                                    placeholder="Search student..."
                                    value={searchStudent}
                                    onChange={e => setSearchStudent(e.target.value)}
                                 />
                             </div>
                         </div>

                         <div className="flex-1 overflow-y-auto p-4 space-y-2">
                             {filteredStudents.map(s => {
                                 const isAdded = participants.some(p => p.studentId === s.uid);
                                 return (
                                     <div key={s.uid} className={`p-3 rounded-2xl flex items-center justify-between border ${isAdded ? 'bg-green-50 border-green-200' : `${themeClasses.cardBg} border-transparent hover:bg-gray-50 dark:hover:bg-slate-800`}`}>
                                         <div className="flex items-center gap-3">
                                             <img src={s.photoURL} className="w-10 h-10 rounded-full object-cover bg-gray-200" />
                                             <div>
                                                 <p className={`font-bold text-sm ${themeClasses.textMain}`}>{s.displayName}</p>
                                                 <p className="text-xs text-gray-400 font-bold">Roll: {s.rollNumber || 'N/A'}</p>
                                             </div>
                                         </div>
                                         {isAdded ? (
                                             <CheckCircle className="text-green-500" size={20} />
                                         ) : (
                                             <button onClick={() => handleAddStudent(s)} className={`px-4 py-1.5 rounded-full text-xs font-bold text-white shadow-sm ${primaryColor}`}>
                                                 Add
                                             </button>
                                         )}
                                     </div>
                                 )
                             })}
                             {filteredStudents.length === 0 && <div className="text-center p-8 text-gray-400">No students found in Class {selectedClass}</div>}
                         </div>
                    </div>
                </div>, document.body
            )}

        </div>
    );
};

export default EventParticipation;