

import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { collection, addDoc, query, orderBy, onSnapshot, updateDoc, doc } from 'firebase/firestore';
import { db } from '../firebase';
import { Complaint } from '../types';
import { AlertTriangle, Send, Shield, Eye, EyeOff, CheckCircle } from 'lucide-react';

const ComplaintBox: React.FC = () => {
    const { userProfile } = useAuth();
    const { themeClasses, primaryColor, playSound } = useTheme();
    const [complaints, setComplaints] = useState<Complaint[]>([]);
    const [title, setTitle] = useState('');
    const [description, setDescription] = useState('');
    const [isAnonymous, setIsAnonymous] = useState(false);
    const [submitting, setSubmitting] = useState(false);

    const isAdmin = userProfile?.role === 'admin';

    // Only Admin can see all complaints. Users only see input (for privacy) or their own? 
    // Usually complaint boxes are private. Only admin sees list.
    useEffect(() => {
        if (!isAdmin) return;
        const q = query(collection(db, 'complaints'), orderBy('submittedAt', 'desc'));
        const unsubscribe = onSnapshot(q, snap => {
            setComplaints(snap.docs.map(d => ({ id: d.id, ...d.data() } as Complaint)));
        });
        return unsubscribe;
    }, [isAdmin]);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!userProfile) return;
        setSubmitting(true);
        playSound('click');
        try {
            await addDoc(collection(db, 'complaints'), {
                title,
                description,
                isAnonymous,
                submittedBy: userProfile.uid,
                submittedByName: isAnonymous ? 'Anonymous' : userProfile.displayName,
                submittedAt: Date.now(),
                status: 'pending'
            });
            setTitle('');
            setDescription('');
            setIsAnonymous(false);
            alert("Complaint submitted securely.");
        } catch (error) {
            console.error(error);
            alert("Submission failed.");
        } finally {
            setSubmitting(false);
        }
    };

    const markResolved = async (id: string) => {
        if (confirm("Mark this issue as resolved?")) {
            await updateDoc(doc(db, 'complaints', id), { status: 'resolved' });
        }
    };

    return (
        <div className="space-y-6 pb-20">
             <div className="flex justify-between items-center">
                <h1 className={`text-2xl font-bold flex items-center gap-2 ${themeClasses.textMain}`}>
                    <AlertTriangle className="text-red-500" /> Complaint Box
                </h1>
            </div>

            {/* Submission Form */}
            {!isAdmin && (
                <div className={`${themeClasses.cardBg} p-6 rounded-[2rem] shadow-lg border ${themeClasses.border} animate-fade-in`}>
                     <div className="flex items-center gap-3 mb-6 bg-yellow-50 p-4 rounded-xl border border-yellow-100">
                         <Shield className="text-yellow-600" size={24} />
                         <p className="text-xs text-yellow-700 font-bold">Your privacy is priority. You can choose to remain anonymous.</p>
                     </div>

                     <form onSubmit={handleSubmit} className="space-y-4">
                         <input required placeholder="Issue Subject" className={`w-full p-4 rounded-xl outline-none ${themeClasses.accentBg} ${themeClasses.textMain}`} value={title} onChange={e => setTitle(e.target.value)} />
                         <textarea required placeholder="Describe your complaint in detail..." className={`w-full p-4 rounded-xl outline-none h-32 resize-none ${themeClasses.accentBg} ${themeClasses.textMain}`} value={description} onChange={e => setDescription(e.target.value)} />
                         
                         <div className="flex justify-between items-center py-2">
                             <div 
                                onClick={() => setIsAnonymous(!isAnonymous)}
                                className={`flex items-center gap-2 cursor-pointer select-none px-4 py-2 rounded-full transition-colors ${isAnonymous ? 'bg-indigo-100 text-indigo-700' : 'bg-gray-100 text-gray-500'}`}
                             >
                                 {isAnonymous ? <EyeOff size={18} /> : <Eye size={18} />}
                                 <span className="text-sm font-bold">{isAnonymous ? 'Submit Anonymously' : 'Show My Name'}</span>
                             </div>
                             
                             <button type="submit" disabled={submitting} className={`px-6 py-3 rounded-xl text-white font-bold shadow-lg flex items-center gap-2 ${primaryColor} ${submitting ? 'opacity-50' : ''}`}>
                                 <Send size={18} /> Submit
                             </button>
                         </div>
                     </form>
                </div>
            )}

            {/* Admin View */}
            {isAdmin && (
                <div className="space-y-4">
                    {complaints.map(c => (
                        <div key={c.id} className={`${themeClasses.cardBg} p-5 rounded-3xl border ${themeClasses.border} shadow-sm relative`}>
                            <div className="flex justify-between items-start mb-2">
                                <h3 className={`font-bold text-lg ${themeClasses.textMain}`}>{c.title}</h3>
                                <div className="flex gap-2">
                                    <span className={`px-2 py-1 rounded text-[10px] font-bold uppercase tracking-wider ${c.status === 'resolved' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>{c.status}</span>
                                    {c.status === 'pending' && (
                                        <button onClick={() => markResolved(c.id)} className="p-1 bg-green-100 text-green-600 rounded-full hover:bg-green-200"><CheckCircle size={16}/></button>
                                    )}
                                </div>
                            </div>
                            
                            <p className={`text-sm mb-4 leading-relaxed ${themeClasses.textMain} opacity-90`}>{c.description}</p>
                            
                            <div className="flex items-center gap-2 text-xs font-bold text-gray-400 border-t pt-3 border-gray-100 dark:border-slate-800">
                                <span className="bg-gray-100 dark:bg-slate-700 px-2 py-0.5 rounded text-gray-600 dark:text-gray-300">
                                    From: {c.submittedByName}
                                </span>
                                <span>• {new Date(c.submittedAt).toLocaleDateString()}</span>
                            </div>
                        </div>
                    ))}
                    {complaints.length === 0 && <div className="text-center p-10 text-gray-400">No complaints received.</div>}
                </div>
            )}
        </div>
    );
};

export default ComplaintBox;