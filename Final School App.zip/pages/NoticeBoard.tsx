
import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { collection, addDoc, query, orderBy, onSnapshot, doc, updateDoc, arrayRemove, arrayUnion, deleteDoc, where } from 'firebase/firestore';
import { db } from '../firebase';
import { uploadImageToImgBB } from '../services/imgbbService';
import { Notice, POST_BACKGROUNDS, SUPER_ADMINS, Comment } from '../types';
import { Bell, Plus, Heart, MessageCircle, X, Image as ImageIcon, Trash2, Send, MoreHorizontal, ZoomIn, ZoomOut, Megaphone } from 'lucide-react';
import { createPortal } from 'react-dom';

const NoticeCommentsDrawer: React.FC<{ noticeId: string, onClose: () => void }> = ({ noticeId, onClose }) => {
    const { userProfile } = useAuth();
    const { themeClasses } = useTheme();
    const [comments, setComments] = useState<Comment[]>([]);
    const [newComment, setNewComment] = useState('');

    useEffect(() => {
        const q = query(collection(db, 'notice_comments'), where('noticeId', '==', noticeId));
        const unsub = onSnapshot(q, snap => {
            const data = snap.docs.map(d => ({ id: d.id, ...d.data() } as Comment));
            data.sort((a, b) => a.timestamp - b.timestamp);
            setComments(data);
        });
        return unsub;
    }, [noticeId]);

    const handleSend = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!newComment.trim() || !userProfile) return;
        await addDoc(collection(db, 'notice_comments'), {
            noticeId, userId: userProfile.uid, userName: userProfile.displayName, userPhoto: userProfile.photoURL,
            text: newComment, timestamp: Date.now()
        });
        setNewComment('');
    };

    const handleDelete = async (id: string) => {
        if(window.confirm("Delete this comment permanently?")) {
            try {
                await deleteDoc(doc(db, 'notice_comments', id));
            } catch (error: any) {
                console.error("Delete failed", error);
                alert(`Delete failed: ${error.message}`);
            }
        }
    };

    // Use Portal to fix Z-Index issues
    return createPortal(
        <div className="fixed inset-0 z-[100] flex flex-col justify-end md:justify-center md:items-center">
             <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose}></div>
             <div className={`${themeClasses.cardBg} w-full md:w-[500px] md:h-[600px] h-[85%] rounded-t-[2.5rem] md:rounded-3xl shadow-2xl z-10 flex flex-col relative animate-slide-in-up border-t border-white/20`}>
                <div className={`p-4 border-b ${themeClasses.border} flex justify-between items-center`}>
                    <h3 className={`font-bold ${themeClasses.textMain}`}>Comments</h3>
                    <button onClick={onClose} className={`p-2 rounded-full ${themeClasses.accentBg}`}><X size={18} /></button>
                </div>
                <div className="flex-1 overflow-y-auto p-4 space-y-4">
                    {comments.length === 0 && <div className="text-center text-gray-400 py-10">No comments yet.</div>}
                    {comments.map(c => {
                        const canDelete = userProfile?.uid === c.userId || userProfile?.role === 'admin' || SUPER_ADMINS.includes(userProfile?.email || '');
                        return (
                            <div key={c.id} className="flex gap-3">
                                <img src={c.userPhoto} className="w-8 h-8 rounded-full border border-gray-200" />
                                <div className="flex-1">
                                    <div className={`${themeClasses.accentBg} p-3 rounded-2xl rounded-tl-none inline-block`}>
                                        <p className={`font-bold text-sm ${themeClasses.textMain}`}>{c.userName}</p>
                                        <p className={`text-sm ${themeClasses.textSub}`}>{c.text}</p>
                                    </div>
                                    {canDelete && 
                                        <button onClick={() => handleDelete(c.id)} className="text-xs text-red-500 ml-2 mt-1 font-bold uppercase tracking-wide">Delete</button>
                                    }
                                </div>
                            </div>
                        )
                    })}
                </div>
                <form onSubmit={handleSend} className={`p-4 border-t ${themeClasses.border} flex gap-2`}>
                    <input className={`flex-1 rounded-full px-5 py-3 outline-none shadow-inner ${themeClasses.accentBg} ${themeClasses.textMain}`} placeholder="Write a comment..." value={newComment} onChange={e => setNewComment(e.target.value)} />
                    <button type="submit" className="bg-indigo-600 text-white p-3 rounded-full shadow-lg"><Send size={18} /></button>
                </form>
             </div>
        </div>,
        document.body
    );
}

const NoticeBoard: React.FC = () => {
    const { userProfile } = useAuth();
    const { themeClasses, primaryColor, playSound } = useTheme();
    const [notices, setNotices] = useState<Notice[]>([]);
    const [showCreate, setShowCreate] = useState(false);
    
    const [title, setTitle] = useState('');
    const [content, setContent] = useState('');
    const [bg, setBg] = useState(POST_BACKGROUNDS[0]);
    const [file, setFile] = useState<File | null>(null);
    const [loading, setLoading] = useState(false);
    
    const [activeNoticeId, setActiveNoticeId] = useState<string | null>(null);
    const [lightbox, setLightbox] = useState<string | null>(null);
    const [zoom, setZoom] = useState(1);
    const [openMenuId, setOpenMenuId] = useState<string | null>(null);

    useEffect(() => {
        const q = query(collection(db, 'notices'), orderBy('date', 'desc'));
        const unsubscribe = onSnapshot(q, snap => {
            setNotices(snap.docs.map(d => ({ id: d.id, ...d.data() } as Notice)));
        });
        return unsubscribe;
    }, []);

    const handlePost = async () => {
        setLoading(true);
        try {
            let imageUrl = '';
            if (file) imageUrl = await uploadImageToImgBB(file);
            await addDoc(collection(db, 'notices'), {
                title, content, imageUrl, background: !file ? bg : '',
                date: new Date().toISOString(), type: 'general',
                postedBy: userProfile?.displayName || 'Admin',
                postedById: userProfile?.uid,
                likes: []
            });
            setShowCreate(false); setTitle(''); setContent(''); setBg(POST_BACKGROUNDS[0]); setFile(null);
        } catch (e) { console.error(e); } finally { setLoading(false); }
    };

    const handleDelete = async (id: string, e: React.MouseEvent) => { 
        e.preventDefault();
        e.stopPropagation();
        setOpenMenuId(null);
        if(window.confirm("Delete this notice permanently?")) {
             try {
                await deleteDoc(doc(db, 'notices', id)); 
                playSound('click');
             } catch(e: any) { 
                 alert(`Error: ${e.message}`); 
             }
        }
    }

    const toggleLike = async (n: Notice, e: React.MouseEvent) => {
        e.stopPropagation();
        if(!userProfile) return;
        playSound('click');
        const ref = doc(db, 'notices', n.id);
        const uid = userProfile.uid;
        const isLiked = n.likes?.includes(uid);
        if (isLiked) await updateDoc(ref, { likes: arrayRemove(uid) });
        else await updateDoc(ref, { likes: arrayUnion(uid) });
    };

    const isAdmin = userProfile?.role === 'admin' || SUPER_ADMINS.includes(userProfile?.email || '');
    const isTeacher = userProfile?.role === 'teacher';

    return (
        <div className="space-y-6 pb-24" onClick={() => setOpenMenuId(null)}>
            {lightbox && createPortal(
                <div className="fixed inset-0 bg-black/95 z-[200] flex flex-col justify-center items-center" onClick={() => setLightbox(null)}>
                    <button className="absolute top-4 right-4 text-white p-2 bg-white/10 rounded-full backdrop-blur-md"><X size={24} /></button>
                    <img src={lightbox} style={{ transform: `scale(${zoom})` }} className="max-w-full max-h-[80vh] transition-transform" onClick={e => e.stopPropagation()} />
                    <div className="absolute bottom-10 flex gap-4" onClick={e => e.stopPropagation()}>
                        <button onClick={() => setZoom(Math.max(1, zoom - 0.5))} className="p-4 bg-white/20 rounded-full text-white backdrop-blur-md"><ZoomOut /></button>
                        <button onClick={() => setZoom(Math.min(3, zoom + 0.5))} className="p-4 bg-white/20 rounded-full text-white backdrop-blur-md"><ZoomIn /></button>
                    </div>
                </div>, document.body
            )}

            <div className="flex justify-between items-center sticky top-0 z-10 py-2 backdrop-blur-sm">
                <h1 className={`text-2xl font-bold flex items-center gap-2 ${themeClasses.textMain}`}><Megaphone className="text-pink-500"/> Notices</h1>
                {(isAdmin || isTeacher) && (
                    <button onClick={() => setShowCreate(true)} className={`px-5 py-2.5 rounded-full text-white font-bold flex items-center gap-2 shadow-lg hover:scale-105 transition-transform ${primaryColor}`}>
                        <Plus size={20} /> Create
                    </button>
                )}
            </div>

            {/* Create Modal */}
            {showCreate && createPortal(
                <div className={`fixed inset-0 z-[100] ${themeClasses.cardBg} flex flex-col animate-fade-in`}>
                     <div className={`p-4 flex justify-between items-center border-b ${themeClasses.border}`}>
                        <button onClick={() => setShowCreate(false)} className={`p-2 rounded-full ${themeClasses.accentBg}`}><X className={themeClasses.textMain}/></button>
                        <h2 className={`font-bold ${themeClasses.textMain}`}>New Notice</h2>
                        <button onClick={handlePost} disabled={loading} className={`px-6 py-2 rounded-full font-bold text-white shadow-lg ${primaryColor}`}>{loading ? 'Posting...' : 'Publish'}</button>
                    </div>
                    <div className="p-4 space-y-4 max-w-2xl mx-auto w-full">
                        <input className={`w-full text-2xl font-bold bg-transparent outline-none p-4 ${themeClasses.textMain}`} placeholder="Notice Headline" value={title} onChange={e => setTitle(e.target.value)} />
                        
                        <div className={`w-full h-72 rounded-3xl flex items-center justify-center p-8 text-center relative overflow-hidden shadow-inner ${!file ? bg : 'bg-gray-100'}`}>
                            {file ? (
                                <>
                                    <img src={URL.createObjectURL(file)} className="w-full h-full object-contain" />
                                    <button onClick={() => setFile(null)} className="absolute top-4 right-4 bg-black/50 text-white p-2 rounded-full backdrop-blur-md"><X size={16}/></button>
                                </>
                            ) : (
                                <textarea className={`w-full h-full bg-transparent border-none outline-none text-center resize-none text-xl font-bold ${bg.includes('white') ? 'text-black' : 'text-white'}`} placeholder="What is this announcement about?" value={content} onChange={e => setContent(e.target.value)} />
                            )}
                        </div>

                        {!file && (
                           <div className="flex gap-3 overflow-x-auto pb-2">
                               {POST_BACKGROUNDS.map(b => <button key={b} onClick={() => setBg(b)} className={`w-10 h-10 rounded-full border-2 transition-transform hover:scale-110 ${b} ${bg===b ? 'border-black scale-110' : 'border-transparent'}`} />)}
                           </div>
                        )}
                        <label className={`flex items-center gap-3 font-bold cursor-pointer p-4 rounded-2xl hover:bg-gray-50 dark:hover:bg-slate-800 transition-colors ${themeClasses.textMain}`}>
                            <div className="p-3 bg-pink-100 text-pink-600 rounded-full"><ImageIcon size={24} /></div>
                            <span>Attach Image</span>
                            <input type="file" className="hidden" onChange={e => { setFile(e.target.files?.[0] || null); setBg('bg-white'); }} />
                        </label>
                    </div>
                </div>, document.body
            )}

            <div className="max-w-xl mx-auto space-y-6">
                {notices.map(notice => {
                    const isLiked = userProfile?.uid ? notice.likes?.includes(userProfile.uid) : false;
                    const canDelete = isAdmin || notice.postedById === userProfile?.uid;
                    
                    return (
                        <div key={notice.id} className={`rounded-3xl shadow-sm overflow-hidden border relative ${themeClasses.cardBg} ${themeClasses.border}`}>
                             <div className="p-4 flex justify-between items-center">
                                 <div className="flex items-center gap-3">
                                     <div className={`w-10 h-10 rounded-full flex items-center justify-center text-white font-bold shadow-md ${primaryColor}`}>
                                         {notice.postedBy[0]}
                                     </div>
                                     <div>
                                         <h3 className={`font-bold text-base leading-none mb-1 ${themeClasses.textMain}`}>{notice.title}</h3>
                                         <p className={`text-[10px] font-medium uppercase tracking-wide opacity-60 ${themeClasses.textSub}`}>{new Date(notice.date).toDateString()} • {notice.postedBy}</p>
                                     </div>
                                 </div>
                                 {canDelete && (
                                     <div className="relative">
                                         <button onClick={(e) => { e.stopPropagation(); setOpenMenuId(openMenuId === notice.id ? null : notice.id); }} className="p-2 text-gray-400 hover:bg-gray-100 rounded-full">
                                             <MoreHorizontal size={18} />
                                         </button>
                                         {openMenuId === notice.id && (
                                            <div className={`absolute right-0 top-full mt-2 shadow-2xl rounded-xl p-2 z-20 w-40 border animate-fade-in-up ${themeClasses.cardBg} ${themeClasses.border}`}>
                                                <button onClick={(e) => handleDelete(notice.id, e)} className="w-full text-left px-4 py-3 text-red-500 hover:bg-red-50 rounded-lg text-sm flex items-center gap-2 font-bold">
                                                    <Trash2 size={16} /> Delete
                                                </button>
                                            </div>
                                         )}
                                     </div>
                                 )}
                             </div>

                             <div className="px-4 pb-2">
                                <p className={`text-sm mb-3 leading-relaxed ${themeClasses.textMain}`}>{notice.content}</p>
                                
                                {notice.imageUrl ? (
                                    <div className="rounded-xl overflow-hidden bg-black/5 border dark:border-slate-700 cursor-pointer relative group" onClick={() => { setLightbox(notice.imageUrl!); setZoom(1); }}>
                                        <img src={notice.imageUrl} className="w-full max-h-80 object-cover" />
                                        <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                                            <ZoomIn className="text-white drop-shadow-lg" size={48} />
                                        </div>
                                    </div>
                                ) : (
                                    notice.background && (
                                        <div className={`p-6 text-center font-bold text-lg rounded-xl shadow-inner ${notice.background || 'bg-white text-gray-800'}`}>
                                            {notice.content}
                                        </div>
                                    )
                                )}
                             </div>

                             <div className="p-3 border-t border-gray-100 dark:border-slate-700 flex gap-4">
                                 <button onClick={(e) => toggleLike(notice, e)} className={`flex items-center gap-2 transition-transform active:scale-90 ${isLiked ? 'text-pink-500' : 'text-gray-400'}`}>
                                     <Heart fill={isLiked ? "currentColor" : "none"} size={22} strokeWidth={isLiked ? 0 : 2} /> 
                                     <span className="font-bold text-xs">{notice.likes?.length || 0}</span>
                                 </button>
                                 <button onClick={() => setActiveNoticeId(notice.id)} className="flex items-center gap-2 text-gray-400 hover:text-indigo-500 transition-colors">
                                     <MessageCircle size={22} />
                                 </button>
                             </div>
                        </div>
                    );
                })}
                {notices.length === 0 && <div className="text-center py-20 text-gray-400">No notices posted yet.</div>}
            </div>
            
            {activeNoticeId && <NoticeCommentsDrawer noticeId={activeNoticeId} onClose={() => setActiveNoticeId(null)} />}
        </div>
    );
};

export default NoticeBoard;
