
import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { collection, addDoc, query, where, onSnapshot, updateDoc, doc, orderBy, getDocs } from 'firebase/firestore';
import { db } from '../firebase';
import { Meeting, UserProfile } from '../types';
import { Clock, Calendar, CheckCircle, XCircle, User, Plus, AlertTriangle } from 'lucide-react';
import { createPortal } from 'react-dom';

const MeetingScheduler: React.FC = () => {
    const { userProfile } = useAuth();
    const { themeClasses, primaryColor, playSound } = useTheme();
    const [meetings, setMeetings] = useState<Meeting[]>([]);
    const [teachers, setTeachers] = useState<UserProfile[]>([]);
    const [showForm, setShowForm] = useState(false);
    
    // Form State
    const [selectedTeacherId, setSelectedTeacherId] = useState('');
    const [date, setDate] = useState('');
    const [timeSlot, setTimeSlot] = useState('');
    const [purpose, setPurpose] = useState('');

    const isTeacher = userProfile?.role === 'teacher';
    const isAdmin = userProfile?.role === 'admin';

    // Fetch Teachers for dropdown
    useEffect(() => {
        const fetchTeachers = async () => {
            const q = query(collection(db, 'users'), where('role', '==', 'teacher'));
            const snap = await getDocs(q);
            setTeachers(snap.docs.map(d => ({ uid: d.id, ...d.data() } as UserProfile)));
        };
        fetchTeachers();
    }, []);

    // Fetch Meetings (Client-side sorting to avoid Index Errors)
    useEffect(() => {
        if (!userProfile) return;

        let q;
        if (isTeacher) {
            // Teacher sees requests for them
            q = query(collection(db, 'meetings'), where('teacherId', '==', userProfile.uid));
        } else if (isAdmin) {
             // Admin sees all (Can use orderBy here safely usually, but sticking to client sort for consistency)
             q = query(collection(db, 'meetings'));
        } else {
            // Parent/Student sees their own requests
            q = query(collection(db, 'meetings'), where('studentId', '==', userProfile.uid));
        }

        const unsubscribe = onSnapshot(q, snap => {
            const data = snap.docs.map(d => ({ id: d.id, ...d.data() } as Meeting));
            // Sort by createdAt descending (newest first) in JavaScript
            data.sort((a, b) => b.createdAt - a.createdAt);
            setMeetings(data);
        });
        return unsubscribe;
    }, [userProfile, isTeacher, isAdmin]);

    const handleRequest = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!userProfile || !selectedTeacherId) return;
        playSound('click');

        const teacher = teachers.find(t => t.uid === selectedTeacherId);

        try {
            await addDoc(collection(db, 'meetings'), {
                teacherId: selectedTeacherId,
                teacherName: teacher?.displayName || 'Unknown Teacher',
                studentId: userProfile.uid,
                studentName: userProfile.linkedStudentName || userProfile.displayName,
                requesterName: userProfile.displayName,
                date,
                timeSlot,
                purpose,
                status: 'pending',
                createdAt: Date.now()
            });
            setShowForm(false);
            setPurpose(''); setDate(''); setTimeSlot(''); setSelectedTeacherId('');
            alert("Meeting request sent successfully!");
        } catch (error) {
            console.error("Error booking meeting:", error);
            alert("Failed to book meeting.");
        }
    };

    const handleStatus = async (id: string, status: 'approved' | 'rejected') => {
        playSound('click');
        try {
            await updateDoc(doc(db, 'meetings', id), { status });
        } catch (error) {
            alert("Action failed.");
        }
    };

    return (
        <div className="space-y-6 pb-20">
             <div className="flex justify-between items-center">
                <h1 className={`text-2xl font-bold flex items-center gap-2 ${themeClasses.textMain}`}>
                    <Clock className="text-orange-500" /> Meeting Scheduler
                </h1>
                {!isTeacher && !isAdmin && (
                    <button onClick={() => setShowForm(true)} className={`px-4 py-2.5 rounded-xl text-white font-bold flex items-center gap-2 shadow-lg ${primaryColor}`}>
                        <Plus size={18} /> Book Meeting
                    </button>
                )}
            </div>

            {/* Form Modal */}
            {showForm && createPortal(
                <div className="fixed inset-0 z-[200] flex items-center justify-center bg-black/60 backdrop-blur-sm px-4">
                    <div className={`${themeClasses.cardBg} w-full max-w-md rounded-[2rem] p-6 animate-slide-in-up shadow-2xl relative border ${themeClasses.border}`}>
                        <button onClick={() => setShowForm(false)} className="absolute top-4 right-4 p-2 bg-gray-100 rounded-full hover:bg-gray-200"><XCircle size={20}/></button>
                        <h2 className={`text-xl font-bold mb-6 ${themeClasses.textMain}`}>Request Meeting</h2>
                        
                        <form onSubmit={handleRequest} className="space-y-4">
                            <div>
                                <label className={`text-xs font-bold uppercase mb-1 block ${themeClasses.textSub}`}>Select Teacher</label>
                                <select required className={`w-full p-3 rounded-xl outline-none ${themeClasses.accentBg} ${themeClasses.textMain}`} value={selectedTeacherId} onChange={e => setSelectedTeacherId(e.target.value)}>
                                    <option value="">-- Choose Teacher --</option>
                                    {teachers.map(t => (
                                        <option key={t.uid} value={t.uid}>{t.displayName} ({t.subject})</option>
                                    ))}
                                </select>
                            </div>
                            <div className="grid grid-cols-2 gap-3">
                                <div>
                                    <label className={`text-xs font-bold uppercase mb-1 block ${themeClasses.textSub}`}>Date</label>
                                    <input type="date" required className={`w-full p-3 rounded-xl outline-none ${themeClasses.accentBg} ${themeClasses.textMain}`} value={date} onChange={e => setDate(e.target.value)} />
                                </div>
                                <div>
                                    <label className={`text-xs font-bold uppercase mb-1 block ${themeClasses.textSub}`}>Time</label>
                                    <input type="time" required className={`w-full p-3 rounded-xl outline-none ${themeClasses.accentBg} ${themeClasses.textMain}`} value={timeSlot} onChange={e => setTimeSlot(e.target.value)} />
                                </div>
                            </div>
                            <div>
                                <label className={`text-xs font-bold uppercase mb-1 block ${themeClasses.textSub}`}>Reason</label>
                                <textarea required placeholder="Discuss academic progress..." className={`w-full p-3 rounded-xl outline-none h-24 resize-none ${themeClasses.accentBg} ${themeClasses.textMain}`} value={purpose} onChange={e => setPurpose(e.target.value)} />
                            </div>
                            <button type="submit" className={`w-full py-3 rounded-xl text-white font-bold shadow-lg ${primaryColor}`}>Send Request</button>
                        </form>
                    </div>
                </div>, document.body
            )}

            {/* List */}
            <div className="space-y-4">
                {meetings.map(meeting => (
                    <div key={meeting.id} className={`${themeClasses.cardBg} p-5 rounded-3xl border ${themeClasses.border} shadow-sm relative group`}>
                         <div className="flex justify-between items-start mb-2">
                             <div>
                                 <h3 className={`font-bold text-lg ${themeClasses.textMain}`}>
                                     {isTeacher ? meeting.requesterName : meeting.teacherName}
                                 </h3>
                                 <div className="flex items-center gap-2 mt-1">
                                     <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-gray-100 text-gray-600`}>
                                         Student: {meeting.studentName}
                                     </span>
                                     <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider ${
                                         meeting.status === 'approved' ? 'bg-green-100 text-green-700' : 
                                         meeting.status === 'rejected' ? 'bg-red-100 text-red-700' : 'bg-yellow-100 text-yellow-700'
                                     }`}>{meeting.status}</span>
                                 </div>
                             </div>
                             {(isTeacher || isAdmin) && meeting.status === 'pending' && (
                                 <div className="flex gap-2">
                                     <button onClick={() => handleStatus(meeting.id, 'approved')} className="p-2 bg-green-100 text-green-600 rounded-full hover:bg-green-200 shadow-sm"><CheckCircle size={18}/></button>
                                     <button onClick={() => handleStatus(meeting.id, 'rejected')} className="p-2 bg-red-100 text-red-600 rounded-full hover:bg-red-200 shadow-sm"><XCircle size={18}/></button>
                                 </div>
                             )}
                         </div>
                         
                         <p className={`text-sm italic mb-3 opacity-80 ${themeClasses.textMain}`}>"{meeting.purpose}"</p>

                         <div className="flex items-center gap-4 text-xs font-bold text-gray-400 border-t pt-3 border-gray-100 dark:border-slate-800">
                             <div className="flex items-center gap-1"><Calendar size={14}/> {meeting.date}</div>
                             <div className="flex items-center gap-1"><Clock size={14}/> {meeting.timeSlot}</div>
                         </div>
                    </div>
                ))}
                {meetings.length === 0 && <div className="text-center p-10 text-gray-400">No meetings scheduled.</div>}
            </div>
        </div>
    );
};

export default MeetingScheduler;
