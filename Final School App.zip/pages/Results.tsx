
import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { collection, addDoc, query, orderBy, onSnapshot } from 'firebase/firestore';
import { db } from '../firebase';
import { ExamResult } from '../types';
import { GraduationCap, Plus, TrendingUp, Award, BookOpen } from 'lucide-react';
import { createPortal } from 'react-dom';

const Results: React.FC = () => {
    const { userProfile } = useAuth();
    const { themeClasses, primaryColor } = useTheme();
    const [results, setResults] = useState<ExamResult[]>([]);
    const [showForm, setShowForm] = useState(false);
    const [formData, setFormData] = useState({
        studentName: '', subject: '', marks: '', total: '100', examName: ''
    });

    useEffect(() => {
        const q = query(collection(db, 'results'), orderBy('examName'));
        const unsubscribe = onSnapshot(q, snap => {
            setResults(snap.docs.map(d => ({ id: d.id, ...d.data() } as ExamResult)));
        });
        return unsubscribe;
    }, []);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        await addDoc(collection(db, 'results'), {
            ...formData,
            studentId: 'manual', 
            marks: formData.marks,
            totalMarks: formData.total
        });
        setShowForm(false);
        setFormData({ studentName: '', subject: '', marks: '', total: '100', examName: '' });
    };

    const getGrade = (marks: number, total: number) => {
        const pct = (marks / total) * 100;
        if (pct >= 80) return { grade: 'A+', color: 'text-green-500', bg: 'bg-green-100' };
        if (pct >= 70) return { grade: 'A', color: 'text-emerald-500', bg: 'bg-emerald-100' };
        if (pct >= 60) return { grade: 'A-', color: 'text-teal-500', bg: 'bg-teal-100' };
        if (pct >= 50) return { grade: 'B', color: 'text-yellow-500', bg: 'bg-yellow-100' };
        if (pct >= 40) return { grade: 'C', color: 'text-orange-500', bg: 'bg-orange-100' };
        if (pct >= 33) return { grade: 'D', color: 'text-red-400', bg: 'bg-red-100' };
        return { grade: 'F', color: 'text-red-600', bg: 'bg-red-200' };
    };

    return (
        <div className="space-y-6 pb-24">
            <div className="flex justify-between items-center">
                <h1 className={`text-2xl font-bold flex items-center gap-2 ${themeClasses.textMain}`}>
                    <GraduationCap className="text-orange-500" /> Exam Results
                </h1>
                {(userProfile?.role === 'teacher' || userProfile?.role === 'admin') && (
                    <button onClick={() => setShowForm(!showForm)} className={`px-4 py-2 rounded-xl text-white font-bold flex items-center gap-2 shadow-lg ${primaryColor}`}>
                        <Plus size={18} /> Publish Result
                    </button>
                )}
            </div>

            {showForm && createPortal(
                <div className="fixed inset-0 z-[200] flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
                     <form onSubmit={handleSubmit} className={`${themeClasses.cardBg} w-full max-w-md p-6 rounded-[2rem] shadow-2xl space-y-4 animate-slide-in-up border ${themeClasses.border}`}>
                        <h3 className={`font-bold text-xl ${themeClasses.textMain}`}>Publish Result</h3>
                        <input placeholder="Student Name" required className={`w-full p-3 rounded-xl outline-none ${themeClasses.accentBg} ${themeClasses.textMain}`} value={formData.studentName} onChange={e => setFormData({...formData, studentName: e.target.value})} />
                        <input placeholder="Exam Name (e.g. Mid Term)" required className={`w-full p-3 rounded-xl outline-none ${themeClasses.accentBg} ${themeClasses.textMain}`} value={formData.examName} onChange={e => setFormData({...formData, examName: e.target.value})} />
                        <input placeholder="Subject" required className={`w-full p-3 rounded-xl outline-none ${themeClasses.accentBg} ${themeClasses.textMain}`} value={formData.subject} onChange={e => setFormData({...formData, subject: e.target.value})} />
                        <div className="flex gap-4">
                            <input placeholder="Marks" required type="number" className={`flex-1 p-3 rounded-xl outline-none ${themeClasses.accentBg} ${themeClasses.textMain}`} value={formData.marks} onChange={e => setFormData({...formData, marks: e.target.value})} />
                            <input placeholder="Total" required type="number" className={`flex-1 p-3 rounded-xl outline-none ${themeClasses.accentBg} ${themeClasses.textMain}`} value={formData.total} onChange={e => setFormData({...formData, total: e.target.value})} />
                        </div>
                        <div className="flex gap-3 pt-2">
                             <button type="button" onClick={() => setShowForm(false)} className="flex-1 py-3 rounded-xl font-bold bg-gray-100 text-gray-500">Cancel</button>
                             <button type="submit" className={`flex-1 py-3 rounded-xl text-white font-bold ${primaryColor}`}>Publish</button>
                        </div>
                    </form>
                </div>, document.body
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {results.map(res => {
                    const gradeInfo = getGrade(Number(res.marks), Number(res.totalMarks));
                    return (
                        <div key={res.id} className={`${themeClasses.cardBg} p-6 rounded-[2rem] shadow-sm border ${themeClasses.border} relative overflow-hidden group hover:shadow-lg transition-all`}>
                            {/* Grade Background Badge */}
                            <div className={`absolute -right-6 -top-6 w-24 h-24 rounded-full ${gradeInfo.bg} opacity-50`}></div>
                            
                            <div className="relative z-10 flex justify-between items-start">
                                <div>
                                    <div className="flex items-center gap-2 mb-2">
                                        <div className="p-2 rounded-full bg-indigo-50 text-indigo-600"><BookOpen size={16}/></div>
                                        <span className={`text-xs font-bold uppercase tracking-widest ${themeClasses.textSub}`}>{res.examName}</span>
                                    </div>
                                    <h3 className={`text-xl font-black ${themeClasses.textMain}`}>{res.subject}</h3>
                                    <p className={`text-sm ${themeClasses.textSub} font-medium mt-1`}>{res.studentName}</p>
                                </div>
                                <div className="text-right">
                                     <div className={`text-4xl font-black ${gradeInfo.color}`}>{gradeInfo.grade}</div>
                                     <p className="text-[10px] font-bold uppercase opacity-50 text-gray-500">Grade</p>
                                </div>
                            </div>

                            <div className="mt-6 flex items-end justify-between">
                                 <div>
                                     <p className="text-xs font-bold text-gray-400 uppercase mb-1">Score Achieved</p>
                                     <p className={`text-2xl font-bold ${themeClasses.textMain}`}>{res.marks} <span className="text-sm opacity-50 font-normal">/ {res.totalMarks}</span></p>
                                 </div>
                                 <div className="h-2 w-24 bg-gray-100 rounded-full overflow-hidden">
                                     <div className={`h-full ${gradeInfo.bg.replace('bg-', 'bg-')} ${gradeInfo.color.replace('text-', 'bg-')}`} style={{ width: `${(Number(res.marks)/Number(res.totalMarks))*100}%` }}></div>
                                 </div>
                            </div>
                        </div>
                    );
                })}
                {results.length === 0 && <div className="col-span-full text-center p-12 text-gray-400">No results published yet.</div>}
            </div>
        </div>
    );
};

export default Results;
