
import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { collection, query, where, getDocs, addDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../firebase';
import { UserProfile } from '../types';
import { ClipboardList, CheckCircle, XCircle, User, Calendar } from 'lucide-react';

const Attendance: React.FC = () => {
    const { userProfile } = useAuth();
    const { themeClasses, primaryColor } = useTheme();
    const [students, setStudents] = useState<UserProfile[]>([]);
    
    useEffect(() => {
        const fetchStudents = async () => {
            const q = query(collection(db, 'users'), where('role', '==', 'student'));
            const snap = await getDocs(q);
            setStudents(snap.docs.map(d => d.data() as UserProfile));
        };
        fetchStudents();
    }, []);

    const markAttendance = async (studentId: string, status: 'present' | 'absent') => {
        try {
            await addDoc(collection(db, 'attendance'), {
                studentId,
                date: new Date().toLocaleDateString(),
                status,
                markedBy: userProfile?.uid,
                timestamp: serverTimestamp()
            });
            alert(`Marked ${status}`);
        } catch (error) {
            console.error(error);
        }
    };

    if (userProfile?.role === 'student') {
        return (
            <div className="flex flex-col items-center justify-center h-[60vh] text-center">
                <div className="bg-green-100 text-green-600 p-8 rounded-full mb-6">
                    <ClipboardList size={64} />
                </div>
                <h2 className={`text-2xl font-bold ${themeClasses.textMain}`}>My Attendance</h2>
                <p className={`${themeClasses.textSub} mt-2 max-w-xs`}>Your daily attendance is automatically tracked by your teachers.</p>
                <div className="mt-8 bg-white dark:bg-slate-800 p-6 rounded-2xl shadow-sm border border-gray-100 dark:border-slate-700">
                    <span className="text-4xl font-bold text-green-500">92%</span>
                    <p className="text-sm font-bold text-gray-400 uppercase tracking-wider mt-1">Presence Rate</p>
                </div>
            </div>
        );
    }

    return (
        <div className="space-y-6 pb-20">
            <h1 className={`text-2xl font-bold flex items-center gap-2 ${themeClasses.textMain}`}>
                <ClipboardList className="text-indigo-500" /> Attendance Register
            </h1>
            
            <div className={`${themeClasses.cardBg} rounded-3xl shadow-sm overflow-hidden border ${themeClasses.border}`}>
                <div className={`p-6 border-b ${themeClasses.border} flex justify-between items-center bg-gray-50 dark:bg-slate-800/50`}>
                    <div className="flex items-center gap-2 font-bold text-gray-500">
                        <Calendar size={18} /> {new Date().toLocaleDateString(undefined, {weekday:'long', year:'numeric', month:'long', day:'numeric'})}
                    </div>
                </div>
                
                <div className="divide-y divide-gray-100 dark:divide-slate-800">
                    {students.map(student => (
                        <div key={student.uid} className="p-4 flex items-center justify-between hover:bg-gray-50 dark:hover:bg-slate-800/50 transition-colors">
                            <div className="flex items-center gap-4">
                                <div className="w-12 h-12 rounded-full overflow-hidden border border-gray-200">
                                    <img src={student.photoURL} alt="" className="w-full h-full object-cover" />
                                </div>
                                <div>
                                    <p className={`font-bold text-base ${themeClasses.textMain}`}>{student.displayName}</p>
                                    <p className="text-xs text-gray-400">Class {student.className} • Roll {student.rollNumber}</p>
                                </div>
                            </div>
                            <div className="flex gap-3">
                                <button onClick={() => markAttendance(student.uid, 'present')} className="w-10 h-10 flex items-center justify-center text-green-500 bg-green-50 hover:bg-green-100 rounded-full transition-colors border border-green-200">
                                    <CheckCircle size={20} />
                                </button>
                                <button onClick={() => markAttendance(student.uid, 'absent')} className="w-10 h-10 flex items-center justify-center text-red-500 bg-red-50 hover:bg-red-100 rounded-full transition-colors border border-red-200">
                                    <XCircle size={20} />
                                </button>
                            </div>
                        </div>
                    ))}
                    {students.length === 0 && <p className="p-10 text-center text-gray-400">No students found in database.</p>}
                </div>
            </div>
        </div>
    );
};

export default Attendance;
