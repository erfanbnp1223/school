

import React, { useState, useEffect } from 'react';
import { collection, query, where, onSnapshot } from 'firebase/firestore';
import { db } from '../firebase';
import { UserProfile } from '../types';
import { useTheme } from '../contexts/ThemeContext';
import { Briefcase, User, Mail, Star, Heart, GraduationCap, BookOpen, X, Phone } from 'lucide-react';
import { createPortal } from 'react-dom';

const Teachers: React.FC = () => {
    const { themeClasses, primaryColor, theme } = useTheme();
    const [teachers, setTeachers] = useState<UserProfile[]>([]);
    const [loading, setLoading] = useState(true);
    const [selectedTeacher, setSelectedTeacher] = useState<UserProfile | null>(null);

    useEffect(() => {
        const q = query(collection(db, 'users'), where('role', '==', 'teacher'));
        const unsubscribe = onSnapshot(q, (snapshot) => {
            setTeachers(snapshot.docs.map(doc => ({ uid: doc.id, ...doc.data() } as UserProfile)));
            setLoading(false);
        });
        return unsubscribe;
    }, []);

    return (
        <div className="space-y-6">
            <h1 className={`text-2xl font-bold flex items-center gap-2 ${themeClasses.textMain}`}>
                <Briefcase className="text-primary" /> Teachers
            </h1>
            
            {loading && <div className="text-center p-10">Loading teachers...</div>}

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6 pb-24">
                {teachers.map(teacher => (
                    <div 
                        key={teacher.uid} 
                        onClick={() => setSelectedTeacher(teacher)}
                        className={`${themeClasses.cardBg} rounded-3xl p-6 shadow-sm border ${themeClasses.border} flex flex-col items-center text-center relative overflow-hidden group hover:shadow-md transition-shadow cursor-pointer`}
                    >
                        <div className={`absolute top-0 left-0 w-full h-24 ${primaryColor} opacity-10`}></div>
                        
                        <img 
                            src={teacher.photoURL} 
                            alt={teacher.displayName} 
                            className={`w-24 h-24 rounded-full object-cover mb-4 border-4 shadow-sm z-10 ${theme === 'dark' ? 'border-slate-700' : 'border-white'}`}
                        />
                        
                        <h3 className={`font-bold text-lg z-10 ${themeClasses.textMain}`}>{teacher.displayName}</h3>
                        <span className="text-sm text-indigo-500 font-medium z-10 mb-4">{teacher.subject || 'General Teacher'}</span>

                        <div className="w-full space-y-3 z-10">
                            <div className={`flex items-center gap-3 p-3 rounded-xl ${themeClasses.accentBg}`}>
                                <Star size={18} className="text-yellow-500" />
                                <div className="text-left">
                                    <p className={`text-xs ${themeClasses.textSub} uppercase font-bold`}>Experience</p>
                                    <p className={`text-sm font-semibold ${themeClasses.textMain}`}>{teacher.experience || 'N/A'}</p>
                                </div>
                            </div>
                        </div>
                    </div>
                ))}
                {!loading && teachers.length === 0 && (
                    <div className="col-span-full text-center p-10 text-gray-400">No teachers found.</div>
                )}
            </div>

            {/* Teacher Details Modal */}
            {selectedTeacher && createPortal(
                <div className="fixed inset-0 z-[300] flex items-center justify-center bg-black/60 backdrop-blur-md p-4" onClick={() => setSelectedTeacher(null)}>
                    <div className={`${themeClasses.cardBg} w-full max-w-lg rounded-[2.5rem] p-6 relative animate-slide-in-up shadow-2xl flex flex-col max-h-[90vh]`} onClick={e => e.stopPropagation()}>
                        
                        <div className="flex justify-between items-center mb-4">
                             <h2 className={`text-xl font-bold ${themeClasses.textMain}`}>Teacher Profile</h2>
                             <button onClick={() => setSelectedTeacher(null)} className="p-2 bg-gray-100 dark:bg-slate-700 rounded-full text-gray-500 hover:text-gray-800">
                                <X size={20} />
                            </button>
                        </div>
                        
                        <div className="overflow-y-auto no-scrollbar pb-6 space-y-6">
                            <div className="text-center">
                                <img src={selectedTeacher.photoURL} className="w-32 h-32 rounded-full mx-auto mb-4 border-4 border-indigo-50 dark:border-slate-700 shadow-md object-cover" />
                                <h2 className={`text-2xl font-bold ${themeClasses.textMain}`}>{selectedTeacher.displayName}</h2>
                                <p className="text-indigo-500 font-bold">{selectedTeacher.subject || 'Teacher'}</p>
                            </div>

                            {/* Bio / Life Story */}
                            <div className={`p-5 rounded-2xl ${themeClasses.accentBg} relative overflow-hidden`}>
                                <div className="absolute top-0 right-0 p-8 text-indigo-500/10"><Heart size={64}/></div>
                                <h3 className={`font-bold mb-2 flex items-center gap-2 ${themeClasses.textMain}`}><Heart size={16} className="text-pink-500"/> About Me</h3>
                                <p className={`text-sm leading-relaxed ${themeClasses.textMain} opacity-80 italic`}>
                                    "{selectedTeacher.bio || "Passionate about teaching and guiding students to achieve their best."}"
                                </p>
                            </div>

                            <div className="grid grid-cols-2 gap-4">
                                <div className={`p-4 rounded-2xl ${themeClasses.accentBg}`}>
                                    <div className="flex items-center gap-2 mb-1">
                                        <GraduationCap size={16} className="text-blue-500"/>
                                        <span className={`text-xs font-bold uppercase ${themeClasses.textSub}`}>Education</span>
                                    </div>
                                    <p className={`font-semibold ${themeClasses.textMain} text-sm`}>{selectedTeacher.education || 'N/A'}</p>
                                </div>
                                <div className={`p-4 rounded-2xl ${themeClasses.accentBg}`}>
                                    <div className="flex items-center gap-2 mb-1">
                                        <Star size={16} className="text-yellow-500"/>
                                        <span className={`text-xs font-bold uppercase ${themeClasses.textSub}`}>Experience</span>
                                    </div>
                                    <p className={`font-semibold ${themeClasses.textMain} text-sm`}>{selectedTeacher.experience || 'N/A'}</p>
                                </div>
                            </div>

                            <div className="space-y-3">
                                <div className={`flex items-center gap-4 p-3 rounded-xl border ${themeClasses.border}`}>
                                    <div className="p-2 bg-green-100 text-green-600 rounded-full"><Mail size={18}/></div>
                                    <div>
                                        <p className={`text-xs font-bold uppercase ${themeClasses.textSub}`}>Email</p>
                                        <p className={`text-sm font-semibold ${themeClasses.textMain}`}>{selectedTeacher.email}</p>
                                    </div>
                                </div>
                                {selectedTeacher.phone && (
                                    <div className={`flex items-center gap-4 p-3 rounded-xl border ${themeClasses.border}`}>
                                        <div className="p-2 bg-blue-100 text-blue-600 rounded-full"><Phone size={18}/></div>
                                        <div>
                                            <p className={`text-xs font-bold uppercase ${themeClasses.textSub}`}>Phone</p>
                                            <p className={`text-sm font-semibold ${themeClasses.textMain}`}>{selectedTeacher.phone}</p>
                                        </div>
                                    </div>
                                )}
                            </div>
                        </div>
                    </div>
                </div>, document.body
            )}
        </div>
    );
};

export default Teachers;