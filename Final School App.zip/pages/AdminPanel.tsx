
import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { SUPER_ADMINS, HIDDEN_ADMIN_EMAIL, UserProfile, TeacherCode, RoutineItem, ExamResult, Fee, Notice, Book, VideoLesson, GalleryItem, SchoolEvent, Meeting, Complaint, LeaveRequest } from '../types';
import { useNavigate } from 'react-router-dom';
import { 
  Users, LayoutDashboard, Search, Trash2, 
  Shield, Key, LogOut, Calendar, GraduationCap, CreditCard, Bell, Edit2, Check, Plus, ArrowLeft, Menu, X, BookOpen, Layers, Video, Image, Clock, AlertTriangle, FileText, Settings, DollarSign
} from 'lucide-react';
import { collection, onSnapshot, deleteDoc, doc, addDoc, updateDoc } from 'firebase/firestore';
import { db, auth } from '../firebase';

const AdminPanel: React.FC = () => {
  const { userProfile, loading: authLoading } = useAuth();
  const { playSound, themeClasses, primaryColor, theme } = useTheme();
  const navigate = useNavigate();
  
  // Navigation State
  const [activeTab, setActiveTab] = useState('dashboard');
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  
  // Data States
  const [users, setUsers] = useState<UserProfile[]>([]);
  const [teacherCodes, setTeacherCodes] = useState<TeacherCode[]>([]);
  const [routines, setRoutines] = useState<RoutineItem[]>([]);
  const [results, setResults] = useState<ExamResult[]>([]);
  const [fees, setFees] = useState<Fee[]>([]);
  const [notices, setNotices] = useState<Notice[]>([]);
  
  // New Data States
  const [books, setBooks] = useState<Book[]>([]);
  const [videos, setVideos] = useState<VideoLesson[]>([]);
  const [gallery, setGallery] = useState<GalleryItem[]>([]);
  const [events, setEvents] = useState<SchoolEvent[]>([]);
  const [meetings, setMeetings] = useState<Meeting[]>([]);
  const [complaints, setComplaints] = useState<Complaint[]>([]);
  const [leaves, setLeaves] = useState<LeaveRequest[]>([]);
  
  // Processing States
  const [processing, setProcessing] = useState(false);

  // Forms & Filters
  const [userSearch, setUserSearch] = useState('');
  const [newTeacherName, setNewTeacherName] = useState('');
  const [feeForm, setFeeForm] = useState({ studentId: '', amount: '', month: '', type: 'Tuition' as Fee['type'] });

  // Monthly Fee Setting
  const [editingFeeUser, setEditingFeeUser] = useState<string | null>(null);
  const [newMonthlyFee, setNewMonthlyFee] = useState('');
  const [globalFee, setGlobalFee] = useState('');

  // Security Check
  useEffect(() => {
    if (!authLoading) {
        const email = userProfile?.email;
        if (!email || !SUPER_ADMINS.includes(email)) {
            navigate('/');
        }
    }
  }, [userProfile, authLoading, navigate]);

  // Data Listeners
  useEffect(() => {
    const unsubUsers = onSnapshot(collection(db, 'users'), snap => setUsers(snap.docs.map(d => ({ uid: d.id, ...d.data() } as UserProfile))));
    const unsubCodes = onSnapshot(collection(db, 'teacher_codes'), snap => setTeacherCodes(snap.docs.map(d => ({ id: d.id, ...d.data() } as TeacherCode))));
    const unsubRoutines = onSnapshot(collection(db, 'routines'), snap => setRoutines(snap.docs.map(d => ({ id: d.id, ...d.data() } as RoutineItem))));
    const unsubResults = onSnapshot(collection(db, 'results'), snap => setResults(snap.docs.map(d => ({ id: d.id, ...d.data() } as ExamResult))));
    const unsubFees = onSnapshot(collection(db, 'fees'), snap => setFees(snap.docs.map(d => ({ id: d.id, ...d.data() } as Fee))));
    const unsubNotices = onSnapshot(collection(db, 'notices'), snap => setNotices(snap.docs.map(d => ({ id: d.id, ...d.data() } as Notice))));
    
    // New Listeners
    const unsubBooks = onSnapshot(collection(db, 'library'), snap => setBooks(snap.docs.map(d => ({ id: d.id, ...d.data() } as Book))));
    const unsubVideos = onSnapshot(collection(db, 'videos'), snap => setVideos(snap.docs.map(d => ({ id: d.id, ...d.data() } as VideoLesson))));
    const unsubGallery = onSnapshot(collection(db, 'gallery'), snap => setGallery(snap.docs.map(d => ({ id: d.id, ...d.data() } as GalleryItem))));
    const unsubEvents = onSnapshot(collection(db, 'events'), snap => setEvents(snap.docs.map(d => ({ id: d.id, ...d.data() } as SchoolEvent))));
    const unsubMeetings = onSnapshot(collection(db, 'meetings'), snap => setMeetings(snap.docs.map(d => ({ id: d.id, ...d.data() } as Meeting))));
    const unsubComplaints = onSnapshot(collection(db, 'complaints'), snap => setComplaints(snap.docs.map(d => ({ id: d.id, ...d.data() } as Complaint))));
    const unsubLeaves = onSnapshot(collection(db, 'leave_requests'), snap => setLeaves(snap.docs.map(d => ({ id: d.id, ...d.data() } as LeaveRequest))));

    return () => { 
        unsubUsers(); unsubCodes(); unsubRoutines(); unsubResults(); unsubFees(); unsubNotices();
        unsubBooks(); unsubVideos(); unsubGallery(); unsubEvents(); unsubMeetings(); unsubComplaints(); unsubLeaves();
    };
  }, []);

  // --- ACTIONS ---

  const handleLogout = async () => {
      if(window.confirm("Are you sure you want to logout from Admin Panel?")) {
          playSound('click');
          setProcessing(true);
          try {
            await auth.signOut();
            navigate('/login');
          } catch (e) {
            console.error(e);
            alert("Logout failed");
            setProcessing(false);
          }
      }
  };

  const deleteItem = async (col: string, id: string, e?: React.MouseEvent) => {
      if (e) {
          e.preventDefault();
          e.stopPropagation();
      }
      playSound('click');
      if (window.confirm("Are you sure you want to delete this item? This cannot be undone.")) {
        setProcessing(true);
        try {
            await deleteDoc(doc(db, col, id));
            // playSound('success'); // Optional: Success sound
        } catch (e: any) {
            console.error("Error deleting:", e);
            alert(`Delete failed: ${e.message}`);
        } finally {
            setProcessing(false);
        }
      }
  };

  const generateTeacherCode = async () => {
      playSound('click');
      if (!newTeacherName) return alert("Enter Teacher Name");
      const code = 'TCH-' + Math.random().toString(36).substring(2, 8).toUpperCase();
      await addDoc(collection(db, 'teacher_codes'), { code, assignedToName: newTeacherName, isUsed: false, createdAt: Date.now() });
      setNewTeacherName('');
  };

  const handleAssignFee = async () => {
      if(!feeForm.studentId || !feeForm.amount) return;
      const student = users.find(u => u.uid === feeForm.studentId);
      await addDoc(collection(db, 'fees'), {
          ...feeForm, studentName: student?.displayName || 'Unknown', status: 'due', date: new Date().toISOString()
      });
      alert("Fee Assigned");
      setFeeForm({ ...feeForm, amount: '' });
  };

  const handleSetMonthlyFee = async (uid: string) => {
      if(!newMonthlyFee) return;
      await updateDoc(doc(db, 'users', uid), { monthlyFee: Number(newMonthlyFee) });
      setEditingFeeUser(null);
      setNewMonthlyFee('');
      alert("Student fee updated");
  };

  const handleBulkUpdateFee = async () => {
      if (!globalFee) return;
      if (!window.confirm(`Are you sure you want to set the Monthly Fee to ৳${globalFee} for ALL ${studentsOnly.length} students?`)) return;
      
      setProcessing(true);
      try {
          const batchPromises = studentsOnly.map(student => 
              updateDoc(doc(db, 'users', student.uid), { monthlyFee: Number(globalFee) })
          );
          await Promise.all(batchPromises);
          alert(`Successfully updated fee for ${studentsOnly.length} students.`);
          setGlobalFee('');
      } catch (e) {
          console.error(e);
          alert("Failed to update.");
      } finally {
          setProcessing(false);
      }
  };

  if (authLoading) return null;

  // Filter Data
  const displayUsers = users.filter(u => u.email !== HIDDEN_ADMIN_EMAIL);
  const filteredUsers = displayUsers.filter(u => (u.displayName || '').toLowerCase().includes(userSearch.toLowerCase()));
  const studentsOnly = users.filter(u => u.role === 'student');

  const tabs = [
    { id: 'dashboard', label: 'Overview', icon: <LayoutDashboard size={20} /> },
    { id: 'users', label: 'Users', icon: <Users size={20} /> },
    { id: 'fees', label: 'Fees', icon: <CreditCard size={20} /> },
    { id: 'codes', label: 'Codes', icon: <Key size={20} /> },
    { id: 'notices', label: 'Notices', icon: <Bell size={20} /> },
    { id: 'routines', label: 'Routines', icon: <Calendar size={20} /> },
    { id: 'results', label: 'Results', icon: <GraduationCap size={20} /> },
    // New Tabs
    { id: 'library', label: 'Library', icon: <BookOpen size={20} /> },
    { id: 'videos', label: 'Videos', icon: <Video size={20} /> },
    { id: 'gallery', label: 'Gallery', icon: <Image size={20} /> },
    { id: 'events', label: 'Events', icon: <Calendar size={20} /> },
    { id: 'meetings', label: 'Meetings', icon: <Clock size={20} /> },
    { id: 'complaints', label: 'Complaints', icon: <AlertTriangle size={20} /> },
    { id: 'leaves', label: 'Leaves', icon: <FileText size={20} /> },
  ];

  const TableHeader = ({ cols }: { cols: string[] }) => (
      <thead className={`${themeClasses.accentBg} ${themeClasses.textSub} uppercase text-xs`}>
        <tr>
            {cols.map(c => <th key={c} className="p-5">{c}</th>)}
        </tr>
      </thead>
  );

  return (
    <div className={`flex h-screen overflow-hidden ${themeClasses.mainBg} text-gray-800 font-sans`}>
        
        {/* Mobile Menu Backdrop */}
        {mobileMenuOpen && (
            <div className="fixed inset-0 bg-black/50 z-40 md:hidden backdrop-blur-sm" onClick={() => setMobileMenuOpen(false)}></div>
        )}

        {/* Sidebar (PC & Mobile) */}
        <aside className={`fixed md:relative z-50 w-64 h-full transform transition-transform duration-300 ease-in-out ${mobileMenuOpen ? 'translate-x-0' : '-translate-x-full'} md:translate-x-0 flex flex-col border-r ${themeClasses.cardBg} ${themeClasses.border}`}>
            <div className="p-6 flex items-center gap-3">
                <div className={`w-10 h-10 rounded-xl flex items-center justify-center text-white shadow-lg ${primaryColor}`}>
                    <Shield size={20} />
                </div>
                <div className="flex flex-col">
                    <span className={`font-bold text-lg leading-tight ${themeClasses.textMain}`}>Admin Panel</span>
                    <span className="text-[10px] uppercase font-bold text-gray-400">School Manager</span>
                </div>
            </div>

            <nav className="flex-1 px-4 py-4 space-y-1 overflow-y-auto no-scrollbar">
                {tabs.map(tab => (
                    <button 
                        key={tab.id} 
                        onClick={() => { playSound('click'); setActiveTab(tab.id); setMobileMenuOpen(false); }}
                        className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl transition-all font-medium ${
                            activeTab === tab.id 
                                ? `${primaryColor} text-white shadow-md transform scale-[1.02]` 
                                : `${themeClasses.textSub} hover:bg-gray-100 dark:hover:bg-slate-800`
                        }`}
                    >
                        {tab.icon} <span>{tab.label}</span>
                    </button>
                ))}
            </nav>

            <div className="p-4 border-t border-gray-100 dark:border-slate-800">
                <button onClick={() => navigate('/')} className={`w-full flex items-center gap-3 px-4 py-3 rounded-xl ${themeClasses.textMain} hover:bg-gray-100 dark:hover:bg-slate-800 transition-all mb-2`}>
                    <ArrowLeft size={18} /> <span>Back to App</span>
                </button>
                <button onClick={handleLogout} className="w-full flex items-center gap-3 px-4 py-3 rounded-xl text-red-500 bg-red-50 dark:bg-red-900/20 hover:bg-red-100 transition-all font-bold">
                    <LogOut size={18} /> <span>Log Out</span>
                </button>
            </div>
        </aside>

        {/* Main Content */}
        <div className="flex-1 flex flex-col h-full overflow-hidden relative">
            {/* Header */}
            <header className={`${themeClasses.cardBg} border-b ${themeClasses.border} p-4 flex justify-between items-center z-10 sticky top-0`}>
                <div className="flex items-center gap-4">
                    <button onClick={() => setMobileMenuOpen(true)} className="md:hidden p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-slate-800">
                        <Menu className={themeClasses.textMain} />
                    </button>
                    <h2 className={`text-xl font-bold capitalize ${themeClasses.textMain}`}>{activeTab}</h2>
                </div>
                <div className="flex items-center gap-3">
                    <div className="hidden md:flex flex-col items-end">
                        <span className={`text-sm font-bold ${themeClasses.textMain}`}>{userProfile?.displayName}</span>
                        <span className="text-xs text-green-500 font-bold bg-green-100 px-2 rounded-full">Super Admin</span>
                    </div>
                    <img src={userProfile?.photoURL} className="w-10 h-10 rounded-full border-2 border-gray-200" alt="Admin" />
                </div>
            </header>

            {/* Scrollable Content Area */}
            <div className="flex-1 overflow-y-auto p-4 md:p-8 space-y-6 relative">
                
                {processing && (
                    <div className="absolute inset-0 bg-white/50 dark:bg-black/50 backdrop-blur-sm z-[100] flex items-center justify-center">
                        <div className={`${themeClasses.cardBg} px-6 py-4 rounded-full shadow-2xl flex items-center gap-3 font-bold ${themeClasses.textMain}`}>
                            <div className="w-5 h-5 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
                            Processing...
                        </div>
                    </div>
                )}

                {/* --- DASHBOARD --- */}
                {activeTab === 'dashboard' && (
                    <div className="space-y-8 animate-fade-in">
                        {/* Stats Grid */}
                        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-3 gap-4 md:gap-6">
                            {[
                                { label: 'Students', val: studentsOnly.length, icon: <Users className="text-white" size={24} />, bg: 'bg-gradient-to-br from-blue-500 to-indigo-600' },
                                { label: 'Teachers', val: users.filter(u => u.role === 'teacher').length, icon: <Shield className="text-white" size={24} />, bg: 'bg-gradient-to-br from-purple-500 to-pink-600' },
                                { label: 'Notices', val: notices.length, icon: <Bell className="text-white" size={24} />, bg: 'bg-gradient-to-br from-orange-400 to-red-500' },
                                { label: 'Revenue', val: `৳${fees.filter(f => f.status === 'due').reduce((a, b) => a + Number(b.amount), 0)}`, icon: <CreditCard className="text-white" size={24} />, bg: 'bg-gradient-to-br from-emerald-400 to-green-600' },
                                { label: 'Library Books', val: books.length, icon: <BookOpen className="text-white" size={24} />, bg: 'bg-gradient-to-br from-cyan-400 to-blue-500' },
                                { label: 'Complaints', val: complaints.length, icon: <AlertTriangle className="text-white" size={24} />, bg: 'bg-gradient-to-br from-rose-400 to-pink-500' }
                            ].map((stat, i) => (
                                <div key={i} className={`rounded-3xl p-6 shadow-lg text-white relative overflow-hidden group ${stat.bg}`}>
                                    <div className="absolute top-0 right-0 p-4 opacity-10 group-hover:scale-110 transition-transform">{stat.icon}</div>
                                    <div className="relative z-10">
                                        <div className="w-10 h-10 rounded-xl bg-white/20 backdrop-blur-sm flex items-center justify-center mb-3">
                                            {stat.icon}
                                        </div>
                                        <h3 className="text-3xl font-bold mb-1">{stat.val}</h3>
                                        <p className="text-xs font-medium uppercase tracking-wider opacity-80">{stat.label}</p>
                                    </div>
                                </div>
                            ))}
                        </div>
                    </div>
                )}

                {/* --- USERS MGMT --- */}
                {activeTab === 'users' && (
                    <div className="space-y-6 animate-fade-in">
                        <div className={`${themeClasses.cardBg} p-4 rounded-2xl flex items-center border ${themeClasses.border} shadow-sm`}>
                            <Search className="ml-2 text-gray-400" size={20} />
                            <input value={userSearch} onChange={e => setUserSearch(e.target.value)} placeholder="Search students, teachers..." className={`bg-transparent border-none focus:ring-0 w-full p-2 outline-none ${themeClasses.textMain}`} />
                        </div>
                        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
                            {filteredUsers.map(u => (
                                <div key={u.uid} className={`${themeClasses.cardBg} p-5 rounded-3xl border ${themeClasses.border} shadow-sm flex flex-col gap-3 relative group hover:shadow-md transition-all`}>
                                    <div className="flex items-center gap-4">
                                        <img src={u.photoURL} className="w-14 h-14 rounded-full bg-gray-200 border-2 border-gray-100 object-cover" />
                                        <div>
                                            <h4 className={`font-bold text-lg ${themeClasses.textMain}`}>{u.displayName}</h4>
                                            <p className={`text-xs ${themeClasses.textSub}`}>{u.email}</p>
                                            <div className="flex gap-2 mt-1">
                                                 <span className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded-md ${u.role === 'teacher' ? 'bg-purple-100 text-purple-600' : 'bg-blue-100 text-blue-600'}`}>{u.role}</span>
                                                 {u.className && <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded-md bg-gray-100 text-gray-600">Class {u.className}</span>}
                                            </div>
                                        </div>
                                    </div>

                                    {/* Monthly Fee Control */}
                                    {u.role === 'student' && (
                                        <div className={`mt-2 ${themeClasses.accentBg} p-3 rounded-xl text-xs`}>
                                            <div className="flex justify-between items-center">
                                                <span className={`${themeClasses.textSub}`}>Monthly Fee: <strong className={`${themeClasses.textMain}`}>৳{u['monthlyFee'] || 0}</strong></span>
                                                <button onClick={() => setEditingFeeUser(u.uid)} className="text-indigo-500 bg-white p-1 rounded-full shadow-sm"><Edit2 size={12}/></button>
                                            </div>
                                            {editingFeeUser === u.uid && (
                                                <div className="flex gap-2 mt-2">
                                                    <input type="number" placeholder="Amt" className="w-full rounded px-2 py-1 outline-none text-black" value={newMonthlyFee} onChange={e => setNewMonthlyFee(e.target.value)} />
                                                    <button onClick={() => handleSetMonthlyFee(u.uid)} className="bg-indigo-600 text-white p-1 rounded"><Check size={12} /></button>
                                                </div>
                                            )}
                                        </div>
                                    )}

                                    <button 
                                        onClick={(e) => deleteItem('users', u.uid, e)} 
                                        className="absolute top-4 right-4 p-2 text-gray-300 hover:text-red-500 hover:bg-red-50 rounded-full transition-all"
                                        title="Delete User"
                                    >
                                        <Trash2 size={18} />
                                    </button>
                                </div>
                            ))}
                        </div>
                    </div>
                )}

                {/* --- NOTICES MGMT --- */}
                {activeTab === 'notices' && (
                    <div className={`${themeClasses.cardBg} rounded-3xl border ${themeClasses.border} overflow-hidden shadow-sm animate-fade-in`}>
                        <div className="overflow-x-auto">
                            <table className="w-full text-left text-sm">
                                <TableHeader cols={['Title', 'Posted By', 'Date', 'Action']} />
                                <tbody className={`divide-y ${theme === 'dark' ? 'divide-slate-700' : 'divide-gray-100'}`}>
                                    {notices.map(n => (
                                        <tr key={n.id} className="hover:bg-gray-50 dark:hover:bg-slate-800/50">
                                            <td className={`p-5 font-bold ${themeClasses.textMain}`}>{n.title}</td>
                                            <td className={`p-5 ${themeClasses.textSub}`}>{n.postedBy}</td>
                                            <td className={`p-5 ${themeClasses.textSub}`}>{new Date(n.date).toLocaleDateString()}</td>
                                            <td className="p-5 text-right">
                                                <button onClick={(e) => deleteItem('notices', n.id, e)} className="text-red-400 hover:text-red-600 bg-red-50 p-2 rounded-full hover:bg-red-100 transition-colors">
                                                    <Trash2 size={16}/>
                                                </button>
                                            </td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                )}

                {/* --- FEES MGMT --- */}
                {activeTab === 'fees' && (
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 animate-fade-in">
                        <div className="lg:col-span-1 space-y-6">
                            {/* Global Fee Setter */}
                            <div className={`${themeClasses.cardBg} p-6 rounded-3xl border ${themeClasses.border} shadow-sm relative overflow-hidden`}>
                                <div className="absolute top-0 right-0 p-4 opacity-5"><Settings size={80}/></div>
                                <h3 className={`font-bold mb-4 ${themeClasses.textMain} flex items-center gap-2`}>
                                    <Settings size={20} className="text-indigo-500"/> Global Fee Settings
                                </h3>
                                <p className={`text-xs ${themeClasses.textSub} mb-4`}>Set the monthly tuition fee for ALL {studentsOnly.length} students at once. Enter 0 for Free.</p>
                                <div className="flex gap-2">
                                    <input placeholder="Amount (e.g. 500)" type="number" className={`flex-1 p-3 rounded-xl outline-none ${themeClasses.accentBg} ${themeClasses.textMain}`} value={globalFee} onChange={e => setGlobalFee(e.target.value)} />
                                    <button onClick={handleBulkUpdateFee} className={`px-4 py-3 rounded-xl font-bold text-white shadow-lg bg-indigo-600`}>Update All</button>
                                </div>
                            </div>

                            {/* Assign Individual Fee */}
                            <div className={`${themeClasses.cardBg} p-6 rounded-3xl border ${themeClasses.border} shadow-sm h-fit`}>
                                <h3 className={`font-bold mb-4 ${themeClasses.textMain}`}>Assign One-time Fee</h3>
                                <div className="space-y-4">
                                    <div>
                                        <label className={`text-xs font-bold uppercase mb-1 block ${themeClasses.textSub}`}>Select Student</label>
                                        <select className={`w-full p-3 rounded-xl outline-none ${themeClasses.accentBg} ${themeClasses.textMain}`} onChange={e => setFeeForm({...feeForm, studentId: e.target.value})} value={feeForm.studentId}>
                                            <option value="">-- Choose --</option>
                                            {studentsOnly.map(s => <option key={s.uid} value={s.uid}>{s.displayName} (Class {s.className})</option>)}
                                        </select>
                                    </div>
                                    <div className="flex gap-2">
                                        <input placeholder="Amount" type="number" className={`flex-1 p-3 rounded-xl outline-none ${themeClasses.accentBg} ${themeClasses.textMain}`} value={feeForm.amount} onChange={e => setFeeForm({...feeForm, amount: e.target.value})} />
                                        <input placeholder="Month" className={`flex-1 p-3 rounded-xl outline-none ${themeClasses.accentBg} ${themeClasses.textMain}`} value={feeForm.month} onChange={e => setFeeForm({...feeForm, month: e.target.value})} />
                                    </div>
                                    <button onClick={handleAssignFee} className={`w-full py-3 rounded-xl font-bold text-white shadow-lg ${primaryColor}`}>Assign Fee</button>
                                </div>
                            </div>
                        </div>

                        <div className={`lg:col-span-2 ${themeClasses.cardBg} rounded-3xl border ${themeClasses.border} overflow-hidden shadow-sm h-fit`}>
                            <div className="p-4 border-b border-gray-100 dark:border-slate-800">
                                <h3 className={`font-bold ${themeClasses.textMain}`}>Recent Fee Assignments</h3>
                            </div>
                            <div className="overflow-x-auto">
                                <table className="w-full text-left text-sm">
                                    <TableHeader cols={['Student', 'Amount', 'Status', 'Action']} />
                                    <tbody className={`divide-y ${theme === 'dark' ? 'divide-slate-700' : 'divide-gray-100'}`}>
                                        {fees.map(f => (
                                            <tr key={f.id} className="hover:bg-gray-50 dark:hover:bg-slate-800/50">
                                                <td className={`p-5 font-bold ${themeClasses.textMain}`}>{f.studentName}</td>
                                                <td className={`p-5 ${themeClasses.textMain}`}>৳{f.amount} <span className="text-xs opacity-50 block">{f.month}</span></td>
                                                <td className="p-5"><span className={`px-2 py-1 rounded text-xs font-bold uppercase ${f.status === 'paid' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>{f.status}</span></td>
                                                <td className="p-5 text-right">
                                                    <button onClick={(e) => deleteItem('fees', f.id, e)} className="text-red-400 hover:text-red-600 bg-red-50 p-2 rounded-full hover:bg-red-100 transition-colors">
                                                        <Trash2 size={16} />
                                                    </button>
                                                </td>
                                            </tr>
                                        ))}
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                )}

                {/* --- CODES --- */}
                {activeTab === 'codes' && (
                    <div className="space-y-6 animate-fade-in">
                        <div className={`${themeClasses.cardBg} p-6 rounded-3xl border ${themeClasses.border} max-w-xl shadow-sm`}>
                            <h3 className={`font-bold mb-4 ${themeClasses.textMain}`}>Generate Teacher Access Code</h3>
                            <div className="flex gap-4">
                                <input value={newTeacherName} onChange={e => setNewTeacherName(e.target.value)} placeholder="Teacher Full Name" className={`flex-1 p-3 rounded-xl outline-none ${themeClasses.accentBg} ${themeClasses.textMain}`} />
                                <button onClick={generateTeacherCode} className={`px-6 rounded-xl font-bold text-white shadow-lg ${primaryColor}`}>Generate</button>
                            </div>
                        </div>
                        <div className={`${themeClasses.cardBg} rounded-3xl border ${themeClasses.border} overflow-hidden shadow-sm`}>
                             <table className="w-full text-left text-sm">
                                <TableHeader cols={['Code', 'Assigned To', 'Status', 'Action']} />
                                <tbody className={`divide-y ${theme === 'dark' ? 'divide-slate-700' : 'divide-gray-100'}`}>
                                    {teacherCodes.map(code => (
                                        <tr key={code.id}>
                                            <td className="p-5 font-mono text-indigo-500 font-bold text-lg">{code.code}</td>
                                            <td className={`p-5 ${themeClasses.textMain}`}>{code.assignedToName}</td>
                                            <td className="p-5"><span className={`px-2 py-1 rounded text-xs font-bold ${code.isUsed ? 'bg-red-100 text-red-600' : 'bg-green-100 text-green-600'}`}>{code.isUsed ? 'Used' : 'Active'}</span></td>
                                            <td className="p-5 text-right"><button onClick={(e) => deleteItem('teacher_codes', code.id, e)} className="text-red-400 hover:text-red-600 bg-red-50 p-2 rounded-full hover:bg-red-100"><Trash2 size={16} /></button></td>
                                        </tr>
                                    ))}
                                </tbody>
                            </table>
                        </div>
                    </div>
                )}

                {/* --- ROUTINES & RESULTS --- */}
                {(activeTab === 'routines' || activeTab === 'results') && (
                     <div className={`${themeClasses.cardBg} rounded-3xl border ${themeClasses.border} overflow-hidden shadow-sm animate-fade-in`}>
                        <table className="w-full text-left text-sm">
                            <TableHeader cols={['Title / Name', 'Detail', 'Action']} />
                            <tbody className={`divide-y ${theme === 'dark' ? 'divide-slate-700' : 'divide-gray-100'}`}>
                                {activeTab === 'routines' ? routines.map(r => (
                                    <tr key={r.id}>
                                        <td className={`p-5 font-bold ${themeClasses.textMain}`}>{r.title}</td>
                                        <td className="p-5"><img src={r.imageUrl} className="h-12 w-12 rounded-lg object-cover border border-gray-200" /></td>
                                        <td className="p-5 text-right"><button onClick={(e) => deleteItem('routines', r.id, e)} className="text-red-400 hover:text-red-600 bg-red-50 p-2 rounded-full hover:bg-red-100"><Trash2 size={16} /></button></td>
                                    </tr>
                                )) : results.map(r => (
                                    <tr key={r.id}>
                                        <td className={`p-5 font-bold ${themeClasses.textMain}`}>{r.examName}</td>
                                        <td className={`p-5 ${themeClasses.textMain}`}>{r.studentName} <span className="font-bold text-indigo-500">({r.marks}/{r.totalMarks})</span></td>
                                        <td className="p-5 text-right"><button onClick={(e) => deleteItem('results', r.id, e)} className="text-red-400 hover:text-red-600 bg-red-50 p-2 rounded-full hover:bg-red-100"><Trash2 size={16} /></button></td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                     </div>
                )}

                {/* --- LIBRARY --- */}
                {activeTab === 'library' && (
                    <div className={`${themeClasses.cardBg} rounded-3xl border ${themeClasses.border} overflow-hidden shadow-sm animate-fade-in`}>
                         <table className="w-full text-left text-sm">
                             <TableHeader cols={['Book', 'Author', 'Action']} />
                             <tbody className={`divide-y ${theme === 'dark' ? 'divide-slate-700' : 'divide-gray-100'}`}>
                                 {books.map(b => (
                                     <tr key={b.id}>
                                         <td className={`p-5 font-bold ${themeClasses.textMain}`}>{b.title}</td>
                                         <td className={`p-5 ${themeClasses.textSub}`}>{b.author}</td>
                                         <td className="p-5"><button onClick={(e) => deleteItem('library', b.id, e)} className="text-red-400 hover:text-red-600 bg-red-50 p-2 rounded-full hover:bg-red-100"><Trash2 size={16} /></button></td>
                                     </tr>
                                 ))}
                             </tbody>
                         </table>
                    </div>
                )}

                {/* --- VIDEOS --- */}
                {activeTab === 'videos' && (
                    <div className={`${themeClasses.cardBg} rounded-3xl border ${themeClasses.border} overflow-hidden shadow-sm animate-fade-in`}>
                         <table className="w-full text-left text-sm">
                             <TableHeader cols={['Title', 'Subject', 'Action']} />
                             <tbody className={`divide-y ${theme === 'dark' ? 'divide-slate-700' : 'divide-gray-100'}`}>
                                 {videos.map(v => (
                                     <tr key={v.id}>
                                         <td className={`p-5 font-bold ${themeClasses.textMain}`}>{v.title}</td>
                                         <td className={`p-5 ${themeClasses.textSub}`}>{v.subject} (Class {v.classGrade})</td>
                                         <td className="p-5"><button onClick={(e) => deleteItem('videos', v.id, e)} className="text-red-400 hover:text-red-600 bg-red-50 p-2 rounded-full hover:bg-red-100"><Trash2 size={16} /></button></td>
                                     </tr>
                                 ))}
                             </tbody>
                         </table>
                    </div>
                )}
                
                 {/* --- GALLERY --- */}
                 {activeTab === 'gallery' && (
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 animate-fade-in">
                         {gallery.map(g => (
                             <div key={g.id} className="relative group rounded-xl overflow-hidden aspect-square">
                                 <img src={g.imageUrl} className="w-full h-full object-cover" />
                                 <div className="absolute inset-0 bg-black/50 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                                     <button onClick={() => deleteItem('gallery', g.id)} className="bg-red-600 text-white p-2 rounded-full"><Trash2 size={20}/></button>
                                 </div>
                                 <div className="absolute bottom-0 left-0 right-0 p-2 bg-black/40 text-white text-xs truncate">{g.caption}</div>
                             </div>
                         ))}
                    </div>
                )}

                {/* --- EVENTS --- */}
                 {activeTab === 'events' && (
                    <div className={`${themeClasses.cardBg} rounded-3xl border ${themeClasses.border} overflow-hidden shadow-sm animate-fade-in`}>
                         <table className="w-full text-left text-sm">
                             <TableHeader cols={['Event', 'Date', 'Type', 'Action']} />
                             <tbody className={`divide-y ${theme === 'dark' ? 'divide-slate-700' : 'divide-gray-100'}`}>
                                 {events.map(ev => (
                                     <tr key={ev.id}>
                                         <td className={`p-5 font-bold ${themeClasses.textMain}`}>{ev.title}</td>
                                         <td className={`p-5 ${themeClasses.textSub}`}>{ev.date}</td>
                                         <td className={`p-5 ${themeClasses.textSub}`}>{ev.type}</td>
                                         <td className="p-5"><button onClick={(e) => deleteItem('events', ev.id, e)} className="text-red-400 hover:text-red-600 bg-red-50 p-2 rounded-full hover:bg-red-100"><Trash2 size={16} /></button></td>
                                     </tr>
                                 ))}
                             </tbody>
                         </table>
                    </div>
                )}

                {/* --- LEAVES --- */}
                 {activeTab === 'leaves' && (
                    <div className={`${themeClasses.cardBg} rounded-3xl border ${themeClasses.border} overflow-hidden shadow-sm animate-fade-in`}>
                         <table className="w-full text-left text-sm">
                             <TableHeader cols={['User', 'Type', 'Status', 'Action']} />
                             <tbody className={`divide-y ${theme === 'dark' ? 'divide-slate-700' : 'divide-gray-100'}`}>
                                 {leaves.map(l => (
                                     <tr key={l.id}>
                                         <td className={`p-5 font-bold ${themeClasses.textMain}`}>{l.userName}</td>
                                         <td className={`p-5 ${themeClasses.textSub}`}>{l.type}</td>
                                         <td className="p-5"><span className={`px-2 py-1 rounded text-xs font-bold ${l.status === 'approved' ? 'bg-green-100 text-green-600' : 'bg-yellow-100 text-yellow-600'}`}>{l.status}</span></td>
                                         <td className="p-5"><button onClick={(e) => deleteItem('leave_requests', l.id, e)} className="text-red-400 hover:text-red-600 bg-red-50 p-2 rounded-full hover:bg-red-100"><Trash2 size={16} /></button></td>
                                     </tr>
                                 ))}
                             </tbody>
                         </table>
                    </div>
                )}

                 {/* --- COMPLAINTS --- */}
                 {activeTab === 'complaints' && (
                    <div className={`${themeClasses.cardBg} rounded-3xl border ${themeClasses.border} overflow-hidden shadow-sm animate-fade-in`}>
                         <table className="w-full text-left text-sm">
                             <TableHeader cols={['Title', 'From', 'Status', 'Action']} />
                             <tbody className={`divide-y ${theme === 'dark' ? 'divide-slate-700' : 'divide-gray-100'}`}>
                                 {complaints.map(c => (
                                     <tr key={c.id}>
                                         <td className={`p-5 font-bold ${themeClasses.textMain}`}>{c.title}</td>
                                         <td className={`p-5 ${themeClasses.textSub}`}>{c.submittedByName}</td>
                                         <td className={`p-5 ${themeClasses.textSub}`}>{c.status}</td>
                                         <td className="p-5"><button onClick={(e) => deleteItem('complaints', c.id, e)} className="text-red-400 hover:text-red-600 bg-red-50 p-2 rounded-full hover:bg-red-100"><Trash2 size={16} /></button></td>
                                     </tr>
                                 ))}
                             </tbody>
                         </table>
                    </div>
                )}

                 {/* --- MEETINGS --- */}
                 {activeTab === 'meetings' && (
                    <div className={`${themeClasses.cardBg} rounded-3xl border ${themeClasses.border} overflow-hidden shadow-sm animate-fade-in`}>
                         <table className="w-full text-left text-sm">
                             <TableHeader cols={['Requester', 'Teacher', 'Date', 'Action']} />
                             <tbody className={`divide-y ${theme === 'dark' ? 'divide-slate-700' : 'divide-gray-100'}`}>
                                 {meetings.map(m => (
                                     <tr key={m.id}>
                                         <td className={`p-5 font-bold ${themeClasses.textMain}`}>{m.requesterName}</td>
                                         <td className={`p-5 ${themeClasses.textSub}`}>{m.teacherName}</td>
                                         <td className={`p-5 ${themeClasses.textSub}`}>{m.date}</td>
                                         <td className="p-5"><button onClick={(e) => deleteItem('meetings', m.id, e)} className="text-red-400 hover:text-red-600 bg-red-50 p-2 rounded-full hover:bg-red-100"><Trash2 size={16} /></button></td>
                                     </tr>
                                 ))}
                             </tbody>
                         </table>
                    </div>
                )}

            </div>
        </div>
    </div>
  );
};

export default AdminPanel;
