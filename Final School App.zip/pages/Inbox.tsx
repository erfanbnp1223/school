
import React, { useEffect, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { collection, query, where, onSnapshot, orderBy } from 'firebase/firestore';
import { ref, onValue } from 'firebase/database';
import { db, rtdb } from '../firebase';
import { useNavigate } from 'react-router-dom';
import { Inbox as InboxIcon, MessageCircle, Calendar, FileText, CheckCircle, Clock, XCircle, AlertTriangle, ArrowRight } from 'lucide-react';
import { Meeting, LeaveRequest, Complaint } from '../types';

interface InboxItem {
    id: string;
    type: 'message' | 'meeting' | 'leave' | 'complaint';
    title: string;
    subtitle: string;
    timestamp: number;
    status?: string;
    actionNeeded?: boolean;
    data?: any;
}

const Inbox: React.FC = () => {
    const { userProfile } = useAuth();
    const { themeClasses, primaryColor } = useTheme();
    const navigate = useNavigate();
    const [items, setItems] = useState<InboxItem[]>([]);
    const [filter, setFilter] = useState<'all' | 'messages' | 'requests'>('all');

    useEffect(() => {
        if (!userProfile) return;

        const allItems: InboxItem[] = [];

        // 1. RTDB Messages (Latest chats)
        const chatsRef = ref(rtdb, 'chats');
        const unsubChats = onValue(chatsRef, snap => {
            const data = snap.val();
            if (data) {
                Object.keys(data).forEach(key => {
                    if (key.includes(userProfile.uid)) {
                        const msgs = data[key].messages;
                        if (msgs) {
                            const lastKey = Object.keys(msgs).pop();
                            if (lastKey) {
                                const lastMsg = msgs[lastKey];
                                const isMe = lastMsg.senderId === userProfile.uid;
                                const otherUid = key.replace(userProfile.uid, '').replace('_', '');
                                const meta = data[key].meta?.[otherUid] || { name: 'User' };

                                // Add to items
                                allItems.push({
                                    id: key,
                                    type: 'message',
                                    title: meta.name,
                                    subtitle: isMe ? `You: ${lastMsg.text}` : lastMsg.text,
                                    timestamp: lastMsg.timestamp,
                                    actionNeeded: !isMe,
                                    data: { otherUid }
                                });
                            }
                        }
                    }
                });
            }
            updateItems(allItems);
        });

        // 2. Meetings
        let meetingQ = query(collection(db, 'meetings'), where('studentId', '==', userProfile.uid));
        if (userProfile.role === 'teacher') {
            meetingQ = query(collection(db, 'meetings'), where('teacherId', '==', userProfile.uid));
        } else if (userProfile.role === 'admin') {
            meetingQ = query(collection(db, 'meetings'));
        }
        
        const unsubMeetings = onSnapshot(meetingQ, snap => {
            snap.docs.forEach(doc => {
                const m = doc.data() as Meeting;
                const isMyRequest = m.studentId === userProfile.uid;
                // If I am teacher, and pending -> Action Needed
                // If I am student, and approved/rejected -> Notification
                
                const actionNeeded = (userProfile.role === 'teacher' || userProfile.role === 'admin') && m.status === 'pending';
                
                allItems.push({
                    id: doc.id,
                    type: 'meeting',
                    title: isMyRequest ? `Meeting with ${m.teacherName}` : `Meeting Request: ${m.studentName}`,
                    subtitle: `${m.date} @ ${m.timeSlot} - ${m.status.toUpperCase()}`,
                    timestamp: m.createdAt,
                    status: m.status,
                    actionNeeded,
                    data: m
                });
            });
            updateItems(allItems);
        });

        // 3. Leave Requests
        let leaveQ = query(collection(db, 'leave_requests'), where('userId', '==', userProfile.uid));
        if (userProfile.role === 'admin') {
            leaveQ = query(collection(db, 'leave_requests')); // Admin sees all
        }
        
        const unsubLeaves = onSnapshot(leaveQ, snap => {
            snap.docs.forEach(doc => {
                const l = doc.data() as LeaveRequest;
                const isMyRequest = l.userId === userProfile.uid;
                const actionNeeded = userProfile.role === 'admin' && l.status === 'pending';

                allItems.push({
                    id: doc.id,
                    type: 'leave',
                    title: isMyRequest ? `Leave Application` : `Leave Request: ${l.userName}`,
                    subtitle: `${l.type} - ${l.status.toUpperCase()}`,
                    timestamp: l.createdAt,
                    status: l.status,
                    actionNeeded,
                    data: l
                });
            });
            updateItems(allItems);
        });
        
        // 4. Complaints (If user submitted one)
        if (userProfile.role !== 'admin') {
             const compQ = query(collection(db, 'complaints'), where('submittedBy', '==', userProfile.uid));
             onSnapshot(compQ, snap => {
                 snap.docs.forEach(doc => {
                     const c = doc.data() as Complaint;
                     allItems.push({
                         id: doc.id,
                         type: 'complaint',
                         title: 'Complaint Update',
                         subtitle: `${c.title} - ${c.status.toUpperCase()}`,
                         timestamp: c.submittedAt,
                         status: c.status,
                         data: c
                     });
                 });
                 updateItems(allItems);
             });
        }

        return () => { unsubChats(); unsubMeetings(); unsubLeaves(); };
    }, [userProfile]);

    const updateItems = (newItems: InboxItem[]) => {
        // De-duplicate by ID
        const unique = Array.from(new Map(newItems.map(item => [item.id, item])).values());
        unique.sort((a, b) => b.timestamp - a.timestamp);
        setItems(unique);
    };

    const getIcon = (type: string, status?: string) => {
        if (type === 'message') return <MessageCircle size={24} className="text-blue-500" />;
        if (type === 'meeting') return <Calendar size={24} className="text-orange-500" />;
        if (type === 'leave') return <FileText size={24} className="text-purple-500" />;
        if (type === 'complaint') return <AlertTriangle size={24} className="text-red-500" />;
        return <InboxIcon size={24} />;
    };

    const getStatusBadge = (status?: string) => {
        if (!status) return null;
        if (status === 'pending') return <span className="bg-yellow-100 text-yellow-700 px-2 py-0.5 rounded text-[10px] uppercase font-bold flex items-center gap-1"><Clock size={10}/> Pending</span>;
        if (status === 'approved' || status === 'resolved') return <span className="bg-green-100 text-green-700 px-2 py-0.5 rounded text-[10px] uppercase font-bold flex items-center gap-1"><CheckCircle size={10}/> {status}</span>;
        if (status === 'rejected') return <span className="bg-red-100 text-red-700 px-2 py-0.5 rounded text-[10px] uppercase font-bold flex items-center gap-1"><XCircle size={10}/> Rejected</span>;
        return null;
    };

    const handleItemClick = (item: InboxItem) => {
        if (item.type === 'message') navigate('/chat');
        if (item.type === 'meeting') navigate('/meeting');
        if (item.type === 'leave') navigate('/leave');
        if (item.type === 'complaint') navigate('/complaint');
    };

    const filteredItems = items.filter(i => {
        if (filter === 'all') return true;
        if (filter === 'messages') return i.type === 'message';
        if (filter === 'requests') return i.type !== 'message';
        return true;
    });

    return (
        <div className="space-y-6 pb-20">
             <div className="flex justify-between items-center">
                <h1 className={`text-2xl font-bold flex items-center gap-2 ${themeClasses.textMain}`}>
                    <InboxIcon className="text-indigo-500" /> Personal Inbox
                </h1>
            </div>

            {/* Filter Tabs */}
            <div className={`${themeClasses.cardBg} p-1 rounded-2xl border ${themeClasses.border} flex`}>
                {['all', 'messages', 'requests'].map(f => (
                    <button
                        key={f}
                        onClick={() => setFilter(f as any)}
                        className={`flex-1 py-2 rounded-xl text-sm font-bold capitalize transition-all ${filter === f ? `${primaryColor} text-white shadow-md` : 'text-gray-500'}`}
                    >
                        {f}
                    </button>
                ))}
            </div>

            <div className="space-y-3">
                {filteredItems.map(item => (
                    <div 
                        key={item.id} 
                        onClick={() => handleItemClick(item)}
                        className={`${themeClasses.cardBg} p-4 rounded-3xl shadow-sm border ${themeClasses.border} flex items-center gap-4 relative group cursor-pointer hover:shadow-md transition-all ${item.actionNeeded ? 'ring-2 ring-red-500/20 bg-red-50/10' : ''}`}
                    >
                        <div className={`w-12 h-12 rounded-2xl flex items-center justify-center shrink-0 ${themeClasses.accentBg}`}>
                            {getIcon(item.type, item.status)}
                        </div>
                        
                        <div className="flex-1 min-w-0">
                            <div className="flex justify-between items-start">
                                <h3 className={`font-bold text-sm ${themeClasses.textMain} truncate`}>{item.title}</h3>
                                <span className={`text-[10px] ${themeClasses.textSub} shrink-0`}>
                                    {new Date(item.timestamp).toLocaleDateString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                                </span>
                            </div>
                            <p className={`text-xs ${themeClasses.textSub} truncate mt-0.5`}>{item.subtitle}</p>
                            <div className="mt-2 flex gap-2">
                                {getStatusBadge(item.status)}
                                {item.actionNeeded && <span className="bg-red-500 text-white px-2 py-0.5 rounded text-[10px] uppercase font-bold animate-pulse">Action Required</span>}
                            </div>
                        </div>
                        
                        <div className="text-gray-300 group-hover:text-indigo-500 transition-colors">
                            <ArrowRight size={18} />
                        </div>
                    </div>
                ))}
                {filteredItems.length === 0 && (
                    <div className="text-center p-12 opacity-50">
                        <InboxIcon size={64} className="mx-auto mb-4 text-gray-300" />
                        <h3 className="font-bold text-lg">All caught up!</h3>
                        <p className="text-sm">No new items in your inbox.</p>
                    </div>
                )}
            </div>
        </div>
    );
};

export default Inbox;
