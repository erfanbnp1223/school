
import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { uploadImageToImgBB } from '../services/imgbbService';
import { doc, setDoc } from 'firebase/firestore';
import { db } from '../firebase';
import { useNavigate } from 'react-router-dom';
import { ShieldCheck, Camera, User, Mail, Phone, Edit2, Save, MapPin, Droplet, Users, CreditCard, LayoutDashboard, Hash, GraduationCap, BookOpen, Heart } from 'lucide-react';
import { useTheme } from '../contexts/ThemeContext';

const Profile: React.FC = () => {
  const { userProfile, currentUser, refreshProfile, loading } = useAuth();
  const { theme, playSound, themeClasses, primaryColor } = useTheme();
  const navigate = useNavigate();
  const [uploading, setUploading] = useState(false);
  const [editing, setEditing] = useState(false);
  
  const [formData, setFormData] = useState({
      displayName: '', phone: '', address: '', bloodGroup: '', fatherName: '', age: '',
      rollNumber: '', bio: '', education: '', department: '', experience: '', subject: ''
  });

  const displayProfile = userProfile || {
      uid: currentUser?.uid, displayName: currentUser?.displayName || 'User', email: currentUser?.email,
      photoURL: currentUser?.photoURL, phone: '', role: 'student', className: '',
      address: 'N/A', bloodGroup: 'N/A', fatherName: 'N/A', age: 'N/A', rollNumber: 'N/A',
      bio: '', education: '', department: '', experience: '', subject: ''
  };

  const startEditing = () => {
      playSound('click');
      setFormData({
          displayName: displayProfile.displayName || '',
          phone: displayProfile.phone || '',
          address: displayProfile['address'] || '',
          bloodGroup: displayProfile['bloodGroup'] || '',
          fatherName: displayProfile['fatherName'] || '',
          age: displayProfile['age'] || '',
          rollNumber: displayProfile['rollNumber'] || '',
          bio: displayProfile['bio'] || '',
          education: displayProfile['education'] || '',
          department: displayProfile['department'] || '',
          experience: displayProfile['experience'] || '',
          subject: displayProfile['subject'] || ''
      });
      setEditing(true);
  };

  const handleImageChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0] && currentUser) {
        setUploading(true);
        try {
            const url = await uploadImageToImgBB(e.target.files[0]);
            await setDoc(doc(db, 'users', currentUser.uid), { photoURL: url }, { merge: true });
            await refreshProfile();
        } catch (error) { alert('Failed to upload image.'); } finally { setUploading(false); }
    }
  };

  const handleSave = async () => {
      playSound('click');
      if(!currentUser) return;
      try {
          await setDoc(doc(db, 'users', currentUser.uid), {
              ...formData
          }, { merge: true });
          setEditing(false); await refreshProfile();
      } catch(e) { alert("Failed to save."); }
  }

  // Admin Check
  const adminEmails = ['erfansarker30@gmail.com', 'erfanbnp99@gmail.com'];
  const showAdminButton = currentUser?.email && adminEmails.includes(currentUser.email);
  const isTeacher = displayProfile.role === 'teacher';
  const isStudent = displayProfile.role === 'student';

  if (loading) return <div>Loading...</div>;
  if (!currentUser) return <div>Please login.</div>;

  return (
    <div className="max-w-3xl mx-auto pb-24 space-y-6 animate-fade-in">
       
       {/* 1. Header Card with Facebook-style Banner */}
       <div className={`${themeClasses.cardBg} rounded-[2rem] shadow-md overflow-hidden relative border ${themeClasses.border}`}>
            {/* Banner Image - Using direct URL as requested, with fallback */}
            <div className="h-48 md:h-72 relative bg-gray-200">
                <img 
                    src="https://i.postimg.cc/y3WGqbYX/image.jpg" 
                    onError={(e) => {
                        // Fallback to the viewer link if direct fails, or a generic banner
                        // Since postimg direct links expire or vary, we use a robust placeholder if it breaks
                        e.currentTarget.src = "https://images.unsplash.com/photo-1546410531-bb4caa6b424d?q=80&w=1000&auto=format&fit=crop";
                    }}
                    className="w-full h-full object-cover"
                    alt="Cover" 
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent"></div>
            </div>
            
            <div className="px-6 pb-6 relative">
                {/* Profile Picture - Overlapping */}
                <div className="relative -mt-20 mb-3 flex justify-between items-end">
                    <div className="relative group">
                        <div className={`w-36 h-36 rounded-full border-[6px] shadow-2xl overflow-hidden bg-white ${themeClasses.border} ${theme === 'dark' ? 'border-slate-800' : 'border-white'}`}>
                             <img 
                                src={displayProfile.photoURL || `https://ui-avatars.com/api/?name=${displayProfile.displayName}`} 
                                className="w-full h-full object-cover transform transition-transform group-hover:scale-110" 
                             />
                        </div>
                        <label className={`absolute bottom-2 right-2 bg-gray-900 text-white p-2.5 rounded-full cursor-pointer hover:bg-gray-700 shadow-xl border-2 border-white ${uploading ? 'opacity-50' : ''}`}>
                            <Camera size={18} />
                            <input type="file" className="hidden" accept="image/*" onChange={handleImageChange} disabled={uploading} />
                        </label>
                    </div>
                    {/* Role Badge */}
                    <div className="mb-6 hidden md:block">
                        <span className={`px-5 py-2 rounded-full text-sm font-bold uppercase tracking-widest shadow-lg ${primaryColor} text-white`}>
                            {displayProfile.role}
                        </span>
                    </div>
                </div>
                
                {editing ? (
                    <div className="space-y-4 animate-fade-in bg-gray-50 dark:bg-slate-800/50 p-6 rounded-2xl border border-gray-200 dark:border-slate-700 mt-4">
                        <h3 className="font-bold text-gray-500">Edit Basic Info</h3>
                        <input value={formData.displayName} onChange={e => setFormData({...formData, displayName: e.target.value})} className={`w-full p-4 rounded-xl outline-none border ${themeClasses.border} ${themeClasses.textMain} ${themeClasses.cardBg}`} placeholder="Full Name" />
                        
                        {isStudent && (
                             <input value={formData.rollNumber} onChange={e => setFormData({...formData, rollNumber: e.target.value})} className={`w-full p-4 rounded-xl outline-none border ${themeClasses.border} ${themeClasses.textMain} ${themeClasses.cardBg}`} placeholder="Class Roll Number" />
                        )}
                        
                        {isTeacher && (
                            <>
                             <input value={formData.subject} onChange={e => setFormData({...formData, subject: e.target.value})} className={`w-full p-4 rounded-xl outline-none border ${themeClasses.border} ${themeClasses.textMain} ${themeClasses.cardBg}`} placeholder="Subject Specialist" />
                             <input value={formData.education} onChange={e => setFormData({...formData, education: e.target.value})} className={`w-full p-4 rounded-xl outline-none border ${themeClasses.border} ${themeClasses.textMain} ${themeClasses.cardBg}`} placeholder="Education" />
                             <input value={formData.experience} onChange={e => setFormData({...formData, experience: e.target.value})} className={`w-full p-4 rounded-xl outline-none border ${themeClasses.border} ${themeClasses.textMain} ${themeClasses.cardBg}`} placeholder="Experience" />
                            </>
                        )}
                        
                        <div className="flex gap-3 justify-end pt-4">
                            <button onClick={() => setEditing(false)} className="px-6 py-2 rounded-xl text-sm font-bold text-gray-500 hover:bg-gray-200">Cancel</button>
                            <button onClick={handleSave} className={`px-8 py-2 rounded-xl text-sm font-bold text-white shadow-lg flex items-center gap-2 ${primaryColor}`}><Save size={18}/> Save</button>
                        </div>
                    </div>
                ) : (
                    <div className="animate-fade-in mt-2">
                        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-2">
                            <div>
                                <h2 className={`text-3xl font-extrabold mb-1 ${themeClasses.textMain}`}>{displayProfile.displayName}</h2>
                                <p className={`text-sm font-medium ${themeClasses.textSub}`}>{displayProfile.email}</p>
                            </div>
                            <div className="md:hidden mt-2">
                                <span className={`px-4 py-1.5 rounded-full text-xs font-bold uppercase tracking-wider shadow-sm ${primaryColor} text-white`}>
                                    {displayProfile.role}
                                </span>
                            </div>
                        </div>

                        {displayProfile['age'] && <p className={`mt-2 ${themeClasses.textSub} text-sm font-bold flex items-center gap-1`}><User size={14}/> {displayProfile['age']} Years Old</p>}
                        
                        {isTeacher && displayProfile['bio'] && (
                            <div className="mt-4 p-4 rounded-xl bg-indigo-50 dark:bg-slate-800/50 border border-indigo-100 dark:border-slate-700">
                                <p className="text-sm italic opacity-80 leading-relaxed text-indigo-900 dark:text-indigo-200">"{displayProfile['bio']}"</p>
                            </div>
                        )}
                        
                        {isStudent && (
                            <div className="flex gap-2 mt-4">
                                {displayProfile.className && <span className="bg-gray-100 dark:bg-slate-700 text-gray-800 dark:text-gray-200 px-4 py-1.5 rounded-lg text-sm font-bold uppercase border border-gray-200 dark:border-slate-600 shadow-sm">Class {displayProfile.className}</span>}
                                {displayProfile.rollNumber && <span className="bg-gray-100 dark:bg-slate-700 text-gray-800 dark:text-gray-200 px-4 py-1.5 rounded-lg text-sm font-bold uppercase border border-gray-200 dark:border-slate-600 shadow-sm">Roll: {displayProfile.rollNumber}</span>}
                            </div>
                        )}
                        
                        <div className="flex gap-3 mt-6">
                            <button onClick={startEditing} className="flex-1 flex items-center justify-center gap-2 text-sm font-bold text-gray-700 dark:text-gray-200 bg-gray-100 dark:bg-slate-700 px-6 py-3 rounded-xl hover:bg-gray-200 dark:hover:bg-slate-600 transition-colors shadow-sm">
                                <Edit2 size={18} /> Edit Profile
                            </button>
                            
                            {showAdminButton && (
                                <button 
                                    onClick={() => navigate('/admin')}
                                    className="flex-1 flex items-center justify-center gap-2 text-sm font-bold text-white bg-gradient-to-r from-indigo-600 to-purple-600 px-6 py-3 rounded-xl shadow-lg shadow-indigo-500/30 hover:shadow-indigo-500/50 transition-all"
                                >
                                    <LayoutDashboard size={18} /> Admin Panel
                                </button>
                            )}
                        </div>
                    </div>
                )}
            </div>
       </div>

       {/* 2. Detailed Info Section (Clean & Professional) */}
       <div className={`${themeClasses.cardBg} rounded-[2rem] p-6 shadow-sm border ${themeClasses.border} space-y-6`}>
           <h3 className={`font-bold text-xl border-b pb-4 ${themeClasses.border} ${themeClasses.textMain} flex items-center gap-2`}>
               <ShieldCheck className="text-indigo-500" /> Personal Information
           </h3>

           <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                
                {/* Teacher Specific Fields */}
                {isTeacher && (
                    <>
                         <div className={`p-4 rounded-2xl ${themeClasses.accentBg} col-span-1 md:col-span-2`}>
                            <p className={`text-xs font-bold uppercase opacity-60 mb-2 ${themeClasses.textSub}`}>About / Bio</p>
                            {editing ? (
                                <textarea value={formData.bio} onChange={e => setFormData({...formData, bio: e.target.value})} className="w-full bg-white p-3 rounded-xl border h-24 resize-none" />
                            ) : (
                                <p className={`font-medium ${themeClasses.textMain} leading-relaxed`}>{displayProfile['bio'] || 'No bio added.'}</p>
                            )}
                         </div>

                         <div className={`p-4 rounded-2xl ${themeClasses.accentBg}`}>
                            <p className={`text-xs font-bold uppercase opacity-60 mb-1 ${themeClasses.textSub}`}>Education</p>
                            <p className={`font-semibold ${themeClasses.textMain}`}>{displayProfile['education'] || 'N/A'}</p>
                         </div>
                         <div className={`p-4 rounded-2xl ${themeClasses.accentBg}`}>
                            <p className={`text-xs font-bold uppercase opacity-60 mb-1 ${themeClasses.textSub}`}>Experience</p>
                            <p className={`font-semibold ${themeClasses.textMain}`}>{displayProfile['experience'] || 'N/A'}</p>
                         </div>
                    </>
                )}

                {/* Common Fields */}
                <div className={`p-4 rounded-2xl flex items-center gap-4 ${themeClasses.accentBg}`}>
                    <div className="p-3 bg-white dark:bg-slate-800 rounded-full text-indigo-500 shadow-sm"><Mail size={20}/></div>
                    <div className="flex-1 overflow-hidden">
                        <p className={`text-xs font-bold uppercase opacity-60 ${themeClasses.textSub}`}>Email</p>
                        <p className={`font-semibold text-sm ${themeClasses.textMain} truncate`}>{displayProfile.email}</p>
                    </div>
                </div>
                
                <div className={`p-4 rounded-2xl flex items-center gap-4 ${themeClasses.accentBg}`}>
                    <div className="p-3 bg-white dark:bg-slate-800 rounded-full text-pink-500 shadow-sm"><Phone size={20}/></div>
                    <div className="flex-1">
                         <p className={`text-xs font-bold uppercase opacity-60 ${themeClasses.textSub}`}>Phone</p>
                         {editing ? <input value={formData.phone} onChange={e => setFormData({...formData, phone: e.target.value})} className="bg-transparent border-b w-full" /> : 
                         <p className={`font-semibold text-sm ${themeClasses.textMain}`}>{displayProfile.phone || 'N/A'}</p>}
                    </div>
                </div>

                <div className={`p-4 rounded-2xl flex items-center gap-4 ${themeClasses.accentBg}`}>
                     <div className="p-3 bg-white dark:bg-slate-800 rounded-full text-orange-500 shadow-sm"><MapPin size={20}/></div>
                     <div className="flex-1">
                        <p className={`text-xs font-bold uppercase opacity-60 ${themeClasses.textSub}`}>Address</p>
                        {editing ? <input value={formData.address} onChange={e => setFormData({...formData, address: e.target.value})} className="bg-transparent border-b w-full" /> : 
                        <p className={`font-semibold text-sm ${themeClasses.textMain}`}>{displayProfile['address'] || 'N/A'}</p>}
                     </div>
                </div>

                <div className={`p-4 rounded-2xl flex items-center gap-4 ${themeClasses.accentBg}`}>
                     <div className="p-3 bg-white dark:bg-slate-800 rounded-full text-red-500 shadow-sm"><Droplet size={20}/></div>
                     <div className="flex-1">
                        <p className={`text-xs font-bold uppercase opacity-60 ${themeClasses.textSub}`}>Blood Group</p>
                        {editing ? <input value={formData.bloodGroup} onChange={e => setFormData({...formData, bloodGroup: e.target.value})} className="bg-transparent border-b w-full" /> : 
                        <p className={`font-semibold text-sm ${themeClasses.textMain}`}>{displayProfile['bloodGroup'] || 'N/A'}</p>}
                     </div>
                </div>

                <div className={`p-4 rounded-2xl flex items-center gap-4 ${themeClasses.accentBg} col-span-1 md:col-span-2`}>
                     <div className="p-3 bg-white dark:bg-slate-800 rounded-full text-blue-500 shadow-sm"><Users size={20}/></div>
                     <div className="flex-1">
                        <p className={`text-xs font-bold uppercase opacity-60 ${themeClasses.textSub}`}>Father's Name</p>
                        {editing ? <input value={formData.fatherName} onChange={e => setFormData({...formData, fatherName: e.target.value})} className="bg-transparent border-b w-full" /> : 
                        <p className={`font-semibold text-sm ${themeClasses.textMain}`}>{displayProfile['fatherName'] || 'N/A'}</p>}
                     </div>
                </div>
           </div>
       </div>
    </div>
  );
};

export default Profile;
