
import React, { useEffect, useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { collection, query, orderBy, limit, onSnapshot, where, addDoc, updateDoc, arrayUnion, arrayRemove, deleteDoc, doc, getDocs } from 'firebase/firestore';
import { db } from '../firebase';
import { Notice, Post, POST_BACKGROUNDS, Comment, SUPER_ADMINS } from '../types';
import { Bell, ArrowRight, Zap, Image as ImageIcon, Send, MoreHorizontal, User, X, Plus, Layers, Heart, MessageCircle, Trash2 } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { createPortal } from 'react-dom';
import { uploadImageToImgBB } from '../services/imgbbService';

// Sub-component for Comments Drawer (Social Posts)
const PostCommentsDrawer: React.FC<{ postId: string, onClose: () => void }> = ({ postId, onClose }) => {
    const { userProfile } = useAuth();
    const { themeClasses } = useTheme();
    const [comments, setComments] = useState<Comment[]>([]);
    const [newComment, setNewComment] = useState('');

    useEffect(() => {
        const q = query(collection(db, 'post_comments'), where('postId', '==', postId));
        const unsub = onSnapshot(q, snap => {
            const data = snap.docs.map(d => ({ id: d.id, ...d.data() } as Comment));
            data.sort((a, b) => a.timestamp - b.timestamp);
            setComments(data);
        });
        return unsub;
    }, [postId]);

    const handleSend = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!newComment.trim() || !userProfile) return;
        
        await addDoc(collection(db, 'post_comments'), {
            postId, 
            userId: userProfile.uid, 
            userName: userProfile.displayName,
            userPhoto: userProfile.photoURL, 
            text: newComment, 
            timestamp: Date.now()
        });
        setNewComment('');
    };

    const handleDelete = async (id: string) => {
        if(confirm("Delete comment?")) await deleteDoc(doc(db, 'post_comments', id));
    };

    return createPortal(
        <div className="fixed inset-0 z-[400] flex flex-col justify-end md:justify-center md:items-center">
             <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose}></div>
             
             <div className={`${themeClasses.cardBg} w-full md:w-[500px] md:h-[600px] h-[85%] rounded-t-[2.5rem] md:rounded-3xl shadow-2xl z-10 flex flex-col relative animate-slide-in-up border-t border-white/20`}>
                <div className={`p-4 border-b ${themeClasses.border} flex justify-between items-center`}>
                    <h3 className={`font-bold ${themeClasses.textMain}`}>Comments ({comments.length})</h3>
                    <button onClick={onClose} className={`p-2 rounded-full ${themeClasses.accentBg}`}><X size={18} /></button>
                </div>

                <div className="flex-1 overflow-y-auto p-4 space-y-4">
                    {comments.length === 0 && <div className="text-center text-gray-400 py-10">No comments yet.</div>}
                    {comments.map(c => {
                        const canDelete = userProfile?.uid === c.userId || userProfile?.role === 'admin' || SUPER_ADMINS.includes(userProfile?.email || '');
                        return (
                            <div key={c.id} className="flex gap-3">
                                <img src={c.userPhoto} className="w-8 h-8 rounded-full border border-gray-200" />
                                <div className="flex-1">
                                    <div className={`${themeClasses.accentBg} p-3 rounded-2xl rounded-tl-none inline-block`}>
                                        <p className={`font-bold text-sm ${themeClasses.textMain}`}>{c.userName}</p>
                                        <p className={`text-sm ${themeClasses.textSub}`}>{c.text}</p>
                                    </div>
                                    {canDelete && <button onClick={() => handleDelete(c.id)} className="text-[10px] text-red-500 font-bold ml-2">Delete</button>}
                                </div>
                            </div>
                        )
                    })}
                </div>

                <form onSubmit={handleSend} className={`p-4 border-t ${themeClasses.border} flex gap-2`}>
                    <input className={`flex-1 rounded-full px-5 py-3 outline-none shadow-inner ${themeClasses.accentBg} ${themeClasses.textMain}`} placeholder="Write a comment..." value={newComment} onChange={e => setNewComment(e.target.value)} />
                    <button type="submit" className="bg-indigo-600 text-white p-3 rounded-full shadow-lg"><Send size={18} /></button>
                </form>
             </div>
        </div>,
        document.body
    );
};

// Sub-component for Text Truncation
const FeedText: React.FC<{ text: string; bg?: string; isImage?: boolean }> = ({ text, bg, isImage }) => {
    const [expanded, setExpanded] = useState(false);
    const { themeClasses } = useTheme();
    
    if (!isImage && bg && bg !== 'bg-white') {
        return (
            <div className={`w-full aspect-video flex items-center justify-center p-8 text-center text-xl md:text-2xl font-bold ${bg} ${bg.includes('white') ? 'text-gray-900' : 'text-white'}`}>
                {text}
            </div>
        );
    }

    const isLong = text.length > 150;
    const displayText = expanded ? text : text.slice(0, 150) + (isLong ? '...' : '');

    return (
        <div className="px-4 pb-2">
            <p className={`text-sm ${themeClasses.textMain} whitespace-pre-wrap leading-relaxed`}>
                {displayText}
            </p>
            {isLong && (
                <button onClick={() => setExpanded(!expanded)} className="text-gray-500 font-bold text-xs mt-1 hover:underline">
                    {expanded ? 'See less' : 'See more'}
                </button>
            )}
        </div>
    );
};

const Home: React.FC = () => {
  const { userProfile } = useAuth();
  const { themeClasses, playSound, primaryColor } = useTheme();
  const navigate = useNavigate();
  const [notices, setNotices] = useState<Notice[]>([]);
  const [recentPosts, setRecentPosts] = useState<Post[]>([]);
  
  // Create Post State
  const [showQuickPost, setShowQuickPost] = useState(false);
  const [postContent, setPostContent] = useState('');
  const [postFiles, setPostFiles] = useState<File[]>([]);
  const [postBg, setPostBg] = useState('bg-white');
  const [isPosting, setIsPosting] = useState(false);
  const [lightbox, setLightbox] = useState<string | null>(null);
  
  // Interaction State
  const [activeCommentPostId, setActiveCommentPostId] = useState<string | null>(null);
  const [openMenuId, setOpenMenuId] = useState<string | null>(null);

  // Clock
  const [currentTime, setCurrentTime] = useState(new Date());

  useEffect(() => {
    const timer = setInterval(() => setCurrentTime(new Date()), 1000);

    // Limit notices to 1 as requested
    const noticeQuery = query(collection(db, 'notices'), orderBy('date', 'desc'), limit(1));
    const unsubNotices = onSnapshot(noticeQuery, (snap) => setNotices(snap.docs.map(d => ({ id: d.id, ...d.data() } as Notice))), (err) => console.log(err));

    const postsQuery = query(collection(db, 'posts'), orderBy('createdAt', 'desc'), limit(30));
    const unsubPosts = onSnapshot(postsQuery, (snap) => setRecentPosts(snap.docs.map(d => ({ id: d.id, ...d.data() } as Post))), (err) => console.log(err));

    return () => { 
        clearInterval(timer);
        unsubNotices(); 
        unsubPosts(); 
    };
  }, []);

  const handleQuickPost = async () => {
      if(!postContent.trim() && postFiles.length === 0) return;
      setIsPosting(true);
      try {
        const imageUrls: string[] = [];
        if (postFiles.length > 0) {
            const uploadPromises = postFiles.map(file => uploadImageToImgBB(file));
            const results = await Promise.all(uploadPromises);
            imageUrls.push(...results);
        }

        await addDoc(collection(db, 'posts'), {
            description: postContent,
            imageUrl: imageUrls[0] || '', 
            images: imageUrls, 
            background: postFiles.length === 0 ? postBg : 'bg-white',
            createdBy: {
                uid: userProfile?.uid,
                name: userProfile?.displayName,
                role: userProfile?.role,
                photoURL: userProfile?.photoURL
            },
            createdAt: Date.now(),
            likes: []
        });

        setPostContent('');
        setPostFiles([]);
        setPostBg('bg-white');
        setShowQuickPost(false);
        playSound('success');
      } catch (e) {
          console.error(e);
          alert("Failed to post.");
      } finally {
          setIsPosting(false);
      }
  };

  const handleLike = async (id: string, currentLikes: string[] = [], collectionName: string) => {
      if (!userProfile) return;
      playSound('click'); // Like Sound
      
      const isLiked = currentLikes.includes(userProfile.uid);
      const docRef = doc(db, collectionName, id);

      if (isLiked) {
          await updateDoc(docRef, { likes: arrayRemove(userProfile.uid) });
      } else {
          await updateDoc(docRef, { likes: arrayUnion(userProfile.uid) });
      }
  };

  const handleDeletePost = async (id: string) => {
      if(confirm("Are you sure you want to delete this post?")) {
          await deleteDoc(doc(db, 'posts', id));
          playSound('click');
      }
  };

  const handleFileSelect = (e: React.ChangeEvent<HTMLInputElement>) => {
      if (e.target.files) {
          setPostFiles(prev => [...prev, ...Array.from(e.target.files!)]);
          setPostBg('bg-white');
      }
  };

  const getGreeting = () => {
    const h = currentTime.getHours();
    if (h >= 5 && h < 12) return 'Good Morning';
    if (h >= 12 && h < 17) return 'Good Afternoon';
    if (h >= 17 && h < 21) return 'Good Evening';
    return 'Good Night';
  };

  const feedItems = [
      ...notices.map(n => ({ type: 'notice', date: new Date(n.date).getTime(), data: n })),
      ...recentPosts.map(p => ({ type: 'post', date: p.createdAt, data: p }))
  ].sort((a, b) => b.date - a.date);

  const renderImageGrid = (images: string[]) => {
      const count = images.length;
      if (count === 0) return null;

      // Facebook Style Grid Logic - Properly contained
      return (
          <div className="w-full mt-3 overflow-hidden">
            {count === 1 && (
                <div className="w-full h-auto cursor-pointer" onClick={() => setLightbox(images[0])}>
                    <img src={images[0]} className="w-full h-auto max-h-[500px] object-cover" />
                </div>
            )}
            
            {count === 2 && (
                <div className="grid grid-cols-2 gap-0.5 h-72">
                    {images.map((img, i) => (
                        <div key={i} className="w-full h-full cursor-pointer overflow-hidden" onClick={() => setLightbox(img)}>
                             <img src={img} className="w-full h-full object-cover hover:scale-105 transition-transform duration-500" />
                        </div>
                    ))}
                </div>
            )}

            {count === 3 && (
                <div className="grid grid-cols-2 gap-0.5 h-96">
                    <div className="row-span-2 cursor-pointer overflow-hidden" onClick={() => setLightbox(images[0])}>
                        <img src={images[0]} className="w-full h-full object-cover hover:scale-105 transition-transform duration-500" />
                    </div>
                    <div className="flex flex-col gap-0.5 h-full">
                        <div className="h-1/2 cursor-pointer overflow-hidden" onClick={() => setLightbox(images[1])}>
                            <img src={images[1]} className="w-full h-full object-cover hover:scale-105 transition-transform duration-500" />
                        </div>
                        <div className="h-1/2 cursor-pointer overflow-hidden" onClick={() => setLightbox(images[2])}>
                            <img src={images[2]} className="w-full h-full object-cover hover:scale-105 transition-transform duration-500" />
                        </div>
                    </div>
                </div>
            )}

            {count >= 4 && (
                <div className="grid grid-cols-2 gap-0.5 h-96">
                    <div className="cursor-pointer overflow-hidden" onClick={() => setLightbox(images[0])}>
                        <img src={images[0]} className="w-full h-full object-cover hover:scale-105 transition-transform duration-500" />
                    </div>
                    <div className="cursor-pointer overflow-hidden" onClick={() => setLightbox(images[1])}>
                        <img src={images[1]} className="w-full h-full object-cover hover:scale-105 transition-transform duration-500" />
                    </div>
                    <div className="cursor-pointer overflow-hidden" onClick={() => setLightbox(images[2])}>
                         <img src={images[2]} className="w-full h-full object-cover hover:scale-105 transition-transform duration-500" />
                    </div>
                    <div className="cursor-pointer overflow-hidden relative" onClick={() => setLightbox(images[3])}>
                        <img src={images[3]} className="w-full h-full object-cover hover:scale-105 transition-transform duration-500" />
                        {count > 4 && (
                            <div className="absolute inset-0 bg-black/50 flex items-center justify-center text-white font-bold text-3xl">
                                +{count - 4}
                            </div>
                        )}
                    </div>
                </div>
            )}
          </div>
      );
  };

  return (
    <div className="space-y-6 pb-24 animate-fade-in max-w-2xl mx-auto" onClick={() => setOpenMenuId(null)}>
      {lightbox && createPortal(
           <div className="fixed inset-0 bg-black/95 z-[500] flex flex-col justify-center items-center" onClick={() => setLightbox(null)}>
               <button className="absolute top-4 right-4 text-white p-2 bg-white/10 rounded-full"><X size={24} /></button>
               <img src={lightbox} className="max-w-full max-h-[90vh] object-contain" onClick={e => e.stopPropagation()} />
           </div>, document.body
      )}

      {/* Hero Header */}
      <div className="flex justify-between items-end px-2">
          <div>
            <h1 className={`text-2xl font-bold ${themeClasses.textMain}`}>{getGreeting()},</h1>
            <p className={`${themeClasses.textSub} text-sm font-medium`}>{userProfile?.displayName}</p>
          </div>
          <div className={`${themeClasses.cardBg} px-3 py-1 rounded-full border ${themeClasses.border} shadow-sm`}>
             <p className={`text-xs font-bold ${themeClasses.textSub}`}>
                {currentTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
             </p>
          </div>
      </div>

      {/* Create Post Button */}
      <div className={`${themeClasses.cardBg} rounded-[2rem] p-4 shadow-sm border ${themeClasses.border}`}>
            <div className="flex gap-3 items-center">
                 <img src={userProfile?.photoURL} className="w-12 h-12 rounded-full bg-gray-200 object-cover border border-gray-100" />
                 <button 
                    onClick={() => setShowQuickPost(true)}
                    className={`flex-1 text-left px-5 py-3.5 rounded-full bg-gray-100 dark:bg-slate-800 ${themeClasses.textSub} text-sm hover:bg-gray-200 transition-colors border border-transparent`}
                 >
                    What's on your mind?
                 </button>
                 <button onClick={() => setShowQuickPost(true)} className="p-3 text-green-500 hover:bg-green-50 rounded-full transition-colors">
                     <ImageIcon size={24} />
                 </button>
            </div>
      </div>

      {/* Full Screen Post Creator */}
      {showQuickPost && createPortal(
          <div className={`fixed inset-0 z-[200] ${themeClasses.cardBg} flex flex-col animate-slide-in-up`}>
              <div className={`p-4 flex justify-between items-center border-b ${themeClasses.border}`}>
                  <div className="flex items-center gap-3">
                      <button onClick={() => setShowQuickPost(false)} className="p-2 -ml-2 rounded-full hover:bg-gray-100 dark:hover:bg-slate-800">
                          <X size={24} className={themeClasses.textMain} />
                      </button>
                      <h2 className={`font-bold text-lg ${themeClasses.textMain}`}>Create Post</h2>
                  </div>
                  <button 
                    onClick={handleQuickPost} 
                    disabled={isPosting || (!postContent && postFiles.length === 0)}
                    className={`px-6 py-2 rounded-full font-bold text-white shadow-lg ${primaryColor} ${isPosting ? 'opacity-50' : ''}`}
                  >
                      {isPosting ? 'Posting...' : 'Post'}
                  </button>
              </div>
              
              <div className="flex-1 overflow-y-auto p-4">
                  <div className="flex items-center gap-3 mb-4">
                      <img src={userProfile?.photoURL} className="w-12 h-12 rounded-full object-cover" />
                      <div>
                          <p className={`font-bold ${themeClasses.textMain}`}>{userProfile?.displayName}</p>
                          <div className="flex items-center gap-1 text-xs text-gray-500 bg-gray-100 dark:bg-slate-800 px-2 py-0.5 rounded w-fit"><User size={10} /> Public</div>
                      </div>
                  </div>

                  <div className={`min-h-[200px] flex items-center justify-center rounded-xl transition-all ${postFiles.length === 0 ? postBg : 'bg-transparent'}`}>
                    <textarea 
                        className={`w-full bg-transparent outline-none resize-none p-4 ${postBg !== 'bg-white' && postFiles.length === 0 ? 'text-center text-2xl font-bold text-white placeholder-white/70 h-full' : `text-xl ${themeClasses.textMain} placeholder-gray-400 h-40`}`}
                        placeholder="What's on your mind?"
                        value={postContent}
                        onChange={e => setPostContent(e.target.value)}
                        autoFocus
                    />
                  </div>
                  
                  {postFiles.length === 0 && (
                       <div className="mt-4 flex gap-2 overflow-x-auto pb-2 no-scrollbar">
                           <button onClick={() => setPostBg('bg-white')} className={`w-8 h-8 rounded-full border border-gray-300 bg-white ${postBg === 'bg-white' ? 'ring-2 ring-indigo-500' : ''}`}></button>
                           {POST_BACKGROUNDS.filter(b => b !== 'bg-white').map(bg => (
                               <button key={bg} onClick={() => setPostBg(bg)} className={`w-8 h-8 rounded-full shadow-sm shrink-0 border border-transparent ${bg} ${postBg === bg ? 'ring-2 ring-indigo-500 scale-110' : ''}`}></button>
                           ))}
                       </div>
                   )}

                  {postFiles.length > 0 && (
                      <div className="grid grid-cols-2 gap-2 mt-4">
                          {postFiles.map((file, idx) => (
                              <div key={idx} className="relative rounded-xl overflow-hidden h-32 bg-gray-100 border border-gray-200">
                                  <img src={URL.createObjectURL(file)} className="w-full h-full object-cover" />
                                  <button onClick={() => setPostFiles(prev => prev.filter((_, i) => i !== idx))} className="absolute top-1 right-1 bg-black/50 text-white p-1 rounded-full"><X size={12}/></button>
                              </div>
                          ))}
                          <label className="flex flex-col items-center justify-center h-32 rounded-xl border-2 border-dashed border-gray-300 bg-gray-50 dark:bg-slate-800 cursor-pointer">
                              <Plus size={24} className="text-gray-400" />
                              <span className="text-xs text-gray-500 font-bold mt-2">Add More</span>
                              <input type="file" multiple className="hidden" accept="image/*" onChange={handleFileSelect} />
                          </label>
                      </div>
                  )}
              </div>

              <div className={`p-4 border-t ${themeClasses.border}`}>
                  <div className={`rounded-xl p-3 shadow-sm border ${themeClasses.border} flex justify-between items-center bg-white dark:bg-slate-800`}>
                      <span className={`font-bold text-sm ${themeClasses.textMain} pl-2`}>Add to your post</span>
                      <div className="flex gap-2">
                          <label className="p-2 hover:bg-green-50 rounded-full cursor-pointer text-green-500">
                              <ImageIcon size={24} />
                              <input type="file" multiple className="hidden" accept="image/*" onChange={handleFileSelect} />
                          </label>
                      </div>
                  </div>
              </div>
          </div>, document.body
      )}

      {/* Feed */}
      <div className="space-y-6">
          {feedItems.map((item: any) => {
              const isNotice = item.type === 'notice';
              const data = item.data;
              const images = data.images || (data.imageUrl ? [data.imageUrl] : []);
              const isLiked = userProfile?.uid ? (data.likes?.includes(userProfile.uid)) : false;
              
              const canDelete = userProfile?.uid === data.createdBy?.uid || userProfile?.role === 'admin' || SUPER_ADMINS.includes(userProfile?.email || '');

              return (
                  <div 
                    key={item.type + data.id} 
                    className={`${themeClasses.cardBg} rounded-[2rem] p-0 shadow-sm border ${themeClasses.border} overflow-hidden`}
                  >
                      {/* Post Header */}
                      <div className="p-4 flex items-center gap-3 relative">
                           <div className={`w-10 h-10 rounded-full overflow-hidden border ${themeClasses.border}`}>
                               {isNotice ? (
                                   <div className="w-full h-full bg-pink-100 flex items-center justify-center text-pink-600 font-bold">N</div>
                               ) : (
                                   <img src={data.createdBy?.photoURL || `https://ui-avatars.com/api/?name=${data.createdBy?.name}`} className="w-full h-full object-cover" />
                               )}
                           </div>
                           <div className="flex-1">
                               <div className="flex justify-between items-start">
                                   <h3 className={`font-bold text-base ${themeClasses.textMain}`}>{isNotice ? data.postedBy : data.createdBy?.name}</h3>
                                   {isNotice && <span className="bg-pink-100 text-pink-600 px-2 py-0.5 rounded text-[10px] font-bold uppercase">Notice</span>}
                               </div>
                               <p className={`text-xs ${themeClasses.textSub} opacity-80 flex items-center gap-1`}>
                                   {new Date(item.date).toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' })} • <Layers size={10} />
                               </p>
                           </div>
                           
                           {/* Post Options (Delete) */}
                           {!isNotice && canDelete && (
                               <div className="relative">
                                   <button 
                                        onClick={(e) => { e.stopPropagation(); setOpenMenuId(openMenuId === data.id ? null : data.id); }}
                                        className="text-gray-400 p-2 hover:bg-gray-100 rounded-full transition-colors"
                                   >
                                       <MoreHorizontal size={20} />
                                   </button>
                                   {openMenuId === data.id && (
                                       <div className={`absolute right-0 top-full mt-2 w-32 ${themeClasses.cardBg} shadow-xl rounded-xl border ${themeClasses.border} overflow-hidden z-20 animate-fade-in`}>
                                           <button onClick={() => handleDeletePost(data.id)} className="w-full text-left px-4 py-3 text-red-500 text-xs font-bold hover:bg-red-50 flex items-center gap-2">
                                               <Trash2 size={14} /> Delete
                                           </button>
                                       </div>
                                   )}
                               </div>
                           )}
                      </div>
                      
                      {/* Content */}
                      {isNotice && <h4 className={`px-4 font-bold text-lg mb-1 ${themeClasses.textMain}`}>{data.title}</h4>}
                      
                      {isNotice ? (
                          <div className="px-4 pb-2">
                             <p className={`text-sm ${themeClasses.textMain} whitespace-pre-wrap leading-relaxed`}>{data.content}</p>
                          </div>
                      ) : (
                         <FeedText text={data.description} bg={data.background} isImage={images.length > 0} />
                      )}

                      {/* Media Grid */}
                      {images.length > 0 && renderImageGrid(images)}
                      
                      {/* Footer Actions */}
                      <div className="p-3 flex justify-between items-center border-t border-gray-50 dark:border-slate-800 mt-2">
                          <div className="flex gap-4 w-full">
                               <button 
                                  onClick={() => handleLike(data.id, data.likes, isNotice ? 'notices' : 'posts')}
                                  className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-lg hover:bg-gray-50 dark:hover:bg-slate-800 transition-colors font-bold text-sm ${isLiked ? 'text-pink-500' : 'text-gray-500'}`}
                               >
                                   <Heart fill={isLiked ? "currentColor" : "none"} size={20} className={isLiked ? "animate-bounce" : ""} /> 
                                   Like {data.likes?.length > 0 && <span>({data.likes.length})</span>}
                               </button>
                               
                               <button 
                                  onClick={() => isNotice ? navigate('/notice') : setActiveCommentPostId(data.id)}
                                  className="flex-1 flex items-center justify-center gap-2 py-2 rounded-lg hover:bg-gray-50 dark:hover:bg-slate-800 text-gray-500 font-bold text-sm transition-colors"
                               >
                                   <MessageCircle size={20} /> Comment
                               </button>
                          </div>
                      </div>
                  </div>
              );
          })}
          {feedItems.length === 0 && (
              <div className="p-10 text-center text-gray-400">
                  <p>No posts yet. Be the first to share something!</p>
              </div>
          )}
      </div>

      {activeCommentPostId && <PostCommentsDrawer postId={activeCommentPostId} onClose={() => setActiveCommentPostId(null)} />}
    </div>
  );
};

export default Home;
