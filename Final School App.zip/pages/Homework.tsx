
import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { 
  collection, addDoc, query, onSnapshot, where, 
  updateDoc, doc, arrayUnion, arrayRemove, deleteDoc
} from 'firebase/firestore';
import { db } from '../firebase';
import { uploadImageToImgBB } from '../services/imgbbService';
import { Homework as IHomework, Comment, SUPER_ADMINS, POST_BACKGROUNDS } from '../types';
import { 
  Plus, X, Send, Heart, MessageCircle, Trash2, ZoomIn, ZoomOut, Image as ImageIcon, MoreHorizontal, Calendar, BookOpen
} from 'lucide-react';
import { createPortal } from 'react-dom';

// --- FB Style Comments Drawer (Using Portal for Z-Index Safety) ---
const CommentsDrawer: React.FC<{ homeworkId: string, onClose: () => void }> = ({ homeworkId, onClose }) => {
    const { userProfile } = useAuth();
    const { themeClasses } = useTheme();
    const [comments, setComments] = useState<Comment[]>([]);
    const [newComment, setNewComment] = useState('');
    const [replyTo, setReplyTo] = useState<{id: string, name: string} | null>(null);

    useEffect(() => {
        const q = query(collection(db, 'homework_comments'), where('homeworkId', '==', homeworkId));
        const unsub = onSnapshot(q, snap => {
            const data = snap.docs.map(d => ({ id: d.id, ...d.data() } as Comment));
            data.sort((a, b) => a.timestamp - b.timestamp);
            setComments(data);
        });
        return unsub;
    }, [homeworkId]);

    const handleSend = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!newComment.trim() || !userProfile) return;
        
        await addDoc(collection(db, 'homework_comments'), {
            homeworkId, 
            userId: userProfile.uid, 
            userName: userProfile.displayName,
            userPhoto: userProfile.photoURL, 
            text: newComment, 
            timestamp: Date.now(),
            parentId: replyTo?.id || null
        });
        setNewComment('');
        setReplyTo(null);
    };

    const handleDelete = async (id: string) => {
        if(window.confirm("Are you sure you want to delete this comment?")) {
            await deleteDoc(doc(db, 'homework_comments', id));
        }
    };

    // Render using Portal to ensure it sits on top of EVERYTHING
    return createPortal(
        <div className="fixed inset-0 z-[400] flex flex-col justify-end md:justify-center md:items-center">
             <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose}></div>
             
             <div className={`${themeClasses.cardBg} w-full md:w-[500px] md:h-[600px] h-[85%] rounded-t-[2.5rem] md:rounded-3xl shadow-2xl z-10 flex flex-col relative animate-slide-in-up border-t border-white/20`}>
                <div className={`p-4 border-b ${themeClasses.border} flex justify-between items-center`}>
                    <h3 className={`font-bold ${themeClasses.textMain}`}>Comments ({comments.length})</h3>
                    <button onClick={onClose} className={`p-2 rounded-full ${themeClasses.accentBg}`}><X size={18} /></button>
                </div>

                <div className="flex-1 overflow-y-auto p-4 space-y-4">
                    {comments.length === 0 && <div className="text-center text-gray-400 py-10">No comments yet. Be the first!</div>}
                    {comments.map(c => {
                        const isReply = !!c.parentId;
                        const isMine = userProfile?.uid === c.userId;
                        const isAdmin = userProfile?.role === 'admin' || SUPER_ADMINS.includes(userProfile?.email || '');
                        
                        return (
                            <div key={c.id} className={`flex gap-3 ${isReply ? 'ml-10' : ''}`}>
                                <img src={c.userPhoto} className="w-8 h-8 rounded-full border border-gray-200" />
                                <div className="flex-1">
                                    <div className={`${themeClasses.accentBg} p-3 rounded-2xl rounded-tl-none inline-block`}>
                                        <p className={`font-bold text-sm ${themeClasses.textMain}`}>{c.userName}</p>
                                        <p className={`text-sm ${themeClasses.textSub} opacity-90`}>{c.text}</p>
                                    </div>
                                    <div className="flex gap-4 text-[10px] text-gray-500 mt-1 pl-2 font-bold uppercase tracking-wide">
                                        <button className="hover:text-indigo-500">Like</button>
                                        <button onClick={() => setReplyTo({id: c.id, name: c.userName})} className="hover:text-indigo-500">Reply</button>
                                        {(isMine || isAdmin) && (
                                            <button onClick={() => handleDelete(c.id)} className="text-red-500">Delete</button>
                                        )}
                                    </div>
                                </div>
                            </div>
                        )
                    })}
                </div>

                <form onSubmit={handleSend} className={`p-4 border-t ${themeClasses.border} ${themeClasses.cardBg} pb-8 md:pb-4`}>
                    {replyTo && (
                        <div className="flex justify-between text-xs text-indigo-500 mb-2 bg-indigo-50 p-2 rounded-lg">
                            <span>Replying to {replyTo.name}</span>
                            <button onClick={() => setReplyTo(null)}><X size={12} /></button>
                        </div>
                    )}
                    <div className="flex gap-2">
                        <input 
                            className={`flex-1 rounded-full px-5 py-3 outline-none shadow-inner text-sm ${themeClasses.accentBg} ${themeClasses.textMain}`}
                            placeholder="Write a comment..." 
                            value={newComment} 
                            onChange={e => setNewComment(e.target.value)}
                        />
                        <button type="submit" className={`text-white p-3 rounded-full shadow-lg ${themeClasses.textMain === 'text-white' ? 'bg-indigo-600' : 'bg-black'}`}><Send size={18} /></button>
                    </div>
                </form>
             </div>
        </div>,
        document.body
    );
}

const Homework: React.FC = () => {
  const { userProfile } = useAuth();
  const { playSound, primaryColor, themeClasses } = useTheme();
  
  const [showCreate, setShowCreate] = useState(false);
  const [homeworkList, setHomeworkList] = useState<IHomework[]>([]);
  const [activeCommentId, setActiveCommentId] = useState<string | null>(null);
  const [lightbox, setLightbox] = useState<string | null>(null);
  const [zoom, setZoom] = useState(1);
  const [openMenuId, setOpenMenuId] = useState<string | null>(null);

  // Create Post State
  const [postText, setPostText] = useState('');
  const [postBg, setPostBg] = useState(POST_BACKGROUNDS[0]);
  const [postFile, setPostFile] = useState<File | null>(null);
  const [postMeta, setPostMeta] = useState({ title: '', subject: '', date: '', class: userProfile?.className || '6' });
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    let q = query(collection(db, 'homework'));
    if (userProfile?.role === 'student' && userProfile?.className) {
        // Students ONLY see posts for their class
        q = query(collection(db, 'homework'), where('classGrade', '==', userProfile.className));
    }
    const unsubscribe = onSnapshot(q, (snapshot) => {
        // Strict Filtering and Sorting
        const hw = snapshot.docs
            .map(doc => ({ id: doc.id, ...doc.data() } as IHomework))
            .filter(item => item.createdBy && item.createdBy.name && item.createdAt);
            
        // Safe sort
        hw.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
        setHomeworkList(hw);
    });
    return unsubscribe;
  }, [userProfile]);

  const handlePost = async () => {
      if(!userProfile) return;
      setLoading(true);
      try {
          let imageUrl = '';
          if (postFile) imageUrl = await uploadImageToImgBB(postFile);
          
          await addDoc(collection(db, 'homework'), {
              title: postMeta.title || 'Homework',
              subject: postMeta.subject || 'General',
              description: postText,
              imageUrl,
              background: !postFile ? postBg : '', 
              classGrade: postMeta.class,
              section: 'A',
              dueDate: postMeta.date,
              createdBy: { uid: userProfile.uid, name: userProfile.displayName, role: userProfile.role, photoURL: userProfile.photoURL },
              createdAt: Date.now(),
              likes: []
          });
          setShowCreate(false);
          setPostText(''); setPostBg(POST_BACKGROUNDS[0]); setPostFile(null);
      } catch (e) { 
          console.error(e); 
          alert("Failed to post. Check connection."); 
      } finally { 
          setLoading(false); 
      }
  };

  const handleDelete = async (id: string, e: React.MouseEvent) => {
      e.preventDefault();
      e.stopPropagation();
      setOpenMenuId(null);
      
      const confirmDelete = window.confirm("Are you sure you want to delete this post?");
      if(confirmDelete) {
        try {
            await deleteDoc(doc(db, 'homework', id));
            playSound('success');
        } catch(e: any) { 
            console.error(e); 
            alert(`Failed to delete. Error: ${e.message}.`);
        }
      }
  };

  const toggleLike = async (hw: IHomework, e: React.MouseEvent) => {
      e.stopPropagation();
      if(!userProfile) return;
      playSound('click');
      const ref = doc(db, 'homework', hw.id);
      
      const uid = userProfile.uid;
      const isLiked = hw.likes?.includes(uid);
      
      try {
          if (isLiked) {
              await updateDoc(ref, { likes: arrayRemove(uid) });
          } else {
              await updateDoc(ref, { likes: arrayUnion(uid) });
          }
      } catch (err) {
          console.error("Like error", err);
      }
  };

  const isAdmin = userProfile && (userProfile.role === 'admin' || SUPER_ADMINS.includes(userProfile.email));
  const isOwner = (uid: string) => userProfile?.uid === uid;
  const isStudent = userProfile?.role === 'student';

  return (
    <div className="space-y-6 pb-24" onClick={() => setOpenMenuId(null)}>
       {/* Lightbox */}
       {lightbox && createPortal(
           <div className="fixed inset-0 bg-black/95 z-[500] flex flex-col justify-center items-center" onClick={() => setLightbox(null)}>
               <button className="absolute top-4 right-4 text-white p-2 bg-white/10 rounded-full backdrop-blur-md"><X size={24} /></button>
               <img src={lightbox} style={{ transform: `scale(${zoom})` }} className="max-w-full max-h-[80vh] transition-transform duration-200" onClick={e => e.stopPropagation()} />
               <div className="absolute bottom-10 flex gap-4" onClick={e => e.stopPropagation()}>
                   <button onClick={() => setZoom(Math.max(1, zoom - 0.5))} className="p-4 bg-white/20 rounded-full text-white backdrop-blur-md hover:bg-white/30"><ZoomOut /></button>
                   <button onClick={() => setZoom(Math.min(3, zoom + 0.5))} className="p-4 bg-white/20 rounded-full text-white backdrop-blur-md hover:bg-white/30"><ZoomIn /></button>
               </div>
           </div>, document.body
       )}

       <div className="flex justify-between items-center sticky top-0 z-10 py-2 backdrop-blur-sm">
           <div>
               <h1 className={`text-2xl font-bold ${themeClasses.textMain}`}>Homework & Tasks</h1>
               {isStudent && <p className="text-xs text-gray-500 font-bold">Class {userProfile.className}</p>}
           </div>
           
           <button onClick={() => setShowCreate(true)} className={`px-5 py-2.5 rounded-full text-white font-bold flex items-center gap-2 shadow-lg hover:shadow-xl hover:scale-105 transition-all ${primaryColor}`}>
               <Plus size={20} /> New Post
           </button>
       </div>

       {showCreate && createPortal(
          // Use Portal to break out of main container stacking context
          <div className={`fixed inset-0 z-[300] ${themeClasses.cardBg} flex flex-col animate-fade-in`}>
              <div className={`p-4 flex justify-between items-center border-b ${themeClasses.border}`}>
                  <button onClick={() => setShowCreate(false)} className={`p-2 rounded-full ${themeClasses.accentBg}`}><X className={themeClasses.textMain}/></button>
                  <h2 className={`font-bold text-lg ${themeClasses.textMain}`}>Create Post</h2>
                  <button onClick={handlePost} disabled={loading} className={`px-6 py-2 rounded-full font-bold text-white shadow-lg ${primaryColor} ${loading ? 'opacity-50' : ''}`}>
                      {loading ? 'Posting...' : 'Post'}
                  </button>
              </div>
              
              <div className="flex-1 overflow-y-auto p-4 max-w-2xl mx-auto w-full">
                   <div className="space-y-3 mb-4">
                       <input className={`w-full p-4 rounded-2xl outline-none ${themeClasses.accentBg} ${themeClasses.textMain}`} placeholder="Homework Title" value={postMeta.title} onChange={e => setPostMeta({...postMeta, title: e.target.value})} />
                       <div className="flex gap-3">
                           <div className={`flex-1 flex items-center px-4 rounded-2xl ${themeClasses.accentBg}`}>
                                <BookOpen size={18} className="text-gray-400 mr-2"/>
                                <input className={`w-full py-4 bg-transparent outline-none ${themeClasses.textMain}`} placeholder="Subject" value={postMeta.subject} onChange={e => setPostMeta({...postMeta, subject: e.target.value})} />
                           </div>
                           
                           {/* Only show class selector if NOT a student (Teachers can post to any class) */}
                           {!isStudent ? (
                               <select className={`p-3 rounded-xl outline-none ${themeClasses.accentBg} ${themeClasses.textMain}`} value={postMeta.class} onChange={e => setPostMeta({...postMeta, class: e.target.value})}>
                                    {[6,7,8,9,10].map(c => <option key={c} value={c}>Class {c}</option>)}
                               </select>
                           ) : (
                               <div className="flex items-center px-4 font-bold text-gray-500">
                                   Class {postMeta.class}
                               </div>
                           )}
                       </div>
                       
                       <div className={`flex items-center px-4 rounded-2xl ${themeClasses.accentBg}`}>
                            <Calendar size={18} className="text-gray-400 mr-2"/>
                            <input type="date" className={`w-full py-4 bg-transparent outline-none ${themeClasses.textMain}`} value={postMeta.date} onChange={e => setPostMeta({...postMeta, date: e.target.value})} />
                       </div>
                   </div>

                   <div className={`w-full h-64 rounded-3xl flex items-center justify-center p-8 text-center transition-all relative overflow-hidden shadow-inner ${!postFile ? postBg : 'bg-gray-100'}`}>
                       {postFile ? (
                           <>
                             <img src={URL.createObjectURL(postFile)} className="w-full h-full object-contain" />
                             <button onClick={() => setPostFile(null)} className="absolute top-4 right-4 bg-black/50 text-white p-2 rounded-full backdrop-blur-md"><X size={16}/></button>
                           </>
                       ) : (
                           <textarea 
                             className={`w-full h-full bg-transparent border-none outline-none text-center resize-none placeholder-white/70 font-bold text-2xl ${postBg === 'bg-white' ? 'text-gray-900 placeholder-gray-400' : 'text-white'}`}
                             placeholder="What's the assignment?"
                             value={postText}
                             onChange={e => setPostText(e.target.value)}
                           />
                       )}
                   </div>

                   {!postFile && (
                       <div className="mt-6">
                           <div className="flex gap-3 overflow-x-auto pb-2">
                               {POST_BACKGROUNDS.map(bg => (
                                   <button key={bg} onClick={() => setPostBg(bg)} className={`w-10 h-10 rounded-full shadow-sm shrink-0 border-2 transition-transform hover:scale-110 ${bg} ${postBg === bg ? 'border-black scale-110' : 'border-transparent'}`}></button>
                               ))}
                           </div>
                       </div>
                   )}

                   <div className={`mt-6 border-t pt-6 ${themeClasses.border}`}>
                       <label className={`flex items-center gap-3 font-bold cursor-pointer p-4 rounded-2xl hover:bg-gray-50 dark:hover:bg-slate-800 transition-colors ${themeClasses.textMain}`}>
                           <div className="p-3 bg-green-100 text-green-600 rounded-full"><ImageIcon size={24} /></div>
                           <div>
                               <p>Photo/Video</p>
                               <p className="text-xs font-normal opacity-60">Add attachments to your post</p>
                           </div>
                           <input type="file" className="hidden" onChange={e => { setPostFile(e.target.files?.[0] || null); setPostBg('bg-white'); }} />
                       </label>
                   </div>
              </div>
          </div>, document.body
       )}

       <div className="max-w-xl mx-auto space-y-6">
           {homeworkList.map((hw) => {
               if (!hw.createdBy || !hw.createdBy.name) return null;

               const canDelete = isOwner(hw.createdBy.uid) || isAdmin;
               const isLiked = userProfile?.uid ? hw.likes?.includes(userProfile.uid) : false;
               
               return (
                   <div key={hw.id} className={`${themeClasses.cardBg} rounded-3xl shadow-sm overflow-hidden border ${themeClasses.border}`}>
                       {/* Header */}
                       <div className="p-4 flex items-center gap-3 relative">
                           <img src={hw.createdBy.photoURL || `https://ui-avatars.com/api/?name=${hw.createdBy.name}`} className="w-10 h-10 rounded-full object-cover border-2 border-gray-100" />
                           <div className="flex-1">
                               <p className={`font-bold text-sm leading-none mb-1 ${themeClasses.textMain}`}>{hw.createdBy.name}</p>
                               <p className={`text-[10px] font-medium uppercase tracking-wide opacity-60 ${themeClasses.textSub}`}>
                                   {hw.createdAt ? new Date(hw.createdAt).toDateString() : 'Just now'} • {hw.subject} • Class {hw.classGrade}
                               </p>
                           </div>
                           {canDelete && (
                               <div className="relative">
                                   <button 
                                        onClick={(e) => { e.stopPropagation(); setOpenMenuId(openMenuId === hw.id ? null : hw.id); }} 
                                        className="p-2 text-gray-400 hover:bg-gray-100 dark:hover:bg-slate-700 rounded-full transition-colors"
                                   >
                                        <MoreHorizontal size={18} />
                                   </button>
                                   {openMenuId === hw.id && (
                                       <div className={`absolute right-0 top-full mt-2 shadow-2xl rounded-2xl p-2 z-20 w-48 border ${themeClasses.cardBg} ${themeClasses.border} animate-fade-in-up`}>
                                           <button onClick={(e) => handleDelete(hw.id, e)} className="w-full text-left px-4 py-3 text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 rounded-xl text-sm flex items-center gap-3 font-bold transition-colors">
                                               <Trash2 size={16} /> Delete Post
                                           </button>
                                       </div>
                                   )}
                               </div>
                           )}
                       </div>

                       {/* Content */}
                       <div className="px-4 pb-2">
                        <p className={`text-sm leading-relaxed mb-3 ${themeClasses.textMain}`}>{hw.description}</p>
                        
                        {hw.imageUrl ? (
                             <div className="rounded-xl overflow-hidden bg-black/5 border dark:border-slate-700 cursor-pointer relative group" onClick={() => { setLightbox(hw.imageUrl!); setZoom(1); }}>
                                    <img src={hw.imageUrl} className="w-full max-h-80 object-cover" />
                                    <div className="absolute inset-0 bg-black/20 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                                        <ZoomIn className="text-white drop-shadow-lg" size={48} />
                                    </div>
                             </div>
                        ) : (
                             hw.background && (
                                <div className={`w-full aspect-video rounded-xl flex items-center justify-center p-6 text-center shadow-inner ${hw.background}`}>
                                    <p className={`text-xl font-bold leading-snug ${hw.background.includes('bg-white') ? 'text-gray-900' : 'text-white'}`}>{hw.description}</p>
                                </div>
                             )
                        )}
                       </div>

                       {/* Footer Actions */}
                       <div className="p-3 border-t border-gray-100 dark:border-slate-700 flex items-center justify-between">
                           <div className="flex gap-4">
                                <button onClick={(e) => toggleLike(hw, e)} className={`flex items-center gap-2 transition-transform active:scale-90 ${isLiked ? 'text-pink-500' : 'text-gray-400'}`}>
                                    <Heart size={22} fill={isLiked ? "currentColor" : "none"} strokeWidth={isLiked ? 0 : 2} /> 
                                    <span className="font-bold text-xs">{hw.likes?.length || 0}</span>
                                </button>
                                <button onClick={() => setActiveCommentId(hw.id)} className="flex items-center gap-2 text-gray-400 hover:text-indigo-500 transition-colors">
                                    <MessageCircle size={22} />
                                </button>
                           </div>
                       </div>
                   </div>
               )
           })}
           {homeworkList.length === 0 && (
               <div className="text-center py-20 opacity-50">
                   <BookOpen size={64} className="mx-auto mb-4 text-gray-300" />
                   <h2 className="text-xl font-bold">No posts for Class {userProfile.className}</h2>
                   <p>Be the first to post homework!</p>
               </div>
           )}
       </div>

       {activeCommentId && <CommentsDrawer homeworkId={activeCommentId} onClose={() => setActiveCommentId(null)} />}
    </div>
  );
};

export default Homework;
