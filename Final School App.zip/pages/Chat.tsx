
import React, { useEffect, useState, useRef } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { ref, push, onValue, serverTimestamp, set, remove } from 'firebase/database';
import { collection, query, where, getDocs } from 'firebase/firestore';
import { rtdb, db } from '../firebase';
import { uploadImageToImgBB } from '../services/imgbbService';
import { 
  Send, ArrowLeft, Image as ImageIcon, Search, Trash2, Reply, X, MessageCircle
} from 'lucide-react';
import { ChatMessage, UserProfile } from '../types';

interface ChatUser {
    uid: string;
    name: string;
    photoURL?: string;
    role: string;
    lastMsg?: string;
    timestamp?: number;
}

interface Message extends ChatMessage {
    replyTo?: {
        id: string;
        text: string;
        senderName: string;
    } | null;
}

const Chat: React.FC = () => {
  const { userProfile, currentUser } = useAuth();
  const { themeClasses, playSound, primaryColor } = useTheme();
  
  // States
  const [activeChatId, setActiveChatId] = useState<string | null>(null);
  const [activeChatUser, setActiveChatUser] = useState<ChatUser | null>(null);
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState('');
  const [contactList, setContactList] = useState<ChatUser[]>([]);
  const [loadingContacts, setLoadingContacts] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [replyTo, setReplyTo] = useState<Message | null>(null);
  const [selectedMsgId, setSelectedMsgId] = useState<string | null>(null);

  const bottomRef = useRef<HTMLDivElement>(null);
  const isTeacherOrAdmin = userProfile?.role === 'admin' || userProfile?.role === 'teacher';

  // 1. Load Contact List
  useEffect(() => {
    if (!currentUser) return;

    const loadContacts = async () => {
        setLoadingContacts(true);
        try {
            if (!isTeacherOrAdmin) {
                // STUDENT VIEW: Load all Teachers and Admins
                const q = query(collection(db, 'users'), where('role', 'in', ['admin', 'teacher']));
                const snap = await getDocs(q);
                const staff = snap.docs.map(d => {
                    const data = d.data() as UserProfile;
                    return {
                        uid: d.id,
                        name: data.displayName || 'Unknown Staff',
                        photoURL: data.photoURL,
                        role: data.role,
                        lastMsg: '',
                        timestamp: 0
                    } as ChatUser;
                });
                setContactList(staff);
            } else {
                // TEACHER VIEW: Load Inbox from RTDB
                const chatsRef = ref(rtdb, 'chats');
                onValue(chatsRef, (snapshot) => {
                    const data = snapshot.val();
                    if (data) {
                        const contacts: ChatUser[] = [];
                        Object.keys(data).forEach(roomId => {
                            if (roomId.includes(currentUser.uid)) {
                                const otherUid = roomId.replace(currentUser.uid, '').replace('_', '');
                                const msgs = data[roomId].messages;
                                let lastMsg = '';
                                let ts = 0;
                                
                                if (msgs) {
                                    const keys = Object.keys(msgs);
                                    const last = msgs[keys[keys.length-1]];
                                    lastMsg = last.text.startsWith('http') ? '📷 Photo' : last.text;
                                    ts = last.timestamp;
                                }

                                const meta = data[roomId]?.meta?.[otherUid] || { name: 'Student', photo: '' };
                                
                                contacts.push({
                                    uid: otherUid,
                                    name: meta.name || 'Student',
                                    photoURL: meta.photo,
                                    role: 'student',
                                    lastMsg,
                                    timestamp: ts
                                });
                            }
                        });
                        contacts.sort((a,b) => (b.timestamp || 0) - (a.timestamp || 0));
                        setContactList(contacts);
                    }
                    setLoadingContacts(false);
                });
            }
        } catch (e) {
            console.error("Error loading chats", e);
        } finally {
            if(!isTeacherOrAdmin) setLoadingContacts(false);
        }
    };
    loadContacts();
  }, [currentUser, isTeacherOrAdmin]);

  // 2. Load Messages
  useEffect(() => {
      if (!activeChatId) return;
      const chatRef = ref(rtdb, `chats/${activeChatId}/messages`);
      const unsub = onValue(chatRef, (snapshot) => {
          const data = snapshot.val();
          setMessages(data ? Object.entries(data).map(([k, v]: [string, any]) => ({ id: k, ...v })) : []);
      });
      return () => unsub();
  }, [activeChatId]);

  useEffect(() => { bottomRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages, replyTo]);

  const openChat = (targetUser: ChatUser) => {
      if (!currentUser) return;
      playSound('click');
      const roomId = [currentUser.uid, targetUser.uid].sort().join('_');
      setActiveChatId(roomId);
      setActiveChatUser(targetUser);
  };

  const handleSend = async (e?: React.FormEvent, imageUrl?: string) => {
      if (e) e.preventDefault();
      
      const msgText = imageUrl ? imageUrl : newMessage.trim();
      
      if (!msgText || !currentUser || !activeChatId) return;

      const chatRef = ref(rtdb, `chats/${activeChatId}/messages`);
      
      const payload: any = {
          text: msgText,
          type: imageUrl ? 'image' : 'text',
          senderId: currentUser.uid,
          senderName: userProfile?.displayName || 'User',
          timestamp: serverTimestamp(),
          isAdmin: isTeacherOrAdmin
      };

      if (replyTo) {
          payload.replyTo = {
              id: replyTo.id,
              text: replyTo.text,
              senderName: replyTo.senderName
          };
      }

      try {
          await push(chatRef, payload);
          
          // Update Meta
          const myMetaRef = ref(rtdb, `chats/${activeChatId}/meta/${currentUser.uid}`);
          set(myMetaRef, { name: userProfile?.displayName, photo: userProfile?.photoURL || '' });

          if(activeChatUser) {
            const otherMetaRef = ref(rtdb, `chats/${activeChatId}/meta/${activeChatUser.uid}`);
            set(otherMetaRef, { name: activeChatUser.name, photo: activeChatUser.photoURL || '' });
          }

          setNewMessage('');
          setReplyTo(null);
          playSound('success');
      } catch (error: any) {
          console.error(error);
          alert("Message sending failed.");
      }
  };

  const deleteMessage = async (msgId: string) => {
      if (!activeChatId) return;
      if (confirm("Delete this message?")) {
          const msgRef = ref(rtdb, `chats/${activeChatId}/messages/${msgId}`);
          await remove(msgRef);
          setSelectedMsgId(null);
      }
  };

  const handleImageUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      if (file) {
          try {
            const url = await uploadImageToImgBB(file);
            await handleSend(undefined, url);
          } catch(err) {
              alert("Failed to send image");
          }
      }
  };

  const filteredContacts = contactList.filter(u => (u.name || '').toLowerCase().includes(searchTerm.toLowerCase()));

  // Component: Contact List
  const ContactList = () => (
      <div className={`h-full flex flex-col ${themeClasses.cardBg}`}>
           {/* Custom Header for Contact List */}
           <div className={`p-4 pt-12 md:pt-4 border-b ${themeClasses.border} sticky top-0 bg-inherit z-10`}>
                <h2 className={`text-2xl font-bold mb-4 ${themeClasses.textMain} flex items-center gap-2`}>
                    <MessageCircle className="text-blue-500"/> Messages
                </h2>
                <div className={`flex items-center gap-2 px-4 py-3 rounded-2xl ${themeClasses.accentBg}`}>
                    <Search className="text-gray-400" size={18} />
                    <input 
                      className={`bg-transparent outline-none w-full text-sm ${themeClasses.textMain}`}
                      placeholder="Search..."
                      value={searchTerm}
                      onChange={e => setSearchTerm(e.target.value)}
                    />
                </div>
            </div>
            <div className="flex-1 overflow-y-auto no-scrollbar pb-20">
                {loadingContacts ? (
                    <div className="p-8 text-center text-gray-400">Loading...</div>
                ) : filteredContacts.length === 0 ? (
                    <div className="p-8 text-center text-gray-400">No contacts.</div>
                ) : (
                    filteredContacts.map(u => (
                        <div 
                            key={u.uid} 
                            onClick={() => openChat(u)} 
                            className={`p-4 border-b ${themeClasses.border} flex items-center gap-3 cursor-pointer transition-colors hover:bg-gray-50 dark:hover:bg-slate-800`}
                        >
                            <div className="relative">
                                <img src={u.photoURL || `https://ui-avatars.com/api/?name=${u.name}`} className="w-12 h-12 rounded-full object-cover border border-gray-200" />
                                {u.timestamp > 0 && <div className="absolute bottom-0 right-0 w-3 h-3 bg-green-50 rounded-full border-2 border-white"></div>}
                            </div>
                            <div className="flex-1 min-w-0">
                                <div className="flex justify-between items-baseline">
                                    <h4 className={`font-bold text-sm truncate ${themeClasses.textMain}`}>{u.name}</h4>
                                    <span className="text-[10px] text-gray-400">{u.timestamp ? new Date(u.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}) : ''}</span>
                                </div>
                                <p className={`text-xs truncate ${themeClasses.textSub} opacity-80`}>{u.lastMsg || 'Tap to chat'}</p>
                            </div>
                        </div>
                    ))
                )}
            </div>
      </div>
  );

  // Component: Chat Window
  const ChatWindow = () => {
      if (!activeChatId || !activeChatUser) {
          return null; 
      }

      return (
          <div className="h-full flex flex-col relative bg-white dark:bg-slate-900">
               {/* Header - Fixed Top */}
               <div className={`px-4 py-3 pt-12 md:pt-4 border-b ${themeClasses.border} flex items-center gap-3 bg-white/50 dark:bg-slate-900/50 backdrop-blur-md sticky top-0 z-20`}>
                   <button onClick={() => setActiveChatId(null)} className="p-2 -ml-2 rounded-full hover:bg-gray-100 dark:hover:bg-slate-800">
                       <ArrowLeft size={24} className={themeClasses.textMain} />
                   </button>
                   <img src={activeChatUser.photoURL || `https://ui-avatars.com/api/?name=${activeChatUser.name}`} className="w-9 h-9 rounded-full object-cover" />
                   <div>
                       <h3 className={`font-bold text-sm ${themeClasses.textMain}`}>{activeChatUser.name}</h3>
                       <p className="text-[10px] text-green-500 font-bold">Online</p>
                   </div>
               </div>

               {/* Messages - Flex-1 to take available space, Overflow-y-auto to scroll */}
               <div className="flex-1 overflow-y-auto p-4 space-y-3 bg-gray-50/50 dark:bg-slate-900/50 scroll-smooth pb-4" onClick={() => setSelectedMsgId(null)}>
                   {messages.map((msg) => {
                       const isMe = msg.senderId === currentUser?.uid;
                       const isImage = msg.type === 'image';
                       const showMenu = selectedMsgId === msg.id;
                       
                       return (
                           <div key={msg.id} className={`flex flex-col ${isMe ? 'items-end' : 'items-start'} animate-fade-in-up relative`}>
                               {msg.replyTo && (
                                   <div className={`text-xs mb-1 px-3 py-1 rounded-lg opacity-70 border-l-4 ${isMe ? 'border-white/50 text-right mr-2' : 'border-indigo-500 ml-2 text-left'}`}>
                                       <span className="font-bold">{msg.replyTo.senderName}</span>: {msg.replyTo.text.substring(0, 20)}...
                                   </div>
                               )}
                               
                               <div 
                                    onClick={(e) => { e.stopPropagation(); setSelectedMsgId(showMenu ? null : msg.id); }}
                                    className={`max-w-[85%] shadow-sm relative text-sm cursor-pointer ${
                                        isMe ? `${primaryColor} text-white rounded-2xl rounded-tr-none` : `bg-white dark:bg-slate-800 ${themeClasses.textMain} rounded-2xl rounded-tl-none`
                                    } ${isImage ? 'p-1' : 'px-4 py-2.5'}`}
                               >
                                   {isImage ? (
                                       <img src={msg.text} className="rounded-xl max-w-full max-h-64 object-cover" onClick={() => window.open(msg.text, '_blank')} />
                                   ) : (
                                       <p className="leading-relaxed whitespace-pre-wrap">{msg.text}</p>
                                   )}
                                   <span className={`text-[9px] block text-right mt-1 opacity-70 ${isMe ? 'text-white/80' : 'text-gray-400'}`}>
                                       {msg.timestamp ? new Date(msg.timestamp).toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}) : '...'}
                                   </span>
                               </div>

                               {/* Menu */}
                               {showMenu && (
                                   <div className={`flex gap-2 mt-1 ${isMe ? 'mr-1' : 'ml-1'} animate-fade-in z-10`}>
                                       <button onClick={() => setReplyTo(msg)} className="p-2 bg-gray-200 dark:bg-slate-700 rounded-full text-gray-600 dark:text-gray-300 shadow-lg hover:scale-110 transition-transform">
                                           <Reply size={14} />
                                       </button>
                                       {isMe && (
                                           <button onClick={() => deleteMessage(msg.id)} className="p-2 bg-red-100 dark:bg-red-900/30 rounded-full text-red-500 shadow-lg hover:scale-110 transition-transform">
                                               <Trash2 size={14} />
                                           </button>
                                       )}
                                   </div>
                               )}
                           </div>
                       )
                   })}
                   <div ref={bottomRef} className="h-2"/>
               </div>

               {/* Input Area - Fixed at bottom of chat column */}
               <div className="p-3 bg-white dark:bg-slate-900 border-t border-gray-100 dark:border-slate-800 shrink-0 pb-safe md:pb-3">
                   {replyTo && (
                       <div className="mb-2 p-2 bg-indigo-50 dark:bg-indigo-900/20 rounded-lg flex justify-between items-center border-l-4 border-indigo-500">
                           <div className="text-xs">
                               <p className="font-bold text-indigo-500">Replying to {replyTo.senderName}</p>
                               <p className={`truncate max-w-[200px] ${themeClasses.textMain}`}>{replyTo.text}</p>
                           </div>
                           <button onClick={() => setReplyTo(null)} className="p-1 hover:bg-black/10 rounded-full"><X size={14}/></button>
                       </div>
                   )}
                   <div className="flex items-center gap-2">
                       <label className="p-2.5 bg-gray-100 dark:bg-slate-800 rounded-full cursor-pointer hover:bg-gray-200 transition-colors shrink-0">
                           <ImageIcon size={20} className="text-gray-500" />
                           <input type="file" className="hidden" accept="image/*" onChange={handleImageUpload} />
                       </label>
                       
                       <input 
                          className={`flex-1 bg-gray-100 dark:bg-slate-800 rounded-full px-4 py-2.5 outline-none ${themeClasses.textMain} text-sm min-w-0`}
                          placeholder="Type a message..."
                          value={newMessage}
                          onChange={e => setNewMessage(e.target.value)}
                          onKeyDown={e => e.key === 'Enter' && handleSend()}
                       />
                       
                       <button 
                          onClick={() => handleSend()} 
                          disabled={!newMessage.trim()}
                          className={`p-2.5 rounded-full text-white shadow-lg transform transition-transform active:scale-95 shrink-0 ${primaryColor} ${!newMessage.trim() ? 'opacity-50' : 'hover:scale-105'}`}
                       >
                           <Send size={20} fill="currentColor" />
                       </button>
                   </div>
               </div>
          </div>
      );
  };

  return (
    // Main Container - 100dvh handles mobile browser bars better than 100vh
    <div className="h-[100dvh] w-full flex flex-col bg-white dark:bg-slate-900 md:rounded-[2.5rem] md:shadow-xl md:border md:border-white/20 overflow-hidden relative">
        
        {/* Contact List - Visible Only When No Chat is Active */}
        <div className={`w-full h-full flex flex-col ${activeChatId ? 'hidden' : 'flex'}`}>
            <ContactList />
        </div>

        {/* Chat Window - Visible Only When Chat is Active (Full Screen) */}
        <div className={`w-full h-full flex flex-col ${activeChatId ? 'flex' : 'hidden'}`}>
             <ChatWindow />
        </div>
    </div>
  );
};

export default Chat;
