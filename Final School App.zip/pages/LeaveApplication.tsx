
import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { collection, addDoc, query, orderBy, onSnapshot, doc, updateDoc, where } from 'firebase/firestore';
import { db } from '../firebase';
import { LeaveRequest } from '../types';
import { FileText, Plus, CheckCircle, XCircle, Clock, Calendar } from 'lucide-react';
import { createPortal } from 'react-dom';

const LeaveApplication: React.FC = () => {
    const { userProfile } = useAuth();
    const { themeClasses, primaryColor, playSound } = useTheme();
    const [leaves, setLeaves] = useState<LeaveRequest[]>([]);
    const [showForm, setShowForm] = useState(false);
    const [formData, setFormData] = useState({ reason: '', type: 'Sick' as const, startDate: '', endDate: '' });
    
    // Check if user is admin or teacher (Admin approves everyone, Teacher approves students)
    const isAdmin = userProfile?.role === 'admin';

    useEffect(() => {
        if(!userProfile) return;

        let q;
        if (isAdmin) {
            // Admin sees all - Safe to order by createdAt since no where clause
            q = query(collection(db, 'leave_requests'));
        } else {
            // Students/Teachers see their own - REMOVED orderBy from query to fix index error
            q = query(collection(db, 'leave_requests'), where('userId', '==', userProfile.uid));
        }

        const unsubscribe = onSnapshot(q, snap => {
            const data = snap.docs.map(d => ({ id: d.id, ...d.data() } as LeaveRequest));
            // Client side sorting
            data.sort((a, b) => b.createdAt - a.createdAt);
            setLeaves(data);
        });
        return unsubscribe;
    }, [userProfile, isAdmin]);

    const handleSubmit = async (e: React.FormEvent) => {
        e.preventDefault();
        if(!userProfile) return;
        playSound('click');
        try {
            await addDoc(collection(db, 'leave_requests'), {
                userId: userProfile.uid,
                userName: userProfile.displayName,
                role: userProfile.role,
                ...formData,
                status: 'pending',
                createdAt: Date.now()
            });
            setShowForm(false);
            setFormData({ reason: '', type: 'Sick', startDate: '', endDate: '' });
            alert("Application Submitted successfully.");
        } catch (error) {
            console.error(error);
        }
    };

    const handleAction = async (id: string, status: 'approved' | 'rejected') => {
        playSound('click');
        await updateDoc(doc(db, 'leave_requests', id), { status });
    };

    const getStatusColor = (status: string) => {
        switch(status) {
            case 'approved': return 'bg-green-100 text-green-700 border-green-200';
            case 'rejected': return 'bg-red-100 text-red-700 border-red-200';
            default: return 'bg-yellow-100 text-yellow-700 border-yellow-200';
        }
    };

    return (
        <div className="space-y-6 pb-20">
             <div className="flex justify-between items-center">
                <h1 className={`text-2xl font-bold flex items-center gap-2 ${themeClasses.textMain}`}>
                    <FileText className="text-orange-500" /> Leave Applications
                </h1>
                {!isAdmin && (
                    <button onClick={() => setShowForm(true)} className={`px-4 py-2.5 rounded-xl text-white font-bold flex items-center gap-2 shadow-lg ${primaryColor}`}>
                        <Plus size={18} /> Apply for Leave
                    </button>
                )}
            </div>

            {/* Application Form Modal */}
            {showForm && createPortal(
                <div className="fixed inset-0 z-[200] flex items-center justify-center bg-black/60 backdrop-blur-sm px-4">
                    <div className={`${themeClasses.cardBg} w-full max-w-md rounded-[2rem] p-6 animate-slide-in-up shadow-2xl relative border ${themeClasses.border}`}>
                        <button onClick={() => setShowForm(false)} className="absolute top-4 right-4 p-2 bg-gray-100 rounded-full hover:bg-gray-200"><XCircle size={20}/></button>
                        <h2 className={`text-xl font-bold mb-6 ${themeClasses.textMain}`}>New Leave Request</h2>
                        
                        <form onSubmit={handleSubmit} className="space-y-4">
                            <div>
                                <label className={`text-xs font-bold uppercase mb-1 block ${themeClasses.textSub}`}>Leave Type</label>
                                <select className={`w-full p-3 rounded-xl outline-none ${themeClasses.accentBg} ${themeClasses.textMain}`} value={formData.type} onChange={e => setFormData({...formData, type: e.target.value as any})}>
                                    <option value="Sick">Sick Leave</option>
                                    <option value="Casual">Casual Leave</option>
                                    <option value="Emergency">Emergency</option>
                                </select>
                            </div>
                            <div className="grid grid-cols-2 gap-3">
                                <div>
                                    <label className={`text-xs font-bold uppercase mb-1 block ${themeClasses.textSub}`}>Start Date</label>
                                    <input type="date" required className={`w-full p-3 rounded-xl outline-none ${themeClasses.accentBg} ${themeClasses.textMain}`} value={formData.startDate} onChange={e => setFormData({...formData, startDate: e.target.value})} />
                                </div>
                                <div>
                                    <label className={`text-xs font-bold uppercase mb-1 block ${themeClasses.textSub}`}>End Date</label>
                                    <input type="date" required className={`w-full p-3 rounded-xl outline-none ${themeClasses.accentBg} ${themeClasses.textMain}`} value={formData.endDate} onChange={e => setFormData({...formData, endDate: e.target.value})} />
                                </div>
                            </div>
                            <div>
                                <label className={`text-xs font-bold uppercase mb-1 block ${themeClasses.textSub}`}>Reason</label>
                                <textarea required placeholder="Explain why you need leave..." className={`w-full p-3 rounded-xl outline-none h-24 resize-none ${themeClasses.accentBg} ${themeClasses.textMain}`} value={formData.reason} onChange={e => setFormData({...formData, reason: e.target.value})} />
                            </div>
                            <button type="submit" className={`w-full py-3 rounded-xl text-white font-bold shadow-lg ${primaryColor}`}>Submit Application</button>
                        </form>
                    </div>
                </div>, document.body
            )}

            {/* List */}
            <div className="grid gap-4">
                {leaves.map(leave => (
                    <div key={leave.id} className={`${themeClasses.cardBg} p-5 rounded-3xl border ${themeClasses.border} shadow-sm relative group`}>
                        <div className="flex justify-between items-start mb-2">
                             <div>
                                 <h3 className={`font-bold text-lg ${themeClasses.textMain}`}>{leave.userName} <span className="text-xs opacity-50 font-normal">({leave.role})</span></h3>
                                 <div className="flex items-center gap-2 mt-1">
                                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider bg-gray-100 text-gray-600`}>{leave.type}</span>
                                    <span className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase tracking-wider border ${getStatusColor(leave.status)}`}>{leave.status}</span>
                                 </div>
                             </div>
                             {isAdmin && leave.status === 'pending' && (
                                 <div className="flex gap-2">
                                     <button onClick={() => handleAction(leave.id, 'approved')} className="p-2 bg-green-100 text-green-600 rounded-full hover:bg-green-200"><CheckCircle size={18}/></button>
                                     <button onClick={() => handleAction(leave.id, 'rejected')} className="p-2 bg-red-100 text-red-600 rounded-full hover:bg-red-200"><XCircle size={18}/></button>
                                 </div>
                             )}
                        </div>
                        
                        <div className={`p-3 rounded-xl ${themeClasses.accentBg} mb-3`}>
                             <p className={`text-sm italic ${themeClasses.textMain}`}>"{leave.reason}"</p>
                        </div>

                        <div className="flex items-center gap-4 text-xs font-bold text-gray-400">
                             <div className="flex items-center gap-1"><Calendar size={14}/> {leave.startDate} to {leave.endDate}</div>
                             <div className="flex items-center gap-1"><Clock size={14}/> Applied: {new Date(leave.createdAt).toLocaleDateString()}</div>
                        </div>
                    </div>
                ))}
                {leaves.length === 0 && <div className="text-center p-10 text-gray-400">No leave applications found.</div>}
            </div>
        </div>
    );
};

export default LeaveApplication;
