

import React from 'react';
import { Settings as SettingsIcon, Bell, Lock, Volume2, Palette, LogOut, EyeOff } from 'lucide-react';
import { auth } from '../firebase';
import { useNavigate } from 'react-router-dom';
import { useTheme } from '../contexts/ThemeContext';
import { requestForToken } from '../services/notificationService';

const Settings: React.FC = () => {
    const navigate = useNavigate();
    const { theme, setTheme, soundEnabled, toggleSound, notificationsEnabled, toggleNotifications, playSound, hideHeader, setHideHeader, themeClasses } = useTheme();

    const handleLogout = async () => {
        playSound('click');
        await auth.signOut();
        navigate('/login');
    };

    const handleNotificationToggle = async () => {
        playSound('click');
        if (!notificationsEnabled) {
            // Trying to enable
            await requestForToken();
        }
        toggleNotifications();
    };

    const themes = [
        { id: 'light', bg: 'bg-white', border: 'border-gray-200', name: 'Clean White' },
        { id: 'dark', bg: 'bg-slate-800', border: 'border-slate-600', name: 'Night Mode' },
        { id: 'pink', bg: 'bg-pink-100', border: 'border-pink-300', name: 'Soft Pink' },
        { id: 'blue', bg: 'bg-blue-100', border: 'border-blue-300', name: 'Sky Blue' }
    ];

    return (
        <div className="space-y-6 pb-20">
            <h1 className={`text-2xl font-bold flex items-center gap-2 ${themeClasses.textMain}`}>
                <SettingsIcon className="text-gray-500" /> Settings
            </h1>
            
            <div className={`${themeClasses.cardBg} rounded-3xl shadow-sm overflow-hidden border ${themeClasses.border}`}>
                
                <div className={`p-6 border-b ${themeClasses.border}`}>
                    <h3 className={`font-bold mb-4 flex items-center gap-2 ${themeClasses.textMain}`}>
                        <Palette size={20} className="text-purple-500" /> App Theme
                    </h3>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                        {themes.map(t => (
                            <button
                                key={t.id}
                                onClick={() => { playSound('click'); setTheme(t.id as any); }}
                                className={`relative p-4 rounded-2xl border-2 transition-all overflow-hidden ${
                                    theme === t.id ? 'border-indigo-500 ring-2 ring-indigo-500/20' : 'border-transparent'
                                } ${t.bg}`}
                            >
                                <span className={`relative z-10 text-xs font-bold ${t.id === 'dark' ? 'text-white' : 'text-gray-800'}`}>{t.name}</span>
                                {theme === t.id && <div className="absolute top-2 right-2 w-2 h-2 bg-indigo-500 rounded-full"></div>}
                            </button>
                        ))}
                    </div>
                </div>

                {/* Hide Header */}
                <div className={`p-4 flex items-center justify-between hover:bg-gray-50 dark:hover:bg-slate-700/50 border-b ${themeClasses.border} cursor-pointer`} onClick={() => { setHideHeader(!hideHeader); playSound('click'); }}>
                    <div className="flex items-center gap-4">
                        <div className="p-2 bg-blue-100 text-blue-600 rounded-xl"><EyeOff size={20} /></div>
                        <span className={`font-bold ${themeClasses.textMain}`}>Hide Header</span>
                    </div>
                    <div className={`w-12 h-6 rounded-full p-1 transition-colors ${hideHeader ? 'bg-blue-500' : 'bg-gray-300'}`}>
                        <div className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${hideHeader ? 'translate-x-6' : ''}`}></div>
                    </div>
                </div>

                {/* Notifications */}
                <div className={`p-4 flex items-center justify-between hover:bg-gray-50 dark:hover:bg-slate-700/50 border-b ${themeClasses.border} cursor-pointer`} onClick={handleNotificationToggle}>
                    <div className="flex items-center gap-4">
                        <div className="p-2 bg-pink-100 text-pink-600 rounded-xl"><Bell size={20} /></div>
                        <span className={`font-bold ${themeClasses.textMain}`}>Notifications</span>
                    </div>
                    <div className={`w-12 h-6 rounded-full p-1 transition-colors ${notificationsEnabled ? 'bg-pink-500' : 'bg-gray-300'}`}>
                        <div className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${notificationsEnabled ? 'translate-x-6' : ''}`}></div>
                    </div>
                </div>

                {/* Sound */}
                 <div className={`p-4 flex items-center justify-between hover:bg-gray-50 dark:hover:bg-slate-700/50 border-b ${themeClasses.border} cursor-pointer`} onClick={() => { toggleSound(); playSound('click'); }}>
                    <div className="flex items-center gap-4">
                        <div className="p-2 bg-green-100 text-green-600 rounded-xl"><Volume2 size={20} /></div>
                        <span className={`font-bold ${themeClasses.textMain}`}>Sound Effects</span>
                    </div>
                    <div className={`w-12 h-6 rounded-full p-1 transition-colors ${soundEnabled ? 'bg-green-500' : 'bg-gray-300'}`}>
                        <div className={`bg-white w-4 h-4 rounded-full shadow-md transform transition-transform ${soundEnabled ? 'translate-x-6' : ''}`}></div>
                    </div>
                </div>

                <div className="p-4 flex items-center justify-between hover:bg-red-50/10 cursor-pointer" onClick={handleLogout}>
                    <div className="flex items-center gap-4">
                        <div className="p-2 bg-red-100 text-red-600 rounded-xl"><LogOut size={20} /></div>
                        <span className="font-bold text-red-600">Logout</span>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Settings;