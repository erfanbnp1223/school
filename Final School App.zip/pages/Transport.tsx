
import React, { useEffect, useState } from 'react';
import { ref, onValue } from 'firebase/database';
import { rtdb } from '../firebase';
import { Bus, MapPin } from 'lucide-react';

const Transport: React.FC = () => {
    const [status, setStatus] = useState('Waiting for updates...');
    const [location, setLocation] = useState('School Garage');

    useEffect(() => {
        // Simulating listening to real-time bus data
        // In a real app with GPS, this would be coordinates
        const busRef = ref(rtdb, 'transport/bus1');
        const unsub = onValue(busRef, snap => {
            const data = snap.val();
            if (data) {
                setStatus(data.status);
                setLocation(data.location);
            } else {
                // Default if no data
                setStatus("On Time");
                setLocation("Main Highway");
            }
        });
        return unsub;
    }, []);

    return (
        <div className="space-y-6">
             <h1 className="text-2xl font-bold text-gray-800 flex items-center gap-2">
                <Bus className="text-yellow-500" /> Live Transport
            </h1>
            
            <div className="bg-white rounded-3xl shadow-sm p-8 text-center">
                <div className="w-24 h-24 bg-yellow-100 rounded-full flex items-center justify-center mx-auto mb-6 text-yellow-600 animate-pulse">
                    <Bus size={48} />
                </div>
                <h2 className="text-3xl font-bold text-gray-800 mb-2">Bus No. 12</h2>
                <div className="flex items-center justify-center gap-2 text-gray-500 mb-6">
                    <MapPin size={18} />
                    <span>Current Location: <strong className="text-primary">{location}</strong></span>
                </div>
                <div className="inline-block bg-green-100 text-green-700 px-6 py-2 rounded-full font-bold">
                    Status: {status}
                </div>
                
                <p className="mt-8 text-gray-400 text-sm">
                    Real-time tracking is active. Updates are pushed automatically.
                </p>
            </div>
        </div>
    );
};

export default Transport;
