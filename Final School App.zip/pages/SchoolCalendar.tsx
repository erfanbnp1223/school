

import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { collection, addDoc, query, orderBy, onSnapshot, deleteDoc, doc } from 'firebase/firestore';
import { db } from '../firebase';
import { SchoolEvent } from '../types';
import { Calendar as CalendarIcon, Plus, Trash2, MapPin } from 'lucide-react';
import { createPortal } from 'react-dom';

const SchoolCalendar: React.FC = () => {
    const { userProfile } = useAuth();
    const { themeClasses, primaryColor, playSound } = useTheme();
    const [events, setEvents] = useState<SchoolEvent[]>([]);
    const [showForm, setShowForm] = useState(false);
    const [formData, setFormData] = useState({ title: '', date: '', type: 'event' as const, description: '' });

    const isAdmin = userProfile?.role === 'admin';

    useEffect(() => {
        const q = query(collection(db, 'events'), orderBy('date', 'asc'));
        const unsubscribe = onSnapshot(q, snap => {
            // Filter out past events? Optional. Let's keep all sorted.
            setEvents(snap.docs.map(d => ({ id: d.id, ...d.data() } as SchoolEvent)));
        });
        return unsubscribe;
    }, []);

    const handleAdd = async (e: React.FormEvent) => {
        e.preventDefault();
        if(!formData.title || !formData.date) return;
        await addDoc(collection(db, 'events'), formData);
        setShowForm(false);
        setFormData({ title: '', date: '', type: 'event', description: '' });
    };

    const handleDelete = async (id: string) => {
        if(confirm("Delete this event?")) await deleteDoc(doc(db, 'events', id));
    };

    const getMonthName = (dateStr: string) => {
        const date = new Date(dateStr);
        return date.toLocaleString('default', { month: 'short' });
    };

    const getDay = (dateStr: string) => {
        const date = new Date(dateStr);
        return date.getDate();
    };

    return (
        <div className="space-y-6 pb-20">
             <div className="flex justify-between items-center">
                <h1 className={`text-2xl font-bold flex items-center gap-2 ${themeClasses.textMain}`}>
                    <CalendarIcon className="text-purple-500" /> Academic Calendar
                </h1>
                {isAdmin && (
                    <button onClick={() => setShowForm(!showForm)} className={`px-4 py-2 rounded-xl text-white font-bold flex items-center gap-2 shadow-lg ${primaryColor}`}>
                        <Plus size={18} /> Add Event
                    </button>
                )}
            </div>

            {showForm && (
                <form onSubmit={handleAdd} className={`${themeClasses.cardBg} p-6 rounded-3xl border ${themeClasses.border} shadow-lg space-y-4 animate-fade-in`}>
                     <h3 className={`font-bold ${themeClasses.textMain}`}>Add New Event</h3>
                     <input className={`w-full p-3 rounded-xl outline-none ${themeClasses.accentBg} ${themeClasses.textMain}`} placeholder="Event Title" value={formData.title} onChange={e => setFormData({...formData, title: e.target.value})} required />
                     <div className="flex gap-3">
                         <input type="date" className={`flex-1 p-3 rounded-xl outline-none ${themeClasses.accentBg} ${themeClasses.textMain}`} value={formData.date} onChange={e => setFormData({...formData, date: e.target.value})} required />
                         <select className={`flex-1 p-3 rounded-xl outline-none ${themeClasses.accentBg} ${themeClasses.textMain}`} value={formData.type} onChange={e => setFormData({...formData, type: e.target.value as any})}>
                             <option value="event">Event</option>
                             <option value="holiday">Holiday</option>
                             <option value="exam">Exam</option>
                         </select>
                     </div>
                     <textarea className={`w-full p-3 rounded-xl outline-none h-20 resize-none ${themeClasses.accentBg} ${themeClasses.textMain}`} placeholder="Details (Optional)" value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} />
                     <button type="submit" className={`w-full py-3 rounded-xl text-white font-bold ${primaryColor}`}>Save Event</button>
                </form>
            )}

            <div className="space-y-4">
                {events.map(event => (
                    <div key={event.id} className={`${themeClasses.cardBg} p-4 rounded-3xl shadow-sm border ${themeClasses.border} flex items-center gap-4 relative group`}>
                         {/* Date Box */}
                         <div className={`flex flex-col items-center justify-center w-16 h-16 rounded-2xl shrink-0 ${
                             event.type === 'holiday' ? 'bg-red-100 text-red-600' :
                             event.type === 'exam' ? 'bg-orange-100 text-orange-600' :
                             'bg-blue-100 text-blue-600'
                         }`}>
                             <span className="text-xs font-bold uppercase">{getMonthName(event.date)}</span>
                             <span className="text-2xl font-bold leading-none">{getDay(event.date)}</span>
                         </div>

                         <div className="flex-1">
                             <div className="flex items-center gap-2 mb-1">
                                <h3 className={`font-bold text-lg ${themeClasses.textMain}`}>{event.title}</h3>
                                <span className={`text-[10px] font-bold uppercase px-2 py-0.5 rounded ${
                                     event.type === 'holiday' ? 'bg-red-50 text-red-500' :
                                     event.type === 'exam' ? 'bg-orange-50 text-orange-500' :
                                     'bg-blue-50 text-blue-500'
                                }`}>{event.type}</span>
                             </div>
                             {event.description && <p className={`text-sm ${themeClasses.textSub}`}>{event.description}</p>}
                             <p className="text-xs text-gray-400 mt-1 flex items-center gap-1"><CalendarIcon size={12}/> {new Date(event.date).toLocaleDateString(undefined, {weekday:'long', year:'numeric', month:'long', day:'numeric'})}</p>
                         </div>

                         {isAdmin && (
                             <button onClick={() => handleDelete(event.id)} className="absolute top-4 right-4 p-2 text-gray-300 hover:text-red-500 transition-colors">
                                 <Trash2 size={16}/>
                             </button>
                         )}
                    </div>
                ))}
                {events.length === 0 && <div className="text-center p-10 text-gray-400">No upcoming events found.</div>}
            </div>
        </div>
    );
};

export default SchoolCalendar;