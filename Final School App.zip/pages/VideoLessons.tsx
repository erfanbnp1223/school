

import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { collection, addDoc, query, orderBy, onSnapshot, deleteDoc, doc, where } from 'firebase/firestore';
import { db } from '../firebase';
import { VideoLesson } from '../types';
import { Video, Plus, Trash2, Play, ExternalLink } from 'lucide-react';
import { createPortal } from 'react-dom';

const VideoLessons: React.FC = () => {
    const { userProfile } = useAuth();
    const { themeClasses, primaryColor } = useTheme();
    const [videos, setVideos] = useState<VideoLesson[]>([]);
    const [showForm, setShowForm] = useState(false);
    const [formData, setFormData] = useState({ title: '', subject: '', videoUrl: '', description: '', classGrade: '6' });

    const canAdd = userProfile?.role === 'admin' || userProfile?.role === 'teacher';

    useEffect(() => {
        let q = query(collection(db, 'videos'), orderBy('createdAt', 'desc'));

        if (userProfile?.role === 'student' && userProfile.className) {
            q = query(collection(db, 'videos'), where('classGrade', '==', userProfile.className));
        }

        const unsubscribe = onSnapshot(q, snap => {
            setVideos(snap.docs.map(d => ({ id: d.id, ...d.data() } as VideoLesson)));
        });
        return unsubscribe;
    }, [userProfile]);

    const handleAdd = async (e: React.FormEvent) => {
        e.preventDefault();
        await addDoc(collection(db, 'videos'), {
            ...formData,
            addedBy: userProfile?.displayName,
            createdAt: Date.now()
        });
        setShowForm(false);
        setFormData({ title: '', subject: '', videoUrl: '', description: '', classGrade: '6' });
    };

    const handleDelete = async (id: string) => {
        if(confirm("Delete this video?")) await deleteDoc(doc(db, 'videos', id));
    };

    // Helper to get YouTube Thumbnail
    const getThumbnail = (url: string) => {
        const regExp = /^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/;
        const match = url.match(regExp);
        return (match && match[2].length === 11) ? `https://img.youtube.com/vi/${match[2]}/mqdefault.jpg` : null;
    };

    return (
        <div className="space-y-6 pb-20">
             <div className="flex justify-between items-center">
                <h1 className={`text-2xl font-bold flex items-center gap-2 ${themeClasses.textMain}`}>
                    <Video className="text-red-500" /> E-Learning Hub
                </h1>
                {canAdd && (
                    <button onClick={() => setShowForm(!showForm)} className={`px-4 py-2 rounded-xl text-white font-bold flex items-center gap-2 shadow-lg ${primaryColor}`}>
                        <Plus size={18} /> Add Video
                    </button>
                )}
            </div>

            {showForm && createPortal(
                <div className="fixed inset-0 z-[200] flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
                    <form onSubmit={handleAdd} className={`${themeClasses.cardBg} w-full max-w-md p-6 rounded-[2rem] border ${themeClasses.border} shadow-lg space-y-4 animate-fade-in-up relative`}>
                         <h3 className={`font-bold ${themeClasses.textMain}`}>New Video Lesson</h3>
                         <button type="button" onClick={() => setShowForm(false)} className="absolute top-4 right-4 p-2 bg-gray-100 rounded-full"><Trash2 size={16} className="text-gray-500"/></button>
                         
                         <input className={`w-full p-3 rounded-xl outline-none ${themeClasses.accentBg} ${themeClasses.textMain}`} placeholder="Lesson Title" value={formData.title} onChange={e => setFormData({...formData, title: e.target.value})} required />
                         
                         <div className="flex gap-3">
                             <input className={`flex-1 p-3 rounded-xl outline-none ${themeClasses.accentBg} ${themeClasses.textMain}`} placeholder="Subject" value={formData.subject} onChange={e => setFormData({...formData, subject: e.target.value})} required />
                             <select className={`p-3 rounded-xl outline-none ${themeClasses.accentBg} ${themeClasses.textMain}`} value={formData.classGrade} onChange={e => setFormData({...formData, classGrade: e.target.value})}>
                                {[6,7,8,9,10].map(c => <option key={c} value={c}>Class {c}</option>)}
                             </select>
                         </div>
                         
                         <input className={`w-full p-3 rounded-xl outline-none ${themeClasses.accentBg} ${themeClasses.textMain}`} placeholder="YouTube Link" value={formData.videoUrl} onChange={e => setFormData({...formData, videoUrl: e.target.value})} required />
                         <button type="submit" className={`w-full py-3 rounded-xl text-white font-bold ${primaryColor}`}>Upload Lesson</button>
                    </form>
                </div>, document.body
            )}

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {videos.map(video => {
                    const thumb = getThumbnail(video.videoUrl);
                    return (
                        <div key={video.id} className={`${themeClasses.cardBg} rounded-3xl overflow-hidden shadow-sm border ${themeClasses.border} group`}>
                            <div className="aspect-video bg-black relative">
                                {thumb ? (
                                    <img src={thumb} className="w-full h-full object-cover opacity-80 group-hover:opacity-100 transition-opacity" />
                                ) : (
                                    <div className="w-full h-full flex items-center justify-center text-white/50"><Video size={48}/></div>
                                )}
                                <a href={video.videoUrl} target="_blank" rel="noopener noreferrer" className="absolute inset-0 flex items-center justify-center bg-black/20 group-hover:bg-black/40 transition-colors">
                                    <div className="w-12 h-12 bg-white/20 backdrop-blur-md rounded-full flex items-center justify-center text-white border-2 border-white/50 group-hover:scale-110 transition-transform">
                                        <Play fill="currentColor" size={20} className="ml-1"/>
                                    </div>
                                </a>
                                <div className="absolute top-2 left-2 bg-black/60 text-white text-[10px] font-bold px-2 py-1 rounded backdrop-blur-md uppercase tracking-wider">
                                    {video.subject} • Class {video.classGrade}
                                </div>
                                {canAdd && (
                                    <button onClick={() => handleDelete(video.id)} className="absolute top-2 right-2 bg-red-600 text-white p-1.5 rounded-full opacity-0 group-hover:opacity-100 transition-opacity">
                                        <Trash2 size={12}/>
                                    </button>
                                )}
                            </div>
                            <div className="p-4">
                                <h3 className={`font-bold text-lg leading-tight mb-1 ${themeClasses.textMain} line-clamp-2`}>{video.title}</h3>
                                <p className={`text-xs ${themeClasses.textSub} mb-3`}>Added by {video.addedBy}</p>
                                <a href={video.videoUrl} target="_blank" className={`text-sm font-bold text-indigo-500 flex items-center gap-1 hover:underline`}>
                                    Watch Now <ExternalLink size={12}/>
                                </a>
                            </div>
                        </div>
                    );
                })}
                {videos.length === 0 && <div className="col-span-full text-center p-10 text-gray-400">No videos found for your class.</div>}
            </div>
        </div>
    );
};

export default VideoLessons;