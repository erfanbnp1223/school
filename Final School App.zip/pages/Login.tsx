

import React, { useState } from 'react';
import { auth, db } from '../firebase';
import { signInWithEmailAndPassword, createUserWithEmailAndPassword, GoogleAuthProvider, signInWithPopup, updateProfile } from 'firebase/auth';
import { doc, setDoc, getDoc, collection, query, where, getDocs, updateDoc } from 'firebase/firestore';
import { useNavigate } from 'react-router-dom';
import { UserRole } from '../types';
import { useTheme } from '../contexts/ThemeContext';
import { ArrowRight, Mail, Lock, User, Phone, Key, Users } from 'lucide-react';

const Login: React.FC = () => {
  const { playSound } = useTheme();
  const [isLogin, setIsLogin] = useState(false); // Default to Sign Up
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [phone, setPhone] = useState('');
  const [role, setRole] = useState<UserRole>('student');
  const [schoolCode, setSchoolCode] = useState('');
  const [teacherCode, setTeacherCode] = useState('');
  const [className, setClassName] = useState('6');
  const [linkedStudentName, setLinkedStudentName] = useState(''); // For Parents
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleEmailBlur = () => {
      if (email && !email.includes('@')) {
          setEmail(email + '@gmail.com');
      }
  };

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    playSound('click');
    setError('');
    setLoading(true);

    try {
      // Auto append gmail if missing before submit
      let finalEmail = email;
      if (!finalEmail.includes('@')) finalEmail += '@gmail.com';

      if (isLogin) {
        await signInWithEmailAndPassword(auth, finalEmail, password);
        navigate('/');
      } else {
        if (password !== confirmPassword) throw new Error("Passwords do not match");
        
        // Teacher Validation
        let validTeacherCodeId = null;
        if (role === 'teacher') {
            const codesRef = collection(db, 'teacher_codes');
            // Query for the exact code and check if it is NOT used
            const q = query(codesRef, where('code', '==', teacherCode), where('isUsed', '==', false));
            const querySnapshot = await getDocs(q);
            
            if (querySnapshot.empty) {
                 throw new Error("Invalid or Already Used Teacher Code. Please contact Admin.");
            }
            validTeacherCodeId = querySnapshot.docs[0].id;
        }

        const userCredential = await createUserWithEmailAndPassword(auth, finalEmail, password);
        const user = userCredential.user;

        // If teacher, mark code as used
        if (validTeacherCodeId && role === 'teacher') {
            await updateDoc(doc(db, 'teacher_codes', validTeacherCodeId), { isUsed: true, usedBy: user.uid });
        }

        await setDoc(doc(db, 'users', user.uid), {
          uid: user.uid,
          email: finalEmail,
          displayName: fullName,
          phone,
          role,
          schoolCode,
          className: role === 'student' ? className : null, 
          teacherCode: role === 'teacher' ? teacherCode : null,
          linkedStudentName: role === 'parent' ? linkedStudentName : null,
          createdAt: Date.now(),
          photoURL: user.photoURL || `https://ui-avatars.com/api/?name=${fullName}&background=random`
        });

        await updateProfile(user, { displayName: fullName, photoURL: `https://ui-avatars.com/api/?name=${fullName}&background=random` });
        navigate('/');
      }
    } catch (err: any) {
      setError(err.message.replace('Firebase: ', ''));
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleLogin = async () => {
    playSound('click');
    const provider = new GoogleAuthProvider();
    try {
        const result = await signInWithPopup(auth, provider);
        const user = result.user;
        const userRef = doc(db, 'users', user.uid);
        const snap = await getDoc(userRef);
        if (!snap.exists()) {
            await setDoc(userRef, {
                uid: user.uid, email: user.email, displayName: user.displayName, role: 'student', className: '6', createdAt: Date.now(), photoURL: user.photoURL
            });
        }
        navigate('/');
    } catch (err: any) { setError(err.message); }
  };

  return (
    <div className="min-h-screen w-full flex flex-col items-center justify-center p-6 relative overflow-hidden bg-gradient-to-br from-indigo-900 via-purple-900 to-black">
      
      {/* Animated Background Bubbles */}
      <ul className="circles">
          <li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li>
      </ul>

      <div className="w-full max-w-md z-10 flex flex-col items-center animate-fade-in-up">
        <div className="mb-8 text-center">
            <h1 className="text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-400 mb-2 drop-shadow-sm">
                {isLogin ? 'Welcome Back' : 'Join Us'}
            </h1>
            <p className="text-indigo-200 text-sm">
                পাচগাও আদর্শ উচ্চ বিদ্যালয়
            </p>
        </div>

        {error && <div className="w-full bg-red-500/20 backdrop-blur border border-red-500/50 text-white p-3 rounded-xl text-center text-xs mb-4">{error}</div>}

        <form onSubmit={handleAuth} className="w-full space-y-4">
            {!isLogin && (
                <>
                <div className="flex gap-3">
                     <div className="bg-white/10 backdrop-blur rounded-xl flex items-center px-4 py-3 flex-1 border border-white/5 transition-all focus-within:bg-white/20 focus-within:border-white/30">
                        <User size={18} className="text-indigo-300 mr-2" />
                        <input className="bg-transparent border-none outline-none text-white text-sm w-full placeholder-indigo-300/50" placeholder="Full Name" value={fullName} onChange={e => setFullName(e.target.value)} required />
                    </div>
                    <div className="bg-white/10 backdrop-blur rounded-xl flex items-center px-4 py-3 flex-1 border border-white/5 transition-all focus-within:bg-white/20 focus-within:border-white/30">
                        <Phone size={18} className="text-indigo-300 mr-2" />
                        <input className="bg-transparent border-none outline-none text-white text-sm w-full placeholder-indigo-300/50" placeholder="Phone" value={phone} onChange={e => setPhone(e.target.value)} required />
                    </div>
                </div>
                
                <div className="flex gap-3">
                    <select className="bg-white/10 backdrop-blur rounded-xl px-4 py-3 flex-1 border border-white/5 text-white text-sm outline-none [&>option]:text-black" value={role} onChange={(e) => setRole(e.target.value as UserRole)}>
                        <option value="student">Student</option>
                        <option value="teacher">Teacher</option>
                        <option value="parent">Parent</option>
                    </select>
                    {role === 'student' && (
                        <select className="bg-white/10 backdrop-blur rounded-xl px-4 py-3 flex-1 border border-white/5 text-white text-sm outline-none [&>option]:text-black" value={className} onChange={(e) => setClassName(e.target.value)}>
                            {[6,7,8,9,10].map(c => <option key={c} value={c}>Class {c}</option>)}
                        </select>
                    )}
                </div>
                
                {role === 'teacher' && (
                    <div className="bg-yellow-500/20 backdrop-blur rounded-xl flex items-center px-4 py-3 border border-yellow-500/30">
                        <Key size={18} className="text-yellow-300 mr-2" />
                        <input className="bg-transparent border-none outline-none text-white text-sm w-full placeholder-yellow-200/50" placeholder="Enter Teacher Code (Get from Admin)" value={teacherCode} onChange={e => setTeacherCode(e.target.value)} required />
                    </div>
                )}

                {role === 'parent' && (
                    <div className="bg-purple-500/20 backdrop-blur rounded-xl flex items-center px-4 py-3 border border-purple-500/30">
                        <Users size={18} className="text-purple-300 mr-2" />
                        <input className="bg-transparent border-none outline-none text-white text-sm w-full placeholder-purple-200/50" placeholder="Your Student's Name" value={linkedStudentName} onChange={e => setLinkedStudentName(e.target.value)} required />
                    </div>
                )}
                </>
            )}

            <div className="bg-white/10 backdrop-blur rounded-xl flex items-center px-4 py-3 border border-white/5 transition-all focus-within:bg-white/20 focus-within:border-white/30">
                <Mail size={18} className="text-indigo-300 mr-2" />
                <input 
                    className="bg-transparent border-none outline-none text-white text-sm w-full placeholder-indigo-300/50" 
                    placeholder="Username or Email" 
                    value={email} 
                    onChange={e => setEmail(e.target.value)} 
                    onBlur={handleEmailBlur}
                    required 
                />
            </div>

            <div className="bg-white/10 backdrop-blur rounded-xl flex items-center px-4 py-3 border border-white/5 transition-all focus-within:bg-white/20 focus-within:border-white/30">
                <Lock size={18} className="text-indigo-300 mr-2" />
                <input 
                    type="password"
                    className="bg-transparent border-none outline-none text-white text-sm w-full placeholder-indigo-300/50" 
                    placeholder="Password" 
                    value={password} 
                    onChange={e => setPassword(e.target.value)} 
                    required 
                />
            </div>

            {!isLogin && (
                 <div className="bg-white/10 backdrop-blur rounded-xl flex items-center px-4 py-3 border border-white/5 transition-all focus-within:bg-white/20 focus-within:border-white/30">
                    <Lock size={18} className="text-indigo-300 mr-2" />
                    <input type="password" className="bg-transparent border-none outline-none text-white text-sm w-full placeholder-indigo-300/50" placeholder="Confirm Password" value={confirmPassword} onChange={e => setConfirmPassword(e.target.value)} required />
                </div>
            )}

            <button type="submit" disabled={loading} className="w-full bg-gradient-to-r from-blue-500 to-indigo-600 text-white font-bold py-4 rounded-xl shadow-lg shadow-indigo-500/30 hover:shadow-indigo-500/50 transform hover:scale-[1.02] transition-all flex justify-center items-center gap-2">
                {loading ? 'Processing...' : (isLogin ? 'Login' : 'Sign Up')}
                {!loading && <ArrowRight size={20} />}
            </button>
        </form>

        <div className="mt-8 flex flex-col items-center gap-4 w-full">
             <div className="flex items-center gap-3 w-full">
                <div className="h-px bg-indigo-300/20 flex-1"></div>
                <span className="text-indigo-300/50 text-xs">OR CONTINUE WITH</span>
                <div className="h-px bg-indigo-300/20 flex-1"></div>
            </div>
            <button onClick={handleGoogleLogin} className="w-full bg-white text-gray-800 font-bold py-3 rounded-xl shadow-md hover:bg-gray-50 flex justify-center items-center gap-2">
                <img src="https://www.gstatic.com/firebasejs/ui/2.0.0/images/auth/google.svg" className="w-5 h-5" alt="" />
                Google
            </button>
            <p className="text-indigo-200 text-sm">
                {isLogin ? "Don't have an account?" : "Already have an account?"}
                <button onClick={() => setIsLogin(!isLogin)} className="font-bold text-white ml-2 underline hover:text-cyan-300">{isLogin ? 'Sign Up' : 'Login'}</button>
            </p>
        </div>
      </div>
    </div>
  );
};

export default Login;