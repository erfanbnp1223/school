
import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useTheme } from '../contexts/ThemeContext';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { 
  Home, BookOpen, Bell, User, Menu, LogOut, Settings, MessageCircle,
  Library, GraduationCap, ClipboardList, Calendar, Users, ShieldCheck, CreditCard, Briefcase, X, ChevronRight,
  IdCard, FileText, Video, BrainCircuit, Image, Clock, AlertTriangle, Inbox, Trophy
} from 'lucide-react';
import { auth, db, rtdb } from '../firebase';
import { collection, query, where, onSnapshot } from 'firebase/firestore';
import { ref, onValue } from 'firebase/database';

// Sidebar Link Component
const SidebarLink: React.FC<{ item: any; onClick: () => void; badge?: number }> = ({ item, onClick, badge }) => {
  const location = useLocation();
  const isActive = location.pathname === item.path;
  const { theme, primaryColor, themeClasses } = useTheme();

  // Refined Active State
  const activeBg = theme === 'dark' ? 'bg-white/10 text-white' : `${primaryColor} text-white shadow-lg shadow-indigo-500/20`;
  const inactiveBg = 'text-gray-500 hover:bg-gray-100/50 hover:text-gray-900 dark:text-gray-400 dark:hover:bg-white/5 dark:hover:text-gray-200';

  return (
    <Link
      to={item.path}
      onClick={onClick}
      className={`relative flex items-center space-x-3 px-4 py-3 my-1 mx-2 rounded-xl transition-all duration-300 group ${
        isActive ? activeBg : inactiveBg
      }`}
    >
      <div className={`transition-transform duration-300 ${isActive ? 'scale-110' : 'group-hover:scale-110'}`}>
          {item.icon}
      </div>
      <span className={`whitespace-nowrap tracking-wide text-sm font-semibold flex-1 ${isActive ? 'font-bold' : ''}`}>{item.name}</span>
      
      {/* Active Indicator Dot */}
      {isActive && <div className="w-1.5 h-1.5 bg-white rounded-full shadow-sm"></div>}

      {/* Badge */}
      {badge ? (
          <span className="absolute right-2 top-2 w-2.5 h-2.5 bg-red-500 rounded-full animate-pulse border border-white dark:border-slate-800"></span>
      ) : null}
    </Link>
  );
};

interface LayoutProps {
  children: React.ReactNode;
}

const Layout: React.FC<LayoutProps> = ({ children }) => {
  const { userProfile } = useAuth();
  const { theme, playSound, primaryColor, hideHeader, themeClasses } = useTheme();
  const location = useLocation();
  const navigate = useNavigate();
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [notificationCount, setNotificationCount] = useState(0);

  // --- Notification Listener ---
  useEffect(() => {
    if (!userProfile) return;
    
    // 1. Listen for Pending Meetings
    let meetingQ = query(collection(db, 'meetings'), where('status', '==', 'pending'));
    if (userProfile.role === 'teacher') {
        meetingQ = query(collection(db, 'meetings'), where('teacherId', '==', userProfile.uid), where('status', '==', 'pending'));
    } 
    
    const unsubMeetings = onSnapshot(meetingQ, snap => {
        // Simple badge logic
    });

    // 2. Listen for RTDB Chats
    const chatsRef = ref(rtdb, 'chats');
    const unsubChats = onValue(chatsRef, snap => {
        const data = snap.val();
        let unread = 0;
        if(data) {
             Object.keys(data).forEach(key => {
                 if(key.includes(userProfile.uid)) {
                      const msgs = data[key].messages;
                      if(msgs) {
                          const lastKey = Object.keys(msgs).pop();
                          if(lastKey) {
                              const lastMsg = msgs[lastKey];
                              if(lastMsg.senderId !== userProfile.uid) {
                                  // In a real app, check 'read' status. Here we assume last msg is new.
                                  unread++;
                              }
                          }
                      }
                 }
             });
        }
        setNotificationCount(unread);
    });

    return () => { unsubMeetings(); unsubChats(); };
  }, [userProfile]);


  if (location.pathname === '/admin') return <>{children}</>;

  const handleLogout = async () => {
    if(window.confirm("Are you sure you want to logout?")) {
        playSound('click');
        await auth.signOut();
        navigate('/login');
    }
  };

  const isActive = (path: string) => location.pathname === path;
  
  // Full Screen Logic for Chat
  const isChat = location.pathname === '/chat';

  // Navigation Config
  const mainNavItems = [
    { name: 'Home', path: '/', icon: <Home size={20} /> },
    { name: 'Notice Board', path: '/notice', icon: <Bell size={20} /> },
    { name: 'Homework', path: '/homework', icon: <BookOpen size={20} /> },
    { name: 'My Profile', path: '/profile', icon: <User size={20} /> },
  ];

  const drawerItems = [
    { name: 'Inbox', path: '/inbox', icon: <Inbox size={18} /> },
    { name: 'Digital ID', path: '/id-card', icon: <IdCard size={18} /> },
    { name: 'Online Quiz', path: '/quiz', icon: <BrainCircuit size={18} /> },
    { name: 'Participation', path: '/participation', icon: <Trophy size={18} /> },
    { name: 'Meeting', path: '/meeting', icon: <Clock size={18} /> },
    { name: 'Complaint Box', path: '/complaint', icon: <AlertTriangle size={18} /> },
    { name: 'Gallery', path: '/gallery', icon: <Image size={18} /> },
    { name: 'Calendar', path: '/calendar', icon: <Calendar size={18} /> },
    { name: 'Video Class', path: '/videos', icon: <Video size={18} /> },
    { name: 'Leave App', path: '/leave', icon: <FileText size={18} /> },
    { name: 'Routine', path: '/routine', icon: <ClipboardList size={18} /> },
    { name: 'Teachers', path: '/teachers', icon: <Briefcase size={18} /> },
    { name: 'Attendance', path: '/attendance', icon: <ShieldCheck size={18} /> },
    { name: 'Exam Results', path: '/results', icon: <GraduationCap size={18} /> },
    { name: 'Tuition Fees', path: '/fees', icon: <CreditCard size={18} /> },
    { name: 'Library', path: '/library', icon: <Library size={18} /> },
    { name: 'Messages', path: '/chat', icon: <MessageCircle size={18} /> },
    { name: 'Settings', path: '/settings', icon: <Settings size={18} /> },
  ];

  if (userProfile?.role !== 'student') {
      drawerItems.splice(1, 0, { name: 'All Students', path: '/students', icon: <Users size={18} /> });
  }
  
  // Header Style Construction
  const headerGradient = 
    theme === 'dark' ? 'bg-slate-900/95 backdrop-blur-md border-b border-slate-800' : 
    'bg-white/90 backdrop-blur-xl border-b border-white/40 shadow-sm';

  const headerText = theme === 'dark' ? 'text-white' : 'text-slate-800';

  return (
    <div className={`min-h-screen flex overflow-hidden ${themeClasses.mainBg} font-sans text-gray-800 relative`}>
      
      {/* Background Animation (Subtle) */}
      <div className="fixed inset-0 overflow-hidden pointer-events-none z-0">
          <ul className="circles opacity-30">
            <li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li><li></li>
          </ul>
      </div>

      {/* PC Sidebar */}
      <aside className={`hidden md:flex flex-col w-[18rem] h-[96vh] my-[2vh] ml-4 rounded-[2rem] fixed top-0 left-0 shadow-2xl z-50 overflow-hidden transition-all duration-300 border border-white/20 dark:border-slate-800 backdrop-blur-xl ${theme === 'dark' ? 'bg-slate-900/90' : 'bg-white/80'}`}>
        
        {/* Sidebar Header */}
        <div className="relative h-32 flex flex-col justify-end p-6 overflow-hidden">
             {/* Background Image */}
             <div className="absolute inset-0 z-0">
                  <img src="https://i.postimg.cc/y3WGqbYX/image.jpg" className="w-full h-full object-cover opacity-100" />
                  <div className={`absolute inset-0 bg-gradient-to-t ${theme === 'dark' ? 'from-slate-900 via-slate-900/60' : 'from-white via-white/60'} to-transparent`}></div>
             </div>
             
             <div className="relative z-10 flex items-center gap-3 animate-fade-in">
                 <img src="https://i.ibb.co/mC9LzB2b/1000121773.jpg" className="w-10 h-10 rounded-full object-cover border-2 border-white shadow-lg" />
                 <div className="flex flex-col">
                    <span className={`text-base font-extrabold leading-tight ${themeClasses.textMain}`}>পাঁচগাও আদর্শ</span>
                    <span className={`text-[10px] ${themeClasses.textSub} font-bold uppercase tracking-widest opacity-80`}>উচ্চ বিদ্যালয়</span>
                 </div>
             </div>
        </div>

        {/* Sidebar Nav */}
        <nav className="flex-1 overflow-y-auto no-scrollbar py-4 px-2 space-y-1 relative z-10">
          <div className="mb-2">
              <p className="px-6 text-[10px] font-bold text-gray-400 uppercase tracking-widest mb-2">Main Menu</p>
              {mainNavItems.map((item) => (
                <SidebarLink 
                    key={item.path} 
                    item={item} 
                    onClick={() => playSound('click')} 
                />
              ))}
          </div>
          
          <div className="mt-6">
            <div className="flex items-center px-4 mb-2">
                <span className="px-2 text-[10px] font-bold text-gray-400 uppercase tracking-widest">Apps & Tools</span>
                <div className="h-px bg-gray-200 dark:bg-slate-700 flex-1 ml-2 opacity-50"></div>
            </div>
            {drawerItems.map((item) => (
                <SidebarLink key={item.path} item={item} onClick={() => playSound('click')} badge={item.name === 'Inbox' ? notificationCount : undefined} />
            ))}
          </div>
        </nav>
        
        {/* User Mini Profile */}
        <div className={`p-4 mx-2 mb-2 rounded-2xl ${themeClasses.accentBg} flex items-center gap-3 border ${themeClasses.border}`}>
            <img src={userProfile?.photoURL} className="w-10 h-10 rounded-full border border-gray-200 object-cover" />
            <div className="flex-1 min-w-0">
                <p className={`text-sm font-bold truncate ${themeClasses.textMain}`}>{userProfile?.displayName}</p>
                <p className="text-[10px] text-gray-400 truncate">{userProfile?.email}</p>
            </div>
            <button onClick={handleLogout} className="p-2 text-red-400 hover:bg-red-50 rounded-full transition-colors"><LogOut size={16}/></button>
        </div>
      </aside>

      {/* Main Content */}
      <main className={`flex-1 md:ml-[19.5rem] flex flex-col h-screen overflow-y-auto overflow-x-hidden ${isChat ? 'pb-0 p-0' : 'pb-24 md:pb-0 p-4 md:p-8'} relative z-10 no-scrollbar`}>
         
         {/* Standalone Menu Button (Visible when header is hidden on PC/Mobile OR when in Chat) */}
         {(hideHeader || isChat) && (
             <div className="fixed top-4 right-4 z-[45] flex gap-2 md:hidden">
                 {/* Only show Inbox button if NOT in chat to save space */}
                 {!isChat && (
                    <button 
                        onClick={() => { playSound('click'); navigate('/inbox'); }}
                        className={`p-3 rounded-full shadow-2xl transition-all active:scale-90 border backdrop-blur-md animate-fade-in relative ${theme === 'dark' ? 'bg-slate-800/80 text-white border-slate-700' : 'bg-white/80 text-indigo-600 border-white/40'}`}
                    >
                        <Inbox size={24} strokeWidth={2.5} />
                        {notificationCount > 0 && <span className="absolute top-2 right-2 w-2.5 h-2.5 bg-red-500 rounded-full animate-pulse border border-white"></span>}
                    </button>
                 )}
                 
                 <button 
                    onClick={() => { playSound('click'); setDrawerOpen(true); }}
                    className={`p-3 rounded-full shadow-2xl transition-all active:scale-90 border backdrop-blur-md animate-fade-in ${theme === 'dark' ? 'bg-slate-800/80 text-white border-slate-700' : 'bg-white/80 text-indigo-600 border-white/40'}`}
                 >
                     <Menu size={24} strokeWidth={2.5} />
                 </button>
             </div>
         )}

         {/* Mobile Header (Floating & Glass) - HIDDEN ON CHAT PAGE */}
         {!isChat && (
             <div className={`md:hidden sticky top-0 z-30 transition-all duration-500 px-4 pt-4 pb-2 ${hideHeader ? '-translate-y-32 absolute opacity-0 pointer-events-none' : ''}`}>
                 <div className={`${headerGradient} rounded-[2rem] flex justify-between items-center p-3 pl-4 pr-3`}>
                     <div className="flex items-center gap-3">
                         <img src="https://i.ibb.co/mC9LzB2b/1000121773.jpg" className="w-10 h-10 rounded-full object-cover border-2 border-white shadow-sm" />
                         <div className="flex flex-col">
                            <h1 className={`text-sm font-extrabold ${headerText} tracking-tight leading-none`}>পাঁচগাও আদর্শ</h1>
                            <span className={`text-[10px] ${headerText} opacity-70 font-bold uppercase`}>উচ্চ বিদ্যালয়</span>
                         </div>
                     </div>
                     
                     <div className="flex items-center gap-2">
                         {/* Inbox Button in Header */}
                         <button 
                            onClick={() => { playSound('click'); navigate('/inbox'); }}
                            className={`p-2 rounded-full active:scale-90 transition-all duration-300 relative ${
                                 theme === 'dark' ? 'hover:bg-slate-800 text-white' : 'hover:bg-indigo-50 text-indigo-600'
                            }`}
                         >
                            <Inbox size={24} strokeWidth={2.5} />
                            {notificationCount > 0 && <span className="absolute top-1.5 right-1.5 w-2.5 h-2.5 bg-red-500 rounded-full animate-pulse border border-white"></span>}
                         </button>

                         {/* Menu Button */}
                         <button 
                            onClick={() => { playSound('click'); setDrawerOpen(true); }} 
                            className={`p-2.5 rounded-full active:scale-90 transition-all duration-300 shadow-sm border ${
                                 theme === 'dark' ? 'bg-slate-800 text-white border-slate-700' : 'bg-white text-indigo-600 border-indigo-50'
                            }`}
                         >
                            <Menu size={24} strokeWidth={2.5} />
                         </button>
                     </div>
                 </div>
               </div>
         )}

         {/* Content Wrapper */}
         <div className={`${isChat ? "flex-1 w-full h-full overflow-hidden" : "max-w-6xl mx-auto w-full relative"}`}>
            {children}
         </div>
      </main>

      {/* Professional Floating Bottom Navigation (Glass Dock) - Z-Index 40 - HIDDEN ON CHAT */}
      {!isChat && (
        <nav className="md:hidden fixed bottom-6 left-6 right-6 z-40">
           <div className={`rounded-[2.5rem] flex justify-between items-center px-6 py-4 shadow-2xl backdrop-blur-xl border transition-all duration-300 ${
              theme === 'dark' 
                ? 'bg-slate-900/90 border-slate-700 shadow-slate-900/50' 
                : 'bg-white/95 border-white/50 shadow-indigo-500/10'
           }`}>
              {mainNavItems.map((item) => {
                const active = isActive(item.path);
                return (
                    <Link
                    key={item.path}
                    to={item.path}
                    onClick={() => playSound('click')}
                    className={`relative flex items-center gap-2 transition-all duration-300 ${active ? 'flex-grow justify-center' : 'flex-none'}`}
                    >
                        <div className={`p-2.5 rounded-full transition-all duration-300 relative ${
                            active 
                            ? `${primaryColor} text-white shadow-lg transform -translate-y-1` 
                            : 'text-gray-400 hover:text-gray-600 dark:text-slate-500 bg-transparent'
                        }`}>
                            {item.icon}
                        </div>
                        
                        {/* Animated Label for Active Tab */}
                        {active && (
                            <span className={`text-xs font-bold animate-fade-in ${
                                theme === 'dark' ? 'text-white' : 'text-gray-800'
                            }`}>
                                {item.name}
                            </span>
                        )}

                        {/* Active Indicator Dot */}
                        {active && (
                            <span className={`absolute -bottom-2 left-1/2 transform -translate-x-1/2 w-1 h-1 rounded-full ${primaryColor}`}></span>
                        )}
                    </Link>
                )
              })}
           </div>
        </nav>
      )}

      {/* Mobile Drawer */}
      <div className={`fixed inset-0 z-[250] md:hidden transition-all duration-300 ${drawerOpen ? 'visible' : 'invisible'}`}>
          <div 
             className={`absolute inset-0 bg-black/60 backdrop-blur-sm transition-opacity duration-300 ${drawerOpen ? 'opacity-100' : 'opacity-0'}`} 
             onClick={() => setDrawerOpen(false)}
          ></div>
          <div className={`absolute right-0 top-0 h-full w-[85%] max-w-[320px] shadow-2xl flex flex-col overflow-y-auto ${themeClasses.cardBg} ${themeClasses.textMain} transition-transform duration-300 ease-out border-l border-white/10 rounded-l-[2.5rem] ${drawerOpen ? 'translate-x-0' : 'translate-x-full'}`}>
            <div className={`relative overflow-hidden ${primaryColor} text-white min-h-[160px]`}>
               <div className="absolute inset-0 z-0">
                    <img src="https://i.postimg.cc/y3WGqbYX/image.jpg" className="w-full h-full object-cover opacity-30" />
                    <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-black/10"></div>
               </div>
               <div className="relative z-10 p-8 flex flex-col justify-end h-full">
                  <div className="flex justify-between items-start mb-4">
                      <div className="w-16 h-16 rounded-full border-4 border-white/30 shadow-inner overflow-hidden bg-white">
                          <img src={userProfile?.photoURL || 'https://ui-avatars.com/api/?name=User'} className="w-full h-full object-cover" />
                      </div>
                      <button onClick={() => setDrawerOpen(false)} className="p-2 bg-white/20 rounded-full hover:bg-white/30 backdrop-blur-md text-white shadow-lg"><X size={20} /></button>
                  </div>
                  <span className="font-bold text-xl leading-tight text-white drop-shadow-md">{userProfile?.displayName || 'Guest'}</span>
                  <span className="text-white/80 text-sm drop-shadow-sm">{userProfile?.email}</span>
               </div>
            </div>
            
            <div className="flex-1 p-6 space-y-2 overflow-y-auto">
               <p className="text-xs font-bold opacity-40 uppercase tracking-widest mb-2 px-2">Menu</p>
               {drawerItems.map((item) => (
                   <Link
                     key={item.path}
                     to={item.path}
                     onClick={() => { playSound('click'); setDrawerOpen(false); }}
                     className={`flex items-center space-x-4 px-4 py-3.5 rounded-2xl transition-all border border-transparent ${
                         isActive(item.path) 
                           ? `${primaryColor} text-white shadow-lg font-bold` 
                           : `hover:bg-gray-50 dark:hover:bg-slate-800 hover:border-gray-100`
                     }`}
                   >
                       {item.icon}
                       <span className="text-sm font-medium">{item.name}</span>
                       {item.name === 'Inbox' && notificationCount > 0 && (
                           <span className="ml-auto bg-red-500 text-white text-[10px] px-2 py-0.5 rounded-full">{notificationCount}</span>
                       )}
                   </Link>
               ))}
            </div>

            <div className="p-6">
                <button onClick={handleLogout} className="flex items-center justify-center space-x-3 px-4 py-4 rounded-2xl text-red-500 bg-red-50 dark:bg-red-900/20 w-full font-bold shadow-sm hover:bg-red-100 transition-colors">
                    <LogOut size={20} /> <span>Sign Out</span>
                </button>
            </div>
          </div>
      </div>
    </div>
  );
};

export default Layout;
