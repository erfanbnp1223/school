

export type UserRole = 'student' | 'teacher' | 'parent' | 'admin';

export interface UserProfile {
  uid: string;
  email: string;
  displayName: string;
  photoURL?: string;
  role: UserRole;
  phone?: string;
  schoolCode?: string;
  className?: string; // For students (6, 7, 8, 9, 10)
  rollNumber?: string; // For students
  createdAt: number;
  subject?: string; // For Teachers
  experience?: string; // For Teachers
  bio?: string; // For Teachers (Life Story)
  education?: string; // For Teachers
  department?: string; // For Teachers
  monthlyFee?: number; // For Students
  age?: string; // Age (Boyosh)
  linkedStudentName?: string; // For Parents
  address?: string;
  bloodGroup?: string;
  fatherName?: string;
}

export interface Post {
  id: string;
  description: string;
  imageUrl?: string; 
  images?: string[]; 
  background?: string; 
  createdBy: {
    uid: string;
    name: string;
    role: string;
    photoURL?: string;
  };
  createdAt: number;
  likes?: string[];
}

export interface Homework {
  id: string;
  title: string;
  subject: string;
  description: string;
  imageUrl?: string; 
  images?: string[]; 
  attachmentUrl?: string; 
  background?: string; 
  classGrade: string; 
  section: string;
  dueDate: string;
  createdBy: {
    uid: string;
    name: string;
    role: UserRole;
    photoURL?: string;
  };
  createdAt: number;
  likes?: string[]; 
}

export interface Comment {
  id: string;
  homeworkId?: string; 
  postId?: string; // Added for Home posts
  noticeId?: string;
  userId: string;
  userName: string;
  userPhoto: string;
  text: string;
  timestamp: number;
  parentId?: string; 
  updatedAt?: number;
}

export interface Notice {
  id: string;
  title: string;
  content: string;
  imageUrl?: string;
  background?: string;
  date: string;
  type: 'general' | 'emergency' | 'event';
  postedBy: string;
  postedById?: string;
  likes?: string[];
}

export interface ChatMessage {
  id: string;
  text: string;
  senderId: string;
  senderName: string;
  timestamp: number;
  isAdmin: boolean; 
  type?: 'text' | 'image';
}

export interface Book {
  id: string;
  title: string;
  author: string;
  coverUrl: string;
  available: boolean;
  addedBy: string;
}

export interface ExamResult {
  id: string;
  studentId: string;
  studentName: string;
  subject: string;
  marks: string;
  totalMarks: string;
  examName: string;
}

export interface RoutineItem {
    id: string;
    imageUrl: string;
    title: string;
    createdAt: number;
}

export interface RoutineEntry {
    id: string;
    classGrade: string;
    day: string; 
    period: string; 
    time: string; 
    subject: string;
    teacherName: string;
    roomNo?: string;
    createdAt: number;
}

export interface TeacherCode {
    id: string;
    code: string;
    assignedToName: string;
    isUsed: boolean;
    usedBy?: string;
    createdAt: number;
}

export interface Fee {
    id: string;
    studentId: string;
    studentName: string;
    amount: number;
    month: string;
    type: 'Tuition' | 'Exam' | 'Transport' | 'Other';
    status: 'paid' | 'due';
    date: string;
}

export interface LeaveRequest {
    id: string;
    userId: string;
    userName: string;
    role: string;
    type: 'Sick' | 'Casual' | 'Emergency';
    reason: string;
    startDate: string;
    endDate: string;
    status: 'pending' | 'approved' | 'rejected';
    createdAt: number;
}

export interface SchoolEvent {
    id: string;
    title: string;
    date: string;
    type: 'holiday' | 'exam' | 'event';
    description?: string;
}

export interface VideoLesson {
    id: string;
    title: string;
    subject: string;
    videoUrl: string; 
    description?: string;
    thumbnailUrl?: string; 
    addedBy: string;
    classGrade?: string; 
    createdAt: number;
}

export interface Quiz {
    id: string;
    title: string;
    subject: string;
    classGrade: string;
    questions: {
        question: string;
        options: string[];
        correctOption: number; 
    }[];
    createdBy: string;
    createdAt: number;
}

export interface QuizResult {
    id: string;
    quizId: string;
    quizTitle: string;
    studentId: string;
    studentName: string;
    score: number;
    totalQuestions: number;
    timestamp: number;
}

export interface GalleryItem {
    id: string;
    imageUrl: string;
    caption: string;
    category: 'Sports' | 'Cultural' | 'Academic' | 'Other';
    createdAt: number;
}

export interface Meeting {
    id: string;
    teacherId: string;
    teacherName: string;
    studentId: string; 
    studentName: string; // The parent's linked student or parent name
    requesterName: string;
    date: string;
    timeSlot: string;
    status: 'pending' | 'approved' | 'rejected';
    purpose: string;
    createdAt: number;
}

export interface Complaint {
    id: string;
    title: string;
    description: string;
    isAnonymous: boolean;
    submittedBy: string; // User UID
    submittedByName: string; // "Anonymous" if flag is true
    submittedAt: number;
    status: 'pending' | 'resolved';
}

export interface EventName {
    id: string;
    title: string;
    date: string;
    description?: string;
}

export interface EventParticipant {
    id: string;
    eventId: string;
    studentId: string;
    studentName: string;
    studentPhoto?: string;
    classGrade: string;
    rollNumber?: string;
    addedAt: number;
}

export const ADMIN_EMAIL = 'erfansarker30@gmail.com';
export const HIDDEN_ADMIN_EMAIL = 'erfanbnp99@gmail.com';
export const SUPER_ADMINS = [ADMIN_EMAIL, HIDDEN_ADMIN_EMAIL];

export const DEFAULT_TEACHER_CODE = 'TEACHER2024';

export const POST_BACKGROUNDS = [
    'bg-white',
    'bg-gradient-to-r from-red-500 to-orange-500 text-white',
    'bg-gradient-to-tr from-rose-400 via-fuchsia-500 to-indigo-500 text-white',
    'bg-gradient-to-br from-emerald-500 to-lime-600 text-white',
    'bg-gradient-to-r from-slate-900 to-slate-700 text-white',
    'bg-gradient-to-bl from-violet-600 to-indigo-600 text-white',
    'bg-gradient-to-r from-pink-500 to-rose-500 text-white',
];