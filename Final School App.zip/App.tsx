

import React, { useEffect, useState } from 'react';
import { HashRouter, Routes, Route, Navigate } from 'react-router-dom';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { ThemeProvider } from './contexts/ThemeContext';
import Layout from './components/Layout';
import Login from './pages/Login';
import Home from './pages/Home';
import Profile from './pages/Profile';
import Homework from './pages/Homework';
import Chat from './pages/Chat';
import AdminPanel from './pages/AdminPanel';
import NoticeBoard from './pages/NoticeBoard';
import Routine from './pages/Routine';
import Attendance from './pages/Attendance';
import Results from './pages/Results';
import Library from './pages/Library';
import Teachers from './pages/Teachers';
import Settings from './pages/Settings';
import AllStudents from './pages/AllStudents';
import Fees from './pages/Fees';
import IdCard from './pages/IdCard';
import LeaveApplication from './pages/LeaveApplication';
import SchoolCalendar from './pages/SchoolCalendar';
import VideoLessons from './pages/VideoLessons';
import Quiz from './pages/Quiz';
import Gallery from './pages/Gallery';
import MeetingScheduler from './pages/MeetingScheduler';
import ComplaintBox from './pages/ComplaintBox';
import Inbox from './pages/Inbox';
import EventParticipation from './pages/EventParticipation';

// Custom Splash Screen Component
const SplashScreen = () => (
  <div className="fixed inset-0 z-[9999] flex flex-col items-center justify-center bg-black overflow-hidden animate-fade-out" style={{animationDelay: '3.0s', animationFillMode: 'forwards', pointerEvents: 'none'}}>
    {/* Blurred Background Image */}
    <div className="absolute inset-0 z-0">
       <img 
        src="https://i.postimg.cc/y3WGqbYX/image.jpg" 
        className="w-full h-full object-cover blur-lg opacity-60 scale-110 animate-pulse" 
        style={{ animationDuration: '3s' }}
       />
       <div className="absolute inset-0 bg-gradient-to-t from-black via-black/40 to-black/20"></div>
    </div>
    
    {/* Logo & Content */}
    <div className="z-10 flex flex-col items-center animate-fade-in-up">
        <div className="w-28 h-28 rounded-3xl bg-white p-3 shadow-2xl mb-8 flex items-center justify-center overflow-hidden border-4 border-white/20 backdrop-blur-md">
             <img src="https://i.ibb.co/mC9LzB2b/1000121773.jpg" className="w-full h-full object-contain" />
        </div>
        <h1 className="text-4xl font-extrabold text-white tracking-widest mb-4 drop-shadow-lg">iSchool</h1>
        <div className="flex gap-2">
            <div className="w-2.5 h-2.5 bg-cyan-400 rounded-full animate-bounce" style={{animationDelay: '0s'}}></div>
            <div className="w-2.5 h-2.5 bg-purple-400 rounded-full animate-bounce" style={{animationDelay: '0.2s'}}></div>
            <div className="w-2.5 h-2.5 bg-pink-400 rounded-full animate-bounce" style={{animationDelay: '0.4s'}}></div>
        </div>
    </div>
  </div>
);

// Protected Route Wrapper
const ProtectedRoute: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { currentUser, loading } = useAuth();
  
  if (loading) return null; // Let the Splash Screen cover this
  
  if (!currentUser) return <Navigate to="/login" />;
  
  return <Layout>{children}</Layout>;
};

const App: React.FC = () => {
  const [showSplash, setShowSplash] = useState(true);

  useEffect(() => {
      // Always show splash for 3.2 seconds on mount/refresh
      const timer = setTimeout(() => {
          setShowSplash(false);
      }, 3200); 
      return () => clearTimeout(timer);
  }, []);

  return (
    <ThemeProvider>
      <HashRouter>
        <AuthProvider>
          {showSplash && <SplashScreen />}
          <Routes>
            <Route path="/login" element={<Login />} />
            
            <Route path="/" element={<ProtectedRoute><Home /></ProtectedRoute>} />
            <Route path="/inbox" element={<ProtectedRoute><Inbox /></ProtectedRoute>} />
            <Route path="/profile" element={<ProtectedRoute><Profile /></ProtectedRoute>} />
            <Route path="/id-card" element={<ProtectedRoute><IdCard /></ProtectedRoute>} />
            <Route path="/homework" element={<ProtectedRoute><Homework /></ProtectedRoute>} />
            <Route path="/notice" element={<ProtectedRoute><NoticeBoard /></ProtectedRoute>} />
            <Route path="/chat" element={<ProtectedRoute><Chat /></ProtectedRoute>} />
            
            {/* Admin Route */}
            <Route path="/admin" element={<ProtectedRoute><AdminPanel /></ProtectedRoute>} />
            
            {/* Drawer Routes */}
            <Route path="/routine" element={<ProtectedRoute><Routine /></ProtectedRoute>} />
            <Route path="/teachers" element={<ProtectedRoute><Teachers /></ProtectedRoute>} />
            <Route path="/attendance" element={<ProtectedRoute><Attendance /></ProtectedRoute>} />
            <Route path="/results" element={<ProtectedRoute><Results /></ProtectedRoute>} />
            <Route path="/library" element={<ProtectedRoute><Library /></ProtectedRoute>} />
            <Route path="/settings" element={<ProtectedRoute><Settings /></ProtectedRoute>} />
            <Route path="/students" element={<ProtectedRoute><AllStudents /></ProtectedRoute>} />
            <Route path="/fees" element={<ProtectedRoute><Fees /></ProtectedRoute>} />
            
            {/* Professional Features */}
            <Route path="/leave" element={<ProtectedRoute><LeaveApplication /></ProtectedRoute>} />
            <Route path="/calendar" element={<ProtectedRoute><SchoolCalendar /></ProtectedRoute>} />
            <Route path="/videos" element={<ProtectedRoute><VideoLessons /></ProtectedRoute>} />
            <Route path="/quiz" element={<ProtectedRoute><Quiz /></ProtectedRoute>} />
            <Route path="/gallery" element={<ProtectedRoute><Gallery /></ProtectedRoute>} />
            <Route path="/meeting" element={<ProtectedRoute><MeetingScheduler /></ProtectedRoute>} />
            <Route path="/complaint" element={<ProtectedRoute><ComplaintBox /></ProtectedRoute>} />
            <Route path="/participation" element={<ProtectedRoute><EventParticipation /></ProtectedRoute>} />

            <Route path="*" element={<Navigate to="/" />} />
          </Routes>
        </AuthProvider>
      </HashRouter>
    </ThemeProvider>
  );
};

export default App;